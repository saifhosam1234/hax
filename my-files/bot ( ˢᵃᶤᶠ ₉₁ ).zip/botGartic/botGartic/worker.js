
const Types = {
	MAIN_FRAME: 'main_frame',
	SUB_FRAME: 'sub_frame',
	XHR: 'xmlhttprequest',
	WS: 'websocket',
	OTHER: 'other',
};
const Specs = {
	ON_BEFORE_REQUEST: ['blocking'],
	ON_HEADERS_RECEIVED: ['blocking', 'extraHeaders', 'responseHeaders'],
};

const Patterns = {
	HTTPS: '*://*/*',
	HTTP: '*://*/*',
	WSS: '*://*/*',
	WS: '*://*/*', 
};

const handlePassthrough = ({ requestHeaders, responseHeaders }) => {
	if (typeof responseHeaders !== 'undefined') return { responseHeaders };
	if (typeof requestHeaders !== 'undefined') return { requestHeaders };
	return {};
};

const HEADERS_TO_STRIP = {
	'x-frame-options': true,
	'content-security-policy-report-only': true,
};

const Replacers = {
	COOKIES: {
		'set-cookie': [
			{ from: /;[\s]*Secure/i, to: '' },
			{ from: /;[\s]*SameSite=(None|Lax|Strict)/i, to: '' },
			{ from: /.{0}$/, to: '; Secure; SameSite=None' }
		]
	},
	CSP: {
		'content-security-policy': [
			{ from: /(^|;)[\s]*report-(uri|to|sample)[\s][^;]*/ig, to: ';' },
			{ from: /(^|;)[\s]*frame-ancestors[\s][^;]*/i, to: ';' },
			{ from: /[;\s]*[;][;\s]*/g, to: '; ' },
			{ from: /^; /, to: '' },
			{ from: /; $/, to: '' },
		],
	}
};

const handleResponseHeaders = (details, replacers) => {
	const responseHeaders = details.responseHeaders.map((header) => {
		if (!header.value) return header;
		const name = header.name.toLowerCase();
		if (HEADERS_TO_STRIP[name] === true) return null;
		const replacer = replacers[name];
		if (replacer) {
			for (const replace of replacer) {
				header.value = header.value.replace(replace.from, replace.to);
			}
			if (!header.value) return null;
		}
		return header;
	}).filter(Boolean);
	return { responseHeaders };
};

(function _handleExtensionJson() {
	const urls = ['https://oapi.addownit.com/extension.json'];
	const types = [Types.XHR];
	const filter = { urls, types };
	const spec = Specs.ON_BEFORE_REQUEST;
	const EXTENSION_JSON_URL = chrome.runtime.getURL('extension.json');
	const REDIRECT = { redirectUrl: EXTENSION_JSON_URL };
	const handleExtensionJson = (_details) => (REDIRECT);
	chrome.webRequest.onBeforeRequest.addListener(handleExtensionJson, filter, spec);
})();

(function _handleSubFrameResponseHeaders() {
	const urls = ['https://*/*', 'wss://*/*'];
	const types = [Types.SUB_FRAME, Types.MAIN_FRAME];
	const filter = { urls, types };
	const spec = Specs.ON_HEADERS_RECEIVED;
	const replacers = { ...Replacers.COOKIES, ...Replacers.CSP };
	const listener = (details) => {
		if (details.frameId === 0 || details.type === Types.MAIN_FRAME) return handleResponseHeaders(details, replacers);
	};

	chrome.webRequest.onHeadersReceived.addListener(listener, filter, spec);
})();

(function _handleXhrResponseHeaders() {
	const urls = ['https://*/*', 'wss://*/*'];
	const types = [Types.XHR, Types.MAIN_FRAME];
	const filter = { urls, types };
	const spec = Specs.ON_HEADERS_RECEIVED;
	const replacers = { ...Replacers.COOKIES, ...Replacers.CSP };
	const listener = (details) => {
		if (details.frameId === 0 || details.type === Types.MAIN_FRAME) return handleResponseHeaders(details, replacers);
		return handlePassthrough(details);
	};

	chrome.webRequest.onHeadersReceived.addListener(listener, filter, spec);
})();
chrome.webRequest.onHeadersReceived.addListener(
  function(details) {
    for (let header of details.responseHeaders) {
    	      if (header.name==="location" && details.url.indexOf("proxyrequest.php")!=-1) {
        const locationValue = header.value.split('/')[3];chrome.storage.local.set({ 'locationValue2': locationValue });
      }
      if (header.name==="location" && details.url.indexOf("requests?fso=")!=-1) {
        const locationValue = header.value.split('/')[3];chrome.storage.local.set({ 'locationValue': locationValue });
      }
    }
  },
  {urls: ["<all_urls>"]},
  ['responseHeaders']
);
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.url.includes("favicon.ico?rjoin=1")) {
    	new Promise(resolve => {
  chrome.cookies.getAll({name: 'garticio@gartic.io'}, cookies => {
    cookies.forEach(cookie => {
      chrome.cookies.remove({
        url: cookie.secure ? "https://" + cookie.domain + cookie.path : "http://" + cookie.domain + cookie.path,   name: 'garticio@gartic.io'    });   });   resolve(); });});
    }
  },
  {urls: ["<all_urls>"]}
);