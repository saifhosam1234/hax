"use strict";
function LUNA_(...v){
  let obj = [];obj = obj.concat(v, Math.random() * 10000);chrome.storage.local.set({message: JSON.stringify(obj)});
}
function __0x70(...a){
  let o= [];o = o.concat(a);window.postMessage('cmd.'+JSON.stringify(o), '*');
}
function __0x11(...a){
  let o= [];o = o.concat(a);document.querySelectorAll('iframe').forEach(function(c) {c.contentWindow.postMessage('cmd.'+JSON.stringify(o), '*');
});
}

function __0x52(...a){console.log(a[1]);
  let o= [];o = a.slice(0, 1).concat(a.slice(2));document.querySelectorAll('iframe').forEach(function(c) {if(c.src.includes(a[1])){c.contentWindow.postMessage('cmd.'+JSON.stringify(o), '*');
}});
}
function f(ICE){return document.querySelector(ICE)}
function fa(ICE){return document.querySelectorAll(ICE)}

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}


    function addStyle(css) {
      const style = document.createElement('style');
      style.textContent = css;
      document.documentElement.appendChild(style);
    };

    function addHtml(html) {
      document.documentElement.insertAdjacentHTML('beforeend', html);
    }
    function setmenu(menu) {
  const elements = [
    '#icebot1','#icebot2','#icebot3','#icebot4',
    "#icebot5","#icebot6","#icebot7",
    '#avatarlist','#cavatarlist','#custombotnick'
  ];
  elements.forEach(element => {
    if (element === `#${menu}`) {
      f(element).style.display = 'block';
    } else {
      f(element).style.display = 'none';
    }
  });
}
    let cmd="",wss=[],tojoin=0,usersinroom=[],customkickitems=[],messagejoinitems=[],tfr,tg,intervalbroadcast,intervalmsg,intervalanswer,intervalantiafk,rainbowdraw,rainbowdrawmode=false,botsidvalue=[],wordsInterval,wordsIntervalPlayer,botID,botlongID,theme,tipo,idioma,am,avatar=localStorage.getItem("avatar"),botnick=localStorage.getItem("botnick"),nick=localStorage.getItem("nick")
    
function getSelectedServer() {
  const input = document.getElementById("serverInput");
  if (!input) return null;

  const val = parseInt(input.value);
  if (isNaN(val) || val < 1 || val > 9) return null;

  return val.toString().padStart(2, '0');
}

        if(window.location.href.indexOf("gartic.io")!=-1){
let red=["#cc0010","#a3000c","#820009","#680007","#530005","#FFFFFF"],orange=["#cc5b00","#a34800","#FFA500","#682d00","#532400","#FFFFFF"],yellow=["#ccbf00","#a39800","#FFFF00","#686000","#534c00","#000000"],green=["#66cc00","#51a300","#408200","#336800","#285300","#FFFFFF"],blue=["#2100cc","#1a00a3","#140082","#100068","#0c0053","#FFFFFF"],indigo=["#3c0068","#300053","#260042","#1e0034","#180029","#FFFFFF"],violet=["#6500cc","#5000a3","#400082","#330068","#280053","#FFFFFF"],pink=["#eb8898","#a33058","#FFC0CB","#681e38","#53182c","#FFFFFF"],crimson=["#b01030","#8c0c26","#70091e","#590718","#470513","#FFFFFF"],brown=["#793000","#602600","#4c1e00","#3c1800","#301300","#FFFFFF"],gray=["#787878","#606060","#4c4c4c","#3c3c3c","#303030","#FFFFFF"],white=["#cccccc","#a3a3a3","#FFFFFF","#686868","#535353","#000000"],black=["#191919","#141414","#101010","#0c0c0c","#090909","#80FF00"],magenta=["#cc00cc","#a300a3","#820082","#680068","#530053","#FFFFFF"];function colorChanger($){let e=[];switch($){case"red":e=red;break;case"orange":e=orange;break;case"yellow":e=yellow;break;case"green":e=green;break;case"blue":e=blue;break;case"indigo":e=indigo;break;case"violet":e=violet;break;case"pink":e=pink;break;case"crimson":e=crimson;break;case"brown":e=brown;break;case"gray":e=gray;break;case"white":e=white;break;case"black":e=black;break;case"magenta":e=magenta}let c=document.querySelectorAll(".icebot button"),o=document.querySelectorAll(".icebot"),r=document.querySelector(".option"),l=document.querySelectorAll(".option button"),a=document.querySelectorAll(".userlist"),t=document.querySelectorAll('.userlist input[type="submit"]'),F=document.querySelectorAll('.icebot input[type="range"]'),n=document.querySelectorAll(".icebot h2"),s=document.querySelectorAll('.icebot input[type="submit"]');n.forEach($=>{$.style.color=e[5]}),r.style.backgroundColor=e[2],F.forEach($=>{$.style.accentColor=e[0]}),o.forEach($=>{$.style.backgroundColor=e[2]}),c.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5],$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})}),l.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5]}),s.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5],$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})}),a.forEach($=>{$.style.backgroundColor=e[2],$.style.color=e[5]}),t.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5]});let b=document.querySelectorAll(".option button");document.querySelectorAll(".option button svg").forEach($=>{$.style.stroke=e[5]}),b.forEach($=>{$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})})}function setmenu(menu){const elements=['#icebot1','#icebot2','#icebot3','#icebot4',"#icebot5","#icebot6","#icebot7",'#avatarlist','#cavatarlist','#custombotnick'];elements.forEach(element=>{if(element===`#${menu}`){f(element).style.display='block';}else{f(element).style.display='none';}})};
function xmv() { const userAgent = navigator.userAgent.toLowerCase(); const dM = ['android', 'webos', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone']; for (let d of dM) {if (userAgent.includes(d)) { function x(){ let ice = document.querySelectorAll(".icebot");let optionBtn= document.querySelectorAll(".option button");let option= document.querySelectorAll(".option");ice.forEach(icebot=>{icebot.style.width="220px";icebot.style.left="110px"});option.forEach(option=>{option.style.left="180px";option.style.top="600px";option.style.width="320px";option.style.height="auto";});optionBtn.forEach(option=>{option.style.width="13%"});setTimeout(()=>{document.querySelector("#avatarlist").style.width="360px";document.querySelector("#avatarlist").style.left="187px";
document.querySelector("#cavatarlist").style.width="360px";document.querySelector("#cavatarlist").style.left="187px";
document.querySelector("#custombotnick").style.width="360px";document.querySelector("#custombotnick").style.left="187px"},200) };x();}}};setTimeout(()=>{xmv();},200)

 addStyle(`        @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');        .userlist *{box-sizing:border-box;}        .userlist {            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;font-style:italic;            position:fixed;left:50%;top:3px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto !important;width:200px !important;        }        .userlist input[type=text]{height:20px;border-radius:3px;font-size:9pt;background:brown;color:white;padding-left:3px;}        .userlist input[type=submit]{height:25px;border-radius:3px;background:#FFD700;}        .userlist input[type=checkbox]{margin-top:2px;}        #background{        z-index:999;width:0px;height:0px;position:fixed;left:0px;top:0px;        }        .option *{box-sizing:border-box;}        .option {            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:14%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto;width:40px;        }        .option input[type=submit],.option button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .option input[type=checkbox]{margin-top:2px;}        .option input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .option button:hover{background:#ccad00;transition:0.2s;}        .option button:hover svg {stroke: #9e6e1c;}        .option button{width:90%;}        .icebot *{box-sizing:border-box;}        #avatarlist,#custombotnick,#cavatarlist {            overflow-x:hidden;width:100%;max-height:450px;overflow-y:scroll;            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:50px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:400px;        .avatarbtn{display:flex;align-items:center;justify-content:center;}        .avatarbtn button,.avatarbtn button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:50px;font-size:11pt;margin-top:5px;}        .avatarbtn button:hover{background:#ccad00;transition:0.2s;}        }        #icebot1,#icebot2,#icebot6,#icebot7,#icebotlog,#wordlist{            overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto;width:240px;        }        #icebot3 {            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .broadcastspamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .messagespamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .answerspamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .broadcastspam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .messagespam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .answerspam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        #broadcaststop{display:none;}        #msgstop{display:none;}        #answerstop{display:none;}     .msgjointext{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;}       }        #icebot4 {            overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .kicklistbox{display:flex;align-items:center;justify-content:center;}        .kicklistbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .kicklistbox input[type=submit],.kicklistbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .kicklistbox input[type=submit]:hover{background:#ccad00;transition:0.2s;}        #kicklistaddbtn{width:40%;}        #kicklistremoveallbtn{width:40%;}        .customkickremove{width:30%;}        .customkick{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;}        }        #icebot5 {            display:none;text-align:center;opacity:none;overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .autoguess{width:40%;}        #autoguessenable{align-items:center;justify-content:center;}        #autoguessdisable{display:none;align-items:center;justify-content:center;}        .autoguessstyle{display:flex;align-items:center;justify-content:center;}        .mimicmode{width:40%;}        #mimicmodeenabled{align-items:center;justify-content:center;}        #mimicmodedisabled{display:none;align-items:center;justify-content:center;}        .mimicmodestyle{display:flex;align-items:center;justify-content:center;}        .rainbowdraw{width:30%;}        #rainbowdrawenabled{align-items:center;justify-content:center;}        #rainbowdrawdisabled{display:none;align-items:center;justify-content:center;}        .rainbowdrawstyle{display:flex;align-items:center;justify-content:center;}        .msgjoinremoveall{width:40%;}        }        .icebot input[type=submit],.icebotbtn button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .icebot input[type=checkbox]{margin-top:2px;}        .icebot input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .icebot input[type=range]{accent-color:#FFD700;}        .icebot input[type=range]:focus::-webkit-slider-runnable-track { background: #3071A9; }        #join{width:20%;}        .roomlink{display:flex;align-items:center;justify-content:center;}        .roomlink input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .roomlink input[type=submit],.broadcastbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .roomlink button:hover{background:#ccad00;transition:0.2s;}        .botnick input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .broadcastbox{display:flex;align-items:center;justify-content:center;}        .broadcastbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .broadcastbox input[type=submit],.broadcastbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .broadcastbox button:hover{background:#ccad00;transition:0.2s;}        .msgbox{display:flex;align-items:center;justify-content:center;}        .msgbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .msgbox input[type=submit],.msgbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .msgbox button:hover{background:#ccad00;transition:0.2s;}        .answerbox{display:flex;align-items:center;justify-content:center;}        .answerbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .answerbox input[type=submit],.answerbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .answerbox button:hover{background:#ccad00;transition:0.2s;}        .msgboxjoin{display:flex;align-items:center;justify-content:center;}        .msgboxjoin input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .msgboxjoin input[type=submit],.msgboxjoin button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .msgboxjoin button:hover{background:#ccad00;transition:0.2s;}        .botnick0{width:50%;}        .botnick1{width:50%;} .botnick2{width:50%;} .botnick3{width:50%;} .botnick4{width:50%;}   .cbotnick{width:80%;}        .chooseavatar{width:80%;}        .broadcastbtn{width:20%;},.broadcastbtn input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .msgbtn{width:20%;}        .answerbtn{width:20%;}        .report{width:40%;} .0xbE{width:40%;}  .dupejoin{width:40%;}      .kickall{width:40%;}        .jump{width:40%;}        .exit{width:40%;}        .rejoin{width:40%;}        .active-afk{width:40%;}        .acceptdraw1{width:40%;}        .acceptdraw2{width:40%;}        .tips{width:40%;}        .autoreport input[type=checkbox]{margin-top:32px}        .autoskip{margin-top:32px;}        .antikick{margin-top:32px;}        .antiafk{margin-top:32px;}        .autokick{margin-top:32px;}        .about{position:absolute;left:20px;top:-3px;width:10%}        .roomconsole{margin-top:3px; text-align:left; color:#FFD700; font-size:17px;}        .roomtheme{margin-top:3px; text-align:left; color:#FFD700; font-size:17px;}.switch {  position: relative;  display: block;  width: 60px;  height: 34px;}.switch input {  opacity: 0;  width: 0;  height: 0;}.slider {  position: absolute;  cursor: pointer;  top: 0;  left: 0;  right: 0;  bottom: 0;  background-color: #ccc;  -webkit-transition: .1s;  transition: .1s;}.slider:before {  position: absolute;  content: "";  height: 26px;  width: 26px;  left: 4px;  bottom: 4px;  background-color: white;  -webkit-transition: .1s;  transition: .1s;}input:checked + .slider {  background-color: #FFD700;}input:focus + .slider {  box-shadow: 0 0 1px #FFD700;}input:checked + .slider:before {  -webkit-transform: translateX(26px);  -ms-transform: translateX(26px);  transform: translateX(26px);}/* Rounded sliders */.slider.round {  border-radius: 34px;}.slider.round:before {  border-radius: 50%;}        .colorthemesbtn1{width:40%;}        .colorthemesbtn2{width:60%;}.swal2-popup.swal2-toast{flex-direction:column;align-items:stretch;width:auto;padding:1.25em;overflow-y:hidden;background:#fff;box-shadow:0 0 .625em #d9d9d9}.swal2-popup.swal2-toast .swal2-header{flex-direction:row;padding:0}.swal2-popup.swal2-toast .swal2-title{flex-grow:1;justify-content:flex-start;margin:0 .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.3125em auto;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{position:static;width:.8em;height:.8em;line-height:.8}.swal2-popup.swal2-toast .swal2-content{justify-content:flex-start;margin:0 .625em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container{padding:.625em 0 0}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-icon{width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:700}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{font-size:.25em}}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{flex:1;flex-basis:auto!important;align-self:stretch;width:auto;height:2.2em;height:auto;margin:0 .3125em;margin-top:.3125em;padding:0}.swal2-popup.swal2-toast .swal2-styled{margin:.125em .3125em;padding:.3125em .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-styled:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(100,150,200,.5)}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.8em;left:-.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-toast-animate-success-line-tip .75s;animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-toast-animate-success-line-long .75s;animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:swal2-toast-show .5s;animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:swal2-toast-hide .1s forwards;animation:swal2-toast-hide .1s forwards}.swal2-container{display:flex;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;flex-direction:row;align-items:center;justify-content:center;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:0 0!important}.swal2-container.swal2-top{align-items:flex-start}.swal2-container.swal2-top-left,.swal2-container.swal2-top-start{align-items:flex-start;justify-content:flex-start}.swal2-container.swal2-top-end,.swal2-container.swal2-top-right{align-items:flex-start;justify-content:flex-end}.swal2-container.swal2-center{align-items:center}.swal2-container.swal2-center-left,.swal2-container.swal2-center-start{align-items:center;justify-content:flex-start}.swal2-container.swal2-center-end,.swal2-container.swal2-center-right{align-items:center;justify-content:flex-end}.swal2-container.swal2-bottom{align-items:flex-end}.swal2-container.swal2-bottom-left,.swal2-container.swal2-bottom-start{align-items:flex-end;justify-content:flex-start}.swal2-container.swal2-bottom-end,.swal2-container.swal2-bottom-right{align-items:flex-end;justify-content:flex-end}.swal2-container.swal2-bottom-end>:first-child,.swal2-container.swal2-bottom-left>:first-child,.swal2-container.swal2-bottom-right>:first-child,.swal2-container.swal2-bottom-start>:first-child,.swal2-container.swal2-bottom>:first-child{margin-top:auto}.swal2-container.swal2-grow-fullscreen>.swal2-modal{display:flex!important;flex:1;align-self:stretch;justify-content:center}.swal2-container.swal2-grow-row>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-grow-column{flex:1;flex-direction:column}.swal2-container.swal2-grow-column.swal2-bottom,.swal2-container.swal2-grow-column.swal2-center,.swal2-container.swal2-grow-column.swal2-top{align-items:center}.swal2-container.swal2-grow-column.swal2-bottom-left,.swal2-container.swal2-grow-column.swal2-bottom-start,.swal2-container.swal2-grow-column.swal2-center-left,.swal2-container.swal2-grow-column.swal2-center-start,.swal2-container.swal2-grow-column.swal2-top-left,.swal2-container.swal2-grow-column.swal2-top-start{align-items:flex-start}.swal2-container.swal2-grow-column.swal2-bottom-end,.swal2-container.swal2-grow-column.swal2-bottom-right,.swal2-container.swal2-grow-column.swal2-center-end,.swal2-container.swal2-grow-column.swal2-center-right,.swal2-container.swal2-grow-column.swal2-top-end,.swal2-container.swal2-grow-column.swal2-top-right{align-items:flex-end}.swal2-container.swal2-grow-column>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-no-transition{transition:none!important}.swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)>.swal2-modal{margin:auto}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-container .swal2-modal{margin:0!important}}.swal2-popup{display:none;position:relative;box-sizing:border-box;flex-direction:column;justify-content:center;width:32em;max-width:100%;padding:1.25em;border:none;border-radius:5px;background:#fff;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-header{display:flex;flex-direction:column;align-items:center;padding:0 1.8em}.swal2-title{position:relative;max-width:100%;margin:0 0 .4em;padding:0;color:#595959;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:100%;margin:1.25em auto 0;padding:0}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-loader{display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 transparent #2778c4 transparent}.swal2-styled{margin:.3125em;padding:.625em 1.1em;box-shadow:none;font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#2778c4;color:#fff;font-size:1em}.swal2-styled.swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#d14529;color:#fff;font-size:1em}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#757575;color:#fff;font-size:1em}.swal2-styled:focus{outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1.25em 0 0;padding:1em 0 0;border-top:1px solid #eee;color:#545454;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;height:.25em;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:1.25em auto}.swal2-close{position:absolute;z-index:2;top:0;right:0;align-items:center;justify-content:center;width:1.2em;height:1.2em;padding:0;overflow:hidden;transition:color .1s ease-out;border:none;border-radius:5px;background:0 0;color:#ccc;font-family:serif;font-size:2.5em;line-height:1.2;cursor:pointer}.swal2-close:hover{transform:none;background:0 0;color:#f27474}.swal2-close:focus{outline:0;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}.swal2-close::-moz-focus-inner{border:0}.swal2-content{z-index:1;justify-content:center;margin:0;padding:0 1.6em;color:#545454;font-size:1.125em;font-weight:400;line-height:normal;text-align:center;word-wrap:break-word}.swal2-checkbox,.swal2-file,.swal2-input,.swal2-radio,.swal2-select,.swal2-textarea{margin:1em auto}.swal2-file,.swal2-input,.swal2-textarea{box-sizing:border-box;width:100%;transition:border-color .3s,box-shadow .3s;border:1px solid #d9d9d9;border-radius:.1875em;background:inherit;box-shadow:inset 0 1px 1px rgba(0,0,0,.06);color:inherit;font-size:1.125em}.swal2-file.swal2-inputerror,.swal2-input.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-file:focus,.swal2-input:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-file::-moz-placeholder,.swal2-input::-moz-placeholder,.swal2-textarea::-moz-placeholder{color:#ccc}.swal2-file:-ms-input-placeholder,.swal2-input:-ms-input-placeholder,.swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-file::placeholder,.swal2-input::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em auto;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-input[type=number]{max-width:10em}.swal2-file{background:inherit;font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:inherit;color:inherit;font-size:1.125em}.swal2-checkbox,.swal2-radio{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-checkbox label,.swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-checkbox input,.swal2-radio input{flex-shrink:0;margin:0 .4em}.swal2-input-label{display:flex;justify-content:center;margin:1em auto}.swal2-validation-message{align-items:center;justify-content:center;margin:0 -2.7em;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:1.25em auto 1.875em;border:.25em solid transparent;border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-.25em;left:-.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:0 0 1.25em;padding:0;background:inherit;font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{right:auto;left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@supports (-ms-accelerator:true){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@-webkit-keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@-webkit-keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@-webkit-keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@-webkit-keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-container{top:auto;right:auto;bottom:auto;left:auto;max-width:calc(100% - .625em * 2);background-color:transparent!important}body.swal2-no-backdrop .swal2-container>.swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}body.swal2-no-backdrop .swal2-container.swal2-top{top:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-top-left,body.swal2-no-backdrop .swal2-container.swal2-top-start{top:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-top-end,body.swal2-no-backdrop .swal2-container.swal2-top-right{top:0;right:0}body.swal2-no-backdrop .swal2-container.swal2-center{top:50%;left:50%;transform:translate(-50%,-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-left,body.swal2-no-backdrop .swal2-container.swal2-center-start{top:50%;left:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-end,body.swal2-no-backdrop .swal2-container.swal2-center-right{top:50%;right:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom{bottom:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom-left,body.swal2-no-backdrop .swal2-container.swal2-bottom-start{bottom:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-bottom-end,body.swal2-no-backdrop .swal2-container.swal2-bottom-right{right:0;bottom:0}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static!important}}body.swal2-toast-shown .swal2-container{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}`);addHtml(`<div class="userlist" style="display:none">    <div class="userkickmenu"></div>    <input type="submit" style="width:90px; background:red" onclick="window.postMessage('kickall','*')" value="KICK ALL">        <input type="checkbox" class="kickonjoin">&nbsp;Kick on join<br>        <input type="checkbox" class="kickallwhenjoin">&nbsp;Kick when join<hr>    </div>    <div class="option">    <button class="hidemenu" onclick="window.postMessage('hidemenu','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></button>    <button class="menu1" onclick="window.postMessage('menu1','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>    <button class="menu2" onclick="window.postMessage('menu2','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 9v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9"/><path d="M9 22V12h6v10M2 10.6L12 2l10 8.6"/></svg></button>    <button class="menu3" onclick="window.postMessage('menu3','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></button>    <button class="menu4" onclick="window.postMessage('menu4','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="8" x2="23" y2="13"></line><line x1="23" y1="8" x2="18" y2="13"></line></svg></button>    <button class="menu5" onclick="window.postMessage('menu5','*')"><span>🆕️</span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg></button>    <button class="menu6" onclick="window.postMessage('menu6','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></button>  <button class="menu7" onclick="window.postMessage('menu7','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></button>    </div>    <div id="avatarlist" class="icebot">    <input type="submit" class="hideavatarlist" onclick="window.postMessage('hideavatarlist','*')" value="CLOSE"><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/0.svg" class="selectedavatar" onclick="window.postMessage('avatar.0','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/1.svg" class="selectedavatar" onclick="window.postMessage('avatar.1','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/2.svg" class="selectedavatar" onclick="window.postMessage('avatar.2','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/3.svg" class="selectedavatar" onclick="window.postMessage('avatar.3','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/4.svg" class="selectedavatar" onclick="window.postMessage('avatar.4','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/5.svg" class="selectedavatar" onclick="window.postMessage('avatar.5','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/6.svg" class="selectedavatar" onclick="window.postMessage('avatar.6','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/7.svg" class="selectedavatar" onclick="window.postMessage('avatar.7','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/8.svg" class="selectedavatar" onclick="window.postMessage('avatar.8','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/9.svg" class="selectedavatar" onclick="window.postMessage('avatar.9','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/10.svg" class="selectedavatar" onclick="window.postMessage('avatar.10','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/11.svg" class="selectedavatar" onclick="window.postMessage('avatar.11','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/12.svg" class="selectedavatar" onclick="window.postMessage('avatar.12','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/13.svg" class="selectedavatar" onclick="window.postMessage('avatar.13','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/14.svg" class="selectedavatar" onclick="window.postMessage('avatar.14','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/15.svg" class="selectedavatar" onclick="window.postMessage('avatar.15','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/16.svg" class="selectedavatar" onclick="window.postMessage('avatar.16','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/17.svg" class="selectedavatar" onclick="window.postMessage('avatar.17','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/18.svg" class="selectedavatar" onclick="window.postMessage('avatar.18','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/19.svg" class="selectedavatar" onclick="window.postMessage('avatar.19','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/20.svg" class="selectedavatar" onclick="window.postMessage('avatar.20','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/21.svg" class="selectedavatar" onclick="window.postMessage('avatar.21','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/22.svg" class="selectedavatar" onclick="window.postMessage('avatar.22','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/23.svg" class="selectedavatar" onclick="window.postMessage('avatar.23','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/24.svg" class="selectedavatar" onclick="window.postMessage('avatar.24','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/25.svg" class="selectedavatar" onclick="window.postMessage('avatar.25','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/26.svg" class="selectedavatar" onclick="window.postMessage('avatar.26','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/27.svg" class="selectedavatar" onclick="window.postMessage('avatar.27','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/28.svg" class="selectedavatar" onclick="window.postMessage('avatar.28','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/29.svg" class="selectedavatar" onclick="window.postMessage('avatar.29','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/30.svg" class="selectedavatar" onclick="window.postMessage('avatar.30','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/31.svg" class="selectedavatar" onclick="window.postMessage('avatar.31','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/32.svg" class="selectedavatar" onclick="window.postMessage('avatar.32','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/33.svg" class="selectedavatar" onclick="window.postMessage('avatar.33','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/34.svg" class="selectedavatar" onclick="window.postMessage('avatar.34','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/35.svg" class="selectedavatar" onclick="window.postMessage('avatar.35','*')"></button></div><div class="avatarbtn"><button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/36.svg" class="selectedavatar" onclick="window.postMessage('avatar.36','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://garticphone.com/images/avatar/31.svg" class="selectedavatar" onclick="window.postMessage('avatar.null','*')"></button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/subjects/1.svg?v=1" class="selectedavatar" onclick="window.postMessage('avatar.random','*')"></button></div><br>    </div>   <div id="icebot1" style="display:none"; class="icebot">    <h2 style="color:white;">ICEbot V6  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="botnumber"></span><input type="submit" class="about" onclick="window.postMessage('info','*')" value="ⓘ"></h2>   <h2 style="color:white;">Bot amount: &nbsp;&nbsp;<span><input type="text" id="quantbot" style="width:15%" oninput="window.postMessage('quantbot','*')"  value="`+localStorage.getItem("quant")+`"><span></h2><br><h3 style="color:red;">Server Number: &nbsp;&nbsp;<span><input type="number" id="serverInput" min="1" max="9" style="width:15%;"> </span></h3><div class="roomlink"><input type="text" id="roomlink" placeholder="Room link"><input type="submit" id="join" onclick="window.postMessage('join','*')" value="JOIN"></div>    <div class="botnick"><input type="text" id="botnick" oninput="window.postMessage('nick','*')" placeholder="Bot nick" value="`+localStorage.getItem("nick")+`"></div>    <input type="submit" class="botnick0" onclick="window.postMessage('botnick0','*')" value="Bot nick 1">    <input type="submit" class="botnick1" onclick="window.postMessage('botnick1','*')" value="Bot nick 2"><input type="submit" class="botnick2" onclick="window.postMessage('botnick2','*')" value="Bot nick 3"><input type="submit" class="botnick3" onclick="window.postMessage('botnick3','*')" value="Bot nick 4"><input type="submit" class="botnick4" onclick="window.postMessage('botnick4','*')" value="Bot nick 5"><input type="submit" class="cbotnick" onclick="window.postMessage('cnickshow','*')" value="custom bot nick"><br><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/`+localStorage.getItem("avatar")+`.svg" id="avatar" class="selectedavatar">    <input type="submit" class="chooseavatar" onclick="window.postMessage('showavatarlist','*')" value="CHOOSE AVATAR">    </div>    <div id="icebot2" class="icebot" style="display:none;"><div class="broadcastbox"><input type="text" id="broadcast" placeholder="Broadcast"><button class="broadcastbtn" onclick="window.postMessage('broadcast','*')" value="Broadcast"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button><button class="msgbtn" style="width:10%" onclick="window.postMessage('broadcastspam','*')" value="Broadcast"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button></div>    <div class="msgbox"><input type="text" id="message" placeholder="Message"><button class="msgbtn" onclick="window.postMessage('chat','*')" value="Message"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button><button class="msgbtn" style="width:10%" onclick="window.postMessage('chatspam','*')" value="Message"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button></div>    <div class="answerbox"><input type="text" id="answer" placeholder="Answer"><button class="answerbtn" onclick="window.postMessage('answer','*')" value="Answer"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">  <path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button><button class="msgbtn" style="width:10%" onclick="window.postMessage('answerspam','*')" value="Answer"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button></div>    <input type="submit" class="exit" style="background:red;" onclick="window.postMessage('exit','*')" value="EXIT">    <input type="submit" class="kickall" onclick="window.postMessage('kickall','*')" value="KICK ALL">    <input type="submit" class="report" onclick="window.postMessage('report','*')" value="REPORT">    <input type="submit" class="rejoin" onclick="window.postMessage('rejoin','*')" value="REJOIN">    <input type="submit" class="jump" onclick="window.postMessage('jump','*')" value="JUMP">    <input type="submit" class="active-afk" onclick="window.postMessage('afkconfirm','*')" value="ACTIVE">  <input type="text" style="width:40%" id="word1"> <input type="text" style="width:40%" id="word2">     <input type="submit" class="acceptdraw1" onclick="window.postMessage('acceptdraw1','*')" value="DRAW 1">    <input type="submit" class="acceptdraw2" onclick="window.postMessage('acceptdraw2','*')" value="DRAW 2">    <input type="submit" class="tips" onclick="window.postMessage('tips','*')" value="TIPS"><input type="submit" class="0xbE" style="display:none;" onclick="window.postMessage('0xbE','*')" value="0xbE">  <input type="submit" class="dupejoin" onclick="window.postMessage('dupejoin','*')" value="DUPE JOIN">  <br>    <h2 class="roomconsole"></h2><span><h2 class="roomtheme"></h2></span></div>    <div id="icebot3" class="icebot">    <div class="broadcastbox"><input type="text" id="broadcastspam" placeholder="Broadcast (spam)"><button class="broadcastbtn" id="broadcaststart" onclick="window.postMessage('broadcastspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="broadcastbtn" id="broadcaststop" onclick="window.postMessage('stopbroadcast','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div>    <div class="msgbox"><input type="text" id="messagespam" placeholder="Message (spam)"><button class="msgbtn" id="msgstart" onclick="window.postMessage('chatspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="msgbtn" id="msgstop" onclick="window.postMessage('stopmsg','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div>    <div class="answerbox"><input type="text" id="answerspam" placeholder="Answer (spam)"><button class="answerbtn" id="answerstart" onclick="window.postMessage('answerspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="answerbtn" id="answerstop" onclick="window.postMessage('stopanswer','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div><h2 class="broadcastspamvalue" id="broadcastms"></h2><input class="broadcastspam" type="range" oninput="postMessage('broadcastspam')" min="1000" max="10000"><h2 class="messagespamvalue" id="messagems"></h2><input class="messagespam" type="range" oninput="postMessage('messagespam')" min="1000" max="10000"><h2 class="answerspamvalue" id="answerms"></h2><input class="answerspam" type="range" oninput="postMessage('answerspam')" min="1000" max="10000">    </div>    <div id="icebot4" class="icebot">    <h2 class="customkick">Custom kick</h2> <div class="kicklistbox">      <input type="text" id="kicklistinput" placeholder="Player name"></input>  <input type="submit" id="kicklistaddbtn" onclick="window.postMessage('customkickadd','*')" value="add"></input></div><input type="submit" id="kicklistremoveallbtn" onclick="window.postMessage('customkickremoveall','*')" value="remove all"></div>    <div id="icebot5" class="icebot"><h2 id="proxylist">Proxy list • ACTIVE</h2><input type="submit" class="report" onclick="window.postMessage('getlocation','*')" value="get location"><input type="submit" class="report" onclick="window.postMessage('refreshall','*')" value="refresh all"> </div>    <div id="icebot6" class="icebot" style="display:none;height:300px;"><h2>Options</h2>
<h2 id="swtext" style="top:40px;left:10px;position:absolute;">Auto report &nbsp;</h2><label class="switch" style="top:10px;left:150px"><input type="checkbox" id="autoreport"><span class="slider round"></span></label>
<h2 id="swtext" style="top:80px;left:10px;position:absolute;">Auto skip &nbsp;</h2><label class="switch" style="top:16px;left:150px"><input type="checkbox" id="autoskip"><span class="slider round"></span></label>
<h2 id="swtext" style="top:120px;left:10px;position:absolute;">Anti kick &nbsp;</h2><label class="switch" style="top:22px;left:150px"><input type="checkbox" id="antikick"><span class="slider round"></span></label>
<h2 id="swtext" style="top:160px;left:10px;position:absolute;">Anti afk &nbsp;</h2><label class="switch" style="top:28px;left:150px"><input type="checkbox" id="antiafk"><span class="slider round"></span></label>
<h2 id="swtext" style="top:200px;left:10px;position:absolute;">Auto kick &nbsp;</h2><label class="switch" style="top:34px;left:150px"><input type="checkbox" id="autokick"><span class="slider round"></span></label>
<h2 id="swtext" style="top:240px;left:10px;position:absolute;">Auto farm &nbsp;</h2><label class="switch" style="top:40px;left:150px"><input type="checkbox" id="autofarm"><span class="slider round"></span></label>
<h2 id="swtext" style="top:280px;left:10px;position:absolute;">Auto guess &nbsp;</h2><label class="switch" style="top:46px;left:150px"><input type="checkbox" id="autoguess" onchange="window.postMessage('autoguess','*')"><span class="slider round"></span></label><h2 class="autoguessvalue" id="autoguessms" style="top:320px;position:absolute;"></h2><input class="autoguessrange" style="top:360px;left:60px;position:absolute;" type="range" oninput="postMessage('autoguess')" min="130" max="10000">
<h2 id="swtext" style="top:390px;left:10px;position:absolute;">Mimic mode &nbsp;</h2><label class="switch" style="top:120px;left:150px"><input type="checkbox" id="mimicmode" onchange="window.postMessage('mimicmode','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:430px;left:10px;position:absolute;">Rainbow draw &nbsp;</h2><label class="switch" style="top:126px;left:150px"><input type="checkbox" id="rainbowdraw" onchange="window.postMessage('rainbowdraw','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:470px;left:10px;position:absolute;">Give answer &nbsp;</h2><label class="switch" style="top:132px;left:150px"><input type="checkbox" id="giveanswer" onchange="window.postMessage('giveanswer','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:510px;left:10px;position:absolute;">Auto rejoin &nbsp;</h2><label class="switch" style="top:138px;left:150px"><input type="checkbox" id="autorejoin" onchange="window.postMessage('autorejoin','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:550px;left:10px;position:absolute;">Kick all (join) &nbsp;</h2><label class="switch" style="top:144px;left:150px"><input type="checkbox" id="kickalljoin" onchange="window.postMessage('kickalljoin','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:590px;left:10px;position:absolute;">Kick on join &nbsp;</h2><label class="switch" style="top:150px;left:150px"><input type="checkbox" id="kickonjoin" onchange="window.postMessage('kickonjoin','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:630px;left:10px;position:absolute;">All command &nbsp;</h2><label class="switch" style="top:156px;left:150px"><input type="checkbox" id="allcommand" onchange="window.postMessage('allcommand','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:670px;left:10px;position:absolute;">Auto tips &nbsp;</h2><label class="switch" style="top:162px;left:150px"><input type="checkbox" id="autotips" onchange="window.postMessage('autotips','*')"><span class="slider round"></span></label>
<h2 id="swtext" style="top:710px;left:10px;position:absolute;">Join spam (3s)&nbsp;</h2><label class="switch" style="top:168px;left:150px"><input type="checkbox" id="joinspam" onchange="window.postMessage('joinspam','*')"><span class="slider round"></span></label>
<h2 style="top:870px;left:50px;position:absolute;">GUI theme color</h2>
    <input type="submit" style="top:900px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.red','*')" value="RED">
    <input type="submit" style="top:900px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.orange','*')" value="ORANGE">
    <input type="submit" style="top:940px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.yellow','*')" value="YELLOW">
    <input type="submit" style="top:940px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.green','*')" value="GREEN">
    <input type="submit" style="top:980px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.blue','*')" value="BLUE">
    <input type="submit" style="top:980px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.indigo','*')" value="INDIGO">
    <input type="submit" style="top:1020px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.violet','*')" value="VIOLET">
    <input type="submit" style="top:1020px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.pink','*')" value="PINK">
    <input type="submit" style="top:1060px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.crimson','*')" value="CRIMSON">
    <input type="submit" style="top:1060px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.brown','*')" value="BROWN">
    <input type="submit" style="top:1100px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.gray','*')" value="GRAY">
    <input type="submit" style="top:1100px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.white','*')" value="WHITE">
    <input type="submit" style="top:1140px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.black','*')" value="BLACK">
    <input type="submit" style="top:1140px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.magenta','*')" value="MAGENTA">
    <input type="submit" style="top:1180px;left:50px;position:absolute;" class="colorthemesbtn2" onclick="javascript:location.reload();localStorage.removeItem('theme')" value="RESET THEME">
    <h2 style="top:1220px;left:70px;position:absolute;">User options</h2>

<h2 id="swtext" style="top:1250px;left:10px;position:absolute;">Auto guess &nbsp;</h2><label class="switch" style="top:675px;left:150px"><input type="checkbox" id="autoguessplayer" onchange="window.postMessage('autoguessp','*')"><span class="slider round"></span></label><h2 class="autoguessvalueplayer" id="autoguessmsplayer" style="top:1320px;position:absolute;"></h2><input class="autoguessrangeplayer" style="top:1285px;left:60px;position:absolute;" type="range" oninput="postMessage('autoguessplayer')" min="130" max="10000">
<input type="file" id="wordlist" style="top:1330px;left:50px;position:absolute;display:none;" onchange="window.postMessage('wordlist','*')" value="add new word list">
</div>
<div id="cavatarlist" class="icebot">    <input type="submit" class="hidecavatarlist" onclick="window.postMessage('hidecavatarlist','*')" value="CLOSE"><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/0.svg" class="selectedavatar" onclick="window.postMessage('cavt.0','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/1.svg" class="selectedavatar" onclick="window.postMessage('cavt.1','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/2.svg" class="selectedavatar" onclick="window.postMessage('cavt.2','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/3.svg" class="selectedavatar" onclick="window.postMessage('cavt.3','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/4.svg" class="selectedavatar" onclick="window.postMessage('cavt.4','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/5.svg" class="selectedavatar" onclick="window.postMessage('cavt.5','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/6.svg" class="selectedavatar" onclick="window.postMessage('cavt.6','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/7.svg" class="selectedavatar" onclick="window.postMessage('cavt.7','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/8.svg" class="selectedavatar" onclick="window.postMessage('cavt.8','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/9.svg" class="selectedavatar" onclick="window.postMessage('cavt.9','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/10.svg" class="selectedavatar" onclick="window.postMessage('cavt.10','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/11.svg" class="selectedavatar" onclick="window.postMessage('cavt.11','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/12.svg" class="selectedavatar" onclick="window.postMessage('cavt.12','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/13.svg" class="selectedavatar" onclick="window.postMessage('cavt.13','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/14.svg" class="selectedavatar" onclick="window.postMessage('cavt.14','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/15.svg" class="selectedavatar" onclick="window.postMessage('cavt.15','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/16.svg" class="selectedavatar" onclick="window.postMessage('cavt.16','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/17.svg" class="selectedavatar" onclick="window.postMessage('cavt.17','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/18.svg" class="selectedavatar" onclick="window.postMessage('cavt.18','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/19.svg" class="selectedavatar" onclick="window.postMessage('cavt.19','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/20.svg" class="selectedavatar" onclick="window.postMessage('cavt.20','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/21.svg" class="selectedavatar" onclick="window.postMessage('cavt.21','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/22.svg" class="selectedavatar" onclick="window.postMessage('cavt.22','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/23.svg" class="selectedavatar" onclick="window.postMessage('cavt.23','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/24.svg" class="selectedavatar" onclick="window.postMessage('cavt.24','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/25.svg" class="selectedavatar" onclick="window.postMessage('cavt.25','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/26.svg" class="selectedavatar" onclick="window.postMessage('cavt.26','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/27.svg" class="selectedavatar" onclick="window.postMessage('cavt.27','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/28.svg" class="selectedavatar" onclick="window.postMessage('cavt.28','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/29.svg" class="selectedavatar" onclick="window.postMessage('cavt.29','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/30.svg" class="selectedavatar" onclick="window.postMessage('cavt.30','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/31.svg" class="selectedavatar" onclick="window.postMessage('cavt.31','*')"></button></div><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/32.svg" class="selectedavatar" onclick="window.postMessage('cavt.32','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/33.svg" class="selectedavatar" onclick="window.postMessage('cavt.33','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/34.svg" class="selectedavatar" onclick="window.postMessage('cavt.34','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/35.svg" class="selectedavatar" onclick="window.postMessage('cavt.35','*')"></button></div><div class="avatarbtn"><button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/36.svg" class="selectedavatar" onclick="window.postMessage('cavt.36','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://garticphone.com/images/avatar/31.svg" class="selectedavatar" onclick="window.postMessage('cavt.null','*')"></button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/subjects/1.svg?v=1" class="selectedavatar" onclick="window.postMessage('cavt.random','*')"></button></div><br>    </div>  
    <div id="custombotnick" style="display:none;" class="icebot">    <img onclick="window.postMessage('customavatar','*')" id="cavatar" width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/`+localStorage.getItem("cavatar")+`.svg" ><div id="cstbtn" class="icebotbtn"><button onclick="window.postMessage('cnickclose','*')" style="width:15%;top:5px;left:5px;position:absolute;">CLOSE</button><button onclick="window.postMessage('cnickenable','*')" style="width:15%;top:5px;left:60px;position:absolute;">ENABLE</button><input type="text" id="customnick" maxlength="18" style="width:45%;" placeholder="Set custom nick here..."></input><button onclick="window.postMessage('customavatar','*')">AVATAR</button>&nbsp;&nbsp;&nbsp;&nbsp;<button onclick="window.postMessage('setcustomnick','*')" style="width:16%">SET</button>
</div></div>
<div class="icebot" id="icebot7" style="display:none;"><h2 class="msgjointext">Message when join</h2> 
<input type="text" placeholder="Message..." id="msgjoin" style="width:100%"></input><input type="submit" onclick="window.postMessage('msgjoin.broadcast','*')" style="width:33.3%" value="Broadcast"></input><input type="submit" onclick="window.postMessage('msgjoin.message','*')" style="width:33.3%" value="Message"></input><input type="submit" onclick="window.postMessage('msgjoin.answer','*')" style="width:33.3%" value="Answer"></input>
<hr>
<h3>Bot Control Panel</h3>
<div class="bot-selection">
  <select id="botSelector" style="width:100%; margin-bottom:10px;">
    <option value="">Select a bot</option>
  </select>
</div>
<div class="control-panel">
  <input type="text" id="botChatMessage" placeholder="Chat message" style="width:70%;">
  <button onclick="window.postMessage('sendBotChat','*')">Send Chat</button>
  <input type="text" id="botAnswerMessage" placeholder="Answer" style="width:70%; margin-top:5px;">
  <button onclick="window.postMessage('sendBotAnswer','*')" style="margin-top:5px;">Send Answer</button>
  <br>
  <button onclick="window.postMessage('sendBotExit','*')" style="margin-top:5px;">Exit</button>
</div>
</div>

`);

let avataritem = localStorage.getItem("avatar");
if (!avataritem) {
  localStorage.setItem("avatar", 1);
  avatar=1
}
        if (avataritem=='null') {setTimeout(()=>{
f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";},1000)
                                }
        if (avataritem=='random') {setTimeout(()=>{
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";},1000)
                                }
                                
    let customkick = localStorage.getItem("customkick");
if (!customkick) {
  localStorage.setItem("customkick", "[]");
}

if (customkick) {
    let list=JSON.parse(localStorage.getItem("customkick"))

        list.forEach(user=>{
            setTimeout(()=>{
        f("#icebot4").innerHTML+=`<h2 class="customkick" id="customkick.`+user.user+`">`+user.user+`</h2>
    <input type="submit" class="customkickremove" id="customkickuser.`+user.user+`" onclick="window.postMessage('customkickremove.`+user.user+`','*')" value="remove">`

            },3000)
        })
}
     let botnickitem = localStorage.getItem("botnick");
if (!botnickitem) {
  localStorage.setItem("botnick", "0");
}
     let botsv = localStorage.getItem("bots");
if (!botsv) {
  localStorage.setItem("bots", '[{"link": "108.181.21.229"},{"link": "108.181.33.135"},{"link": "108.181.33.117"},{"link": "108.181.33.119"},{"link": "108.181.34.57"},{"link": "108.181.34.71"},{"link": "108.181.30.85"},{"link": "108.181.34.149"},{"link": "108.181.32.49"},{"link": "108.181.32.73"},{"link": "108.181.32.55"},{"link": "108.181.32.61"},{"link": "108.181.32.59"},{"link": "108.181.43.67"},{"link": "108.181.34.45"},{"link": "108.181.24.243"},{"link": "108.181.34.177"},{"link": "108.181.34.157"},{"link": "195.3.223.166"},{"link": "195.3.223.164"},{"link": "146.19.24.89"},{"link": "195.3.222.15"},{"link": "185.16.39.161"},{"link": "95.214.53.145"},{"link": "95.214.53.152"},{"link": "108.181.8.179"},{"link": "108.181.9.39"},{"link": "108.181.11.39"},{"link": "108.181.6.89"},{"link": "208.87.240.203"},{"link": "208.87.240.219"},{"link": "208.87.240.251"},{"link": "208.87.241.149"},{"link": "108.181.4.237"},{"link": "208.87.241.209"},{"link": "108.181.4.241"},{"link": "208.87.240.35"},{"link": "108.181.5.29"},{"link": "208.87.242.233"},{"link": "208.87.240.67"},{"link": "95.214.53.48"},{"link": "195.3.222.40"},{"link": "185.225.191.49"},{"link": "185.225.191.57"},{"link": "108.181.11.173"},{"link": "108.181.11.193"},{"link": "108.181.11.137"},{"link": "108.181.11.171"},{"link": "108.181.11.175"},{"link": "185.16.39.144"},{"link": "185.16.39.213"},{"link": "178.211.139.238"},{"link": "185.246.84.18"},{"link": "185.246.84.66"},{"link": "108.181.90.163"},{"link": "108.181.90.129"},{"link": "208.87.241.75"},{"link": "199.71.214.121"},{"link": "108.181.5.31"},{"link": "108.181.54.41"},{"link": "185.246.87.210"},{"link": "95.214.53.28"},{"link": "185.246.85.103"},{"link": "195.3.223.101"},{"link": "185.246.85.105"},{"link": "195.3.220.223"},{"link": "185.16.38.230"},{"link": "146.19.24.59"},{"link": "195.3.220.74"},{"link": "108.181.88.29"},{"link": "108.181.88.105"},{"link": "108.181.88.107"},{"link": "199.71.214.89"},{"link": "185.246.86.208"},{"link": "185.246.87.7"},{"link": "185.246.86.211"},{"link": "95.214.53.33"}]');
}
if(botsv){
	document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length
let botsp=JSON.parse(botsv);
	botsp.forEach(x=>{
	document.querySelector("#icebot5").innerHTML += `<input type="submit" style="width:100%; height:40px; position: relative; font-weight: bold;" id="proxy-`+x.link+`" onclick="window.postMessage('proxyrmv.`+x.link+`','*')" value="`+x.link+`">`;})
	}
	 let msgjoin = localStorage.getItem("messagejoin");
if (!msgjoin) {
  localStorage.setItem("messagejoin", "[]");
}

if (msgjoin) {
	let es=JSON.parse(msgjoin);
	es.forEach(d=>{
document.querySelector("#icebot7").innerHTML += `
<h2 class="msgjoinvalue" id="msgjoinvalue.${d.msg}">${d.type} : ${d.msg}</h2>
<input type="submit" class="msgjoinremove" id="msgjoin.${d.msg}" onclick="window.postMessage('messagejoinremove.${d.msg}','*')" value="remove">
`;})
  
}
	let cbotnickitems= localStorage.getItem("custom-nicks");
if (!cbotnickitems) {
  localStorage.setItem("custom-nicks", "[]");
}
if (cbotnickitems) {
	let xm=JSON.parse(cbotnickitems);
	xm.forEach(e=>{
	    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;" id="custom-`+e.nick+`" onclick="window.postMessage('cbtnrmv.`+e.nick+`','*')">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+e.avatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+e.nick+`</span>
</button>
`;})
}
     let nickitem = localStorage.getItem("nick");
if (!nickitem) {
  localStorage.setItem("nick", "ICEbot");
}
     let quantitem = localStorage.getItem("quant");
if (!quantitem) {
  localStorage.setItem("quant", 15);
}
     let theme = localStorage.getItem("theme");
if (theme) {setTimeout(()=>{colorChanger(theme)},300)
}
     window.addEventListener("message",function(msg){
        if(typeof(msg.data)==="string"){
        	    if(msg.data=="hidemenu"){setmenu('none')}
    if(msg.data=="menu1"){setmenu('icebot1')}
    if(msg.data=="menu2"){setmenu('icebot2')}
    if(msg.data=="menu3"){setmenu('icebot3')}
    if(msg.data=="menu4"){setmenu('icebot4')}
    if(msg.data=="menu5"){setmenu('icebot5')}
    if(msg.data=="menu6"){setmenu('icebot6')}
    if(msg.data=="menu7"){setmenu('icebot7')}

    if(msg.data.indexOf("color.")!=-1){
 let color = event.data.split("color.")[1];localStorage.setItem("theme",color)
                colorChanger(color)
            }
                        if(msg.data=="quantbot"){
            localStorage.setItem("quant",f("#quantbot").value)

    }
            if(msg.data=="nick"){
            localStorage.setItem("nick",f("#botnick").value)

    }
        if(msg.data=="botnick0"){
botnick=0
localStorage.setItem("botnick",0)
}
if(msg.data=="botnick1"){
botnick=1
localStorage.setItem("botnick",1)
    }
    
if(msg.data=="botnick2"){
botnick=2
localStorage.setItem("botnick",2)
    }
    if(msg.data=="botnick3"){
botnick=4
localStorage.setItem("botnick",4)
    }
    if(msg.data=="botnick4"){
botnick=5
localStorage.setItem("botnick",5)
    }
    if(msg.data=="showavatarlist"){
        f("#icebot1").style.display="none"
        f("#avatarlist").style.display="block"
    }
    if(msg.data=="hideavatarlist"){
        f("#icebot1").style.display="block"
        f("#avatarlist").style.display="none"
    }
                if(msg.data.indexOf("proxyrmv.")!=-1){
 let proxym = msg.data.substring(9);
let storage = JSON.parse(localStorage.getItem("bots"));
if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].link === proxym) {
      storage.splice(i, 1);
          setTimeout(()=>{document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length},70)
      break;
    }
  }
  localStorage.setItem("bots", JSON.stringify(storage));
}
      let proxyel= document.getElementById("proxy-"+proxym)
      proxyel.remove()
            }

 if(msg.data.indexOf("avatar.")!=-1){
                let a=msg.data.split("avatar.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#avatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
avatar=a
localStorage.setItem("avatar",a)
    break;
    case 'null':

f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";
    avatar=null
localStorage.setItem("avatar",null)
break;
    case 'random':
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
    avatar='random'
localStorage.setItem("avatar",'random')
        break
            }}
                if(msg.data.indexOf("cavt.")!=-1){
                let a=msg.data.split("cavt.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#cavatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
localStorage.setItem("cavatar",a)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    break;
    case 'null':

f("#cavatar").src = "https://garticphone.com/images/avatar/31.svg";
localStorage.setItem("cavatar",null)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
break;
    case 'random':
f("#cavatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
localStorage.setItem("cavatar",'random')
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
        break
            }}
                if (msg.data === 'cnickenable') {
          	localStorage.setItem("botnick",3)
                	}
    if (msg.data === 'setcustomnick') {
    	let cavatar=parseInt(localStorage.getItem("cavatar"))
    	let cnick=document.querySelector("#customnick").value
let customnicks = JSON.parse(localStorage.getItem("custom-nicks")) || [];
if (!customnicks.some(i => i.nick === cnick)) {
    customnicks.push({
        avatar: cavatar,
        nick: cnick,
        isenabled: true
    });
    }
    localStorage.setItem('custom-nicks', JSON.stringify(customnicks));
    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;" id="custom-`+cnick+`" onclick="window.postMessage('cbtnrmv.`+cnick+`','*')">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+cavatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+cnick+`</span>
</button>
`;
}
    	
        if (msg.data === 'customavatar') {
        	document.querySelector('#cavatarlist').style.display='block';document.querySelector('#custombotnick').style.display='none'
        	}
        
    if(msg.data=="hidecavatarlist"){
        	document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    }
        if(msg.data=="cnickclose"){
        	document.querySelector('#custombotnick').style.display='none';
    }
        if(msg.data=="cnickshow"){
        	document.querySelector('#custombotnick').style.display='block';
    }
                if(msg.data.indexOf("cbtnrmv.")!=-1){
                let abtn=msg.data.split("cbtnrmv.")[1]
                let storage = JSON.parse(localStorage.getItem("custom-nicks"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].nick === abtn) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("custom-nicks", JSON.stringify(storage));
 document.getElementById('custom-'+abtn).remove();
}
}
                if(msg.data=="getlocation"){var ifrm = document.createElement("iframe"); ifrm.setAttribute("src", "https://croxyproxy.rocks/?proxyset"); ifrm.style.width = "100px"; ifrm.style.height = "180px";ifrm.style.display = "none"; document.body.appendChild(ifrm);var ifrm2 = document.createElement("iframe"); ifrm2.setAttribute("src", "https://proxyium.com/?2proxyset"); ifrm2.style.width = "100px"; ifrm2.style.height = "180px";ifrm2.style.display = "none"; document.body.appendChild(ifrm2);
                setTimeout(()=>{
     window.postMessage('proxyactive','*');
                	},10000)
}
                if(msg.data=="refreshall"){
             let bx = localStorage.getItem("bots");
             let ba = JSON.parse(bx);
             
let bots = ba.filter(item => ![
        {link: "185.246.87.210"},
        {link: "95.214.53.28"},
        {link: "185.246.85.103"},
        {link: "195.3.223.101"},
        {link: "185.246.85.105"},
        {link: "195.3.220.223"},
        {link: "185.16.38.230"},
        {link: "146.19.24.59"},
        {link: "195.3.220.74"}
    ].find(obj => obj.link === item.link)
);

let bots2 = ba.filter(item => [
    {link: "185.246.87.210"},
    {link: "95.214.53.28"},
    {link: "185.246.85.103"},
    {link: "195.3.223.101"},
    {link: "185.246.85.105"},
    {link: "195.3.220.223"},
    {link: "185.16.38.230"},
    {link: "146.19.24.59"},
    {link: "195.3.220.74"}
].find(obj => obj.link === item.link));

chrome.storage.local.get("locationValue2",function(e){let lc=e.locationValue2
bots2.forEach(b=>{fetch("https://"+b.link+"/"+lc, {
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
})})})
chrome.storage.local.get("locationValue",function(e){let lc=e.locationValue
bots.forEach(b=>{fetch("https://"+b.link+"/"+lc, {
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
})})});
}
        if(msg.data=="autoguess"){
        let autoguessMS=f(".autoguessrange").value
        f("#autoguessms").innerText='AUTO GUESS VALUE: ' + autoguessMS
        localStorage.setItem("autoguess",autoguessMS)
        }
                if(msg.data=="mimicmode"){if(document.querySelector("#mimicmode").checked){localStorage.setItem("mimic",'true')} else {localStorage.setItem("mimic",'false') }}
                if(msg.data.indexOf("kickuser.")!=-1){
 let id = event.data.split("kickuser.")[1];
 __0x70("kick",id)
            }
if(msg.data=="broadcast"){
__0x70("broadcast",document.querySelector("#broadcast").value)
        }
if(msg.data=="broadcastspam"){
__0x70("broadcastspam",document.querySelector("#broadcast").value)
        }
        if(msg.data=="chat"){
__0x70("msg",document.querySelector("#message").value)
        }
 if(msg.data.indexOf("chatx.")!=-1){
                let a=msg.data.split("chatx.")[1]
__0x70("msg",a)
        }
        if(msg.data=="chatspam"){
__0x70("msgspam",document.querySelector("#message").value)
        }
        if(msg.data=="answer"){
__0x70("answer",document.querySelector("#answer").value)
        }
 if(msg.data.indexOf("answerx.")!=-1){
                let a=msg.data.split("answerx.")[1]
__0x70("answer",a)
        }
        if(msg.data=="answerspam"){
__0x70("answerspam",document.querySelector("#answer").value)
        }
                    if(msg.data=="broadcastspamtoggle"){
            let broadcastspamMS=parseInt(localStorage.getItem("broadcastspam"))
            var broadcastspam = document.querySelector("#broadcastspam").value
            intervalbroadcast=setInterval(()=>{
                __0x70("broadcastspam",broadcastspam)
            },broadcastspamMS)
        document.querySelector("#broadcaststart").style.display="none"
        document.querySelector("#broadcaststop").style.display="block"
        }
        if(msg.data=="chatspamtoggle"){
            let messagespamMS=parseInt(localStorage.getItem("messagespam"))
            var messagespam = document.querySelector("#messagespam").value
            intervalmsg=setInterval(()=>{
            var chatspam = document.querySelector("#messagespam").value
                __0x70("msgspam",chatspam)
            },messagespamMS)
        document.querySelector("#msgstart").style.display="none"
        document.querySelector("#msgstop").style.display="block"
        }
        if(msg.data=="answerspamtoggle"){
            let answerspamMS=parseInt(localStorage.getItem("answerspam"))
            var answerspam = document.querySelector("#answerspam").value
            intervalanswer=setInterval(()=>{
            var answerspam = document.querySelector("#answerspam").value
                __0x70("answerspam",answerspam)
            },answerspamMS)
        document.querySelector("#answerstart").style.display="none"
        document.querySelector("#answerstop").style.display="block"
        }
        if(msg.data=="stopbroadcast"){
        clearInterval(intervalbroadcast)
        document.querySelector("#broadcaststart").style.display="block"
        document.querySelector("#broadcaststop").style.display="none"
        }
        if(msg.data=="stopmsg"){
        clearInterval(intervalmsg)
        document.querySelector("#msgstart").style.display="block"
        document.querySelector("#msgstop").style.display="none"
        }
        if(msg.data=="stopanswer"){
        clearInterval(intervalanswer)
        document.querySelector("#answerstart").style.display="block"
        document.querySelector("#answerstop").style.display="none"
        }
             if(msg.data=="broadcastspam"){
        let broadcastspamMS=document.querySelector(".broadcastspam").value
        f("#broadcastms").innerText='BROADCAST SPAM VALUE: ' + broadcastspamMS
        localStorage.setItem("broadcastspam",broadcastspamMS)
    }
    if(msg.data=="messagespam"){
        let messagespamMS=document.querySelector(".messagespam").value
        f("#messagems").innerText='MESSAGE SPAM VALUE: ' + messagespamMS
        localStorage.setItem("messagespam",messagespamMS)
    }
    if(msg.data=="answerspam"){
        let answerspamMS=document.querySelector(".answerspam").value
        f("#answerms").innerText='ANSWER SPAM VALUE: ' + answerspamMS
        localStorage.setItem("answerspam",answerspamMS)
    }
      if(msg.data=="customkickadd"){
 const value = f("#kicklistinput").value;
var customkicklist = localStorage.getItem("customkick");

  let customkickitem = JSON.parse(localStorage.getItem("customkick"));
  if (customkickitem.findIndex(item => item.user === value) === -1) {
    customkickitem.push({ "user": value });
    localStorage.setItem("customkick", JSON.stringify(customkickitem));
    f("#icebot4").innerHTML += `<h2 class="customkick" id="customkick.` + value + `">` + value + `</h2>
    <input type="submit" class="customkickremove" id="customkickuser.` + value + `" onclick="window.postMessage('customkickremove.` + value + `','*')" value="remove"></input>`
  }

        }
                    if(msg.data.indexOf("customkickremove.")!=-1){
 let usernick = event.data.split("customkickremove.")[1];
let storage = JSON.parse(localStorage.getItem("customkick"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].user === usernick) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("customkick", JSON.stringify(storage));
      let kickusertext= document.getElementById("customkick."+usernick)
      let kickuserremovebtn= document.getElementById("customkickuser."+usernick)
      kickusertext.remove()
      kickuserremovebtn.remove()
}}
        if(msg.data=="customkickremoveall"){
var elementsCustomKick = document.querySelectorAll('[id*="customkick."]');
var elementsCustomKickUser = document.querySelectorAll('[id*="customkickuser."]');
function deleteElement(element) {
  element.parentNode.removeChild(element);
}
elementsCustomKick.forEach(function(element) {
  deleteElement(element);
});
elementsCustomKickUser.forEach(function(element) {
  deleteElement(element);

})
      localStorage.setItem("customkick","[]")
      
        }
    if(msg.data.indexOf("msgjoin.")!=-1){ 	
                let xmd=msg.data.split("msgjoin.")[1]
 const value = document.querySelector("#msgjoin").value;
var messagelist = localStorage.getItem("messagejoin");

  let custommsgitem = JSON.parse(localStorage.getItem("messagejoin"));

    custommsgitem.push({ "msg": value ,"type":xmd});
    localStorage.setItem("messagejoin", JSON.stringify(custommsgitem));
document.querySelector("#icebot7").innerHTML += `
<h2 class="msgjoinvalue" id="msgjoinvalue.${value}">${xmd} : ${value}</h2>
<input type="submit" class="msgjoinremove" id="msgjoin.${value}" onclick="window.postMessage('messagejoinremove.${value}','*')" value="remove">
`;
  

    }
      if(msg.data.indexOf("messagejoinremove.")!=-1){
 let message = msg.data.split("messagejoinremove.")[1];
let storage = JSON.parse(localStorage.getItem("messagejoin"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].msg === message) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("messagejoin", JSON.stringify(storage));
}
      let msgjointext= document.getElementById("msgjoinvalue."+message)
      let msgjoinremovebtn= document.getElementById("msgjoin."+message)
      msgjointext.remove()
      msgjoinremovebtn.remove()

       }
   if(msg.data=="dupejoin"){window.postMessage('join','*');fetch("https://gartic.io/favicon.ico?rjoin=1")}
    if(msg.data=="join"){__0x70("join",document.querySelector("#roomlink").value.split("/")[3],document.querySelector("#botnick").value,avatar,localStorage.getItem("botnick"),localStorage.getItem("custom-nicks"),localStorage.getItem("messagejoin"))

}
    if(msg.data=="exit"){__0x70("exit")}
    if(msg.data=="report"){__0x70("report");}
    if(msg.data=="jump"){__0x70("jump")}
    if(msg.data=="0xbE"){__0x70("0xbE")}
    if(msg.data=="afkconfirm"){__0x70("afkconfirm")}
    if(msg.data=="acceptdraw1"){__0x70("accept1")}
    if(msg.data=="acceptdraw2"){__0x70("accept2")}
    if(msg.data=="tips"){__0x70("tips")}
}})
        document.querySelector(".kickallwhenjoin").addEventListener("click",()=>{__0x70("kicknewset",f(".kickallwhenjoin").checked)})
        document.querySelector(".kickonjoin").addEventListener("click",()=>{__0x70("kickjoinset",f(".kickonjoin").checked)
        })
                document.querySelector("#autoreport").addEventListener("click",()=>{__0x70("autoreport",f("#autoreport").checked);
        })
                document.querySelector("#autoskip").addEventListener("click",()=>{__0x70("autoskip",f("#autoskip").checked)
        })
                document.querySelector("#antikick").addEventListener("click",()=>{__0x70("antikick",f("#antikick").checked)
        })
                document.querySelector("#autokick").addEventListener("click",()=>{__0x70("autokick",f("#autokick").checked)
        })
                document.querySelector("#antiafk").addEventListener("click",()=>{__0x70("antiafk",f("#antiafk").checked)
        })
                document.querySelector("#autofarm").addEventListener("click",()=>{__0x70("autofarm",f("#autofarm").checked)
        })
                document.querySelector("#autoguess").addEventListener("click",()=>{__0x70("autoguess",f("#autoguess").checked)
        })
        
                document.querySelector("#giveanswer").addEventListener("click",()=>{__0x70("giveanswer",f("#giveanswer").checked)
        })
        
                document.querySelector("#autorejoin").addEventListener("click",()=>{__0x70("autorejoin",f("#autorejoin").checked)
        })
        
                document.querySelector("#kickalljoin").addEventListener("click",()=>{__0x70("kickalljoin",f("#kickalljoin").checked)
        })
                        document.querySelector("#kickonjoin").addEventListener("click",()=>{__0x70("kickonjoin",f("#kickonjoin").checked)
        })               
 document.querySelector("#allcommand").addEventListener("click",()=>{__0x70("allcommand",f("#allcommand").checked)
        })
 document.querySelector("#autotips").addEventListener("click",()=>{__0x70("autotips",f("#autotips").checked)
        })
                    	    let kicknewstat=false,kickjoinstat=false,autoreport=false,autoskip=false,antiafk=false,antikick=false,antikickDelay=1,autokick=false,autoguess,autofarm=false,giveanswer=false,autorejoin=false,kickalljoin=false,kickonjoin=false,allcommand=false,autotips=false,waitforkick=0
function addHiddenCharToArabicName(name) {
    const ZWSPs = ['\u2060', '\u2061', '\u2062', '\u2063'];
    const chars = name.split("");
    const randomIndex = Math.floor(Math.random() * (chars.length + 1));
    const hiddenChar = ZWSPs[Math.floor(Math.random() * ZWSPs.length)];
    const repeatCount = Math.floor(Math.random() * 3) + 1;
    const hiddenChars = hiddenChar.repeat(repeatCount);
    chars.splice(randomIndex, 0, hiddenChars);
    return chars.join("");
}

function LUNA(o, pN, c) {let v = o[pN];Object.defineProperty(o, pN, {  get() { return v;    },set(nV) {  if (nV !== v) {  const oV = v;  v = nV; c(nV, oV);    }},  });};
let usersinroom=[]
         let lE=JSON.parse(localStorage.getItem("languages"));
let sE=JSON.parse(localStorage.getItem("subjects"));let arfSL=[];function gSL(s, l) {const sO=sE.find(item => item.id === s);const lO= lE.find(item => item.id === l);if(sO && lO) {arfSL=[sO.name,lO.name];}}
const data = {ev: 10};
function g(e, x) {
  data.ev = [e,x,Math.ceil(Math.random()*100000+1)]
}
     let inv= ['឴','‏','឵','­','͏','‎','𝅹','⁡'];
     function em(p){
  let iC = ['\uFE00', '\uFE01', '\uFE02', '\uFE03', '\uFE04', '\uFE05', '\uFE06', '\uFE07', '\uFE08', '\uFE09', '\uFE0A', '\uFE0B', '\uFE0C', '\uFE0D', '\uFE0E', '\uFE0F','\u206F','\u206E','\u200B', '\u200C', '\u200D', '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u17b4', '\u17b5', '\u2068', '\u2069'];
  let niC = 18 - p.length;  
  for(let i = 0; i < niC; i++){
    let rP = Math.floor(Math.random() * p.length);
    let rC = iC[Math.floor(Math.random() * iC.length)];   
    p = p.slice(0, rP) + rC + p.slice(rP);
  }  
  return p;
};
if (localStorage.getItem("botQueueNum") === null) {
    localStorage.setItem("botQueueNum", "0");
}
function getNextQueueNumber() {
    let current = parseInt(localStorage.getItem("botQueueNum")) || 0;
    current++;
    localStorage.setItem("botQueueNum", current.toString());
    return current;
}
function gRc() { const eR = [128512, 128591, 128640, 128767, 129280, 129535];  let c; do {
    c = Math.floor(Math.random() * 2801);
  } while (eR.some(range => c >= range && c <= range + 127));  return c;}
function gRcs() {const cs = [];for (let i = 0; i < 17; i++) {  cs.push(String.fromCharCode(gRc())); } return cs;}
   let etL = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
function shuffle(a) {for (let i = a.length - 1; i > 0; i--) {let j = Math.floor(Math.random() * (i + 1));[a[i], a[j]] = [a[j], a[i]];}  return a;}
const intervalIds= {};
  const webSockets = {};
let connectedBots = {};

function updateBotSelector() {
  const selector = document.querySelector('#botSelector');
  if (!selector) return;
  selector.innerHTML = '<option value="">Select a bot</option>';
  for (const botId in connectedBots) {
    const option = document.createElement('option');
    option.value = botId;
    option.textContent = connectedBots[botId].nickname;
    selector.appendChild(option);
  }
}


window.addEventListener('message', function(event) {
  if (event.data === 'sendBotChat') {
    const botId = document.querySelector('#botSelector').value;
    const message = document.querySelector('#botChatMessage').value;
    if (botId && connectedBots[botId]) {
      connectedBots[botId].socket.send(`42[11,${connectedBots[botId].id},"${message}"]`);
    }
  }
  if (event.data === 'sendBotAnswer') {
    const botId = document.querySelector('#botSelector').value;
    const answer = document.querySelector('#botAnswerMessage').value;
    if (botId && connectedBots[botId]) {
      connectedBots[botId].socket.send(`42[13,${connectedBots[botId].id},"${answer}"]`);
    }
  }
  if (event.data === 'sendBotExit') {
    const botId = document.querySelector('#botSelector').value;
    const answer = document.querySelector('#botAnswerMessage').value;
    if (botId && connectedBots[botId]) {
      connectedBots[botId].socket.send(`42[24,${connectedBots[botId].id}]`);
    }
  }
});
window.addEventListener("load", () => {
  const msgInput = document.getElementById("message");
  msgInput.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
      const socketsList = Object.values(webSockets);
      const textToSend = msgInput.value.trim();
      socketsList.forEach(wsObj => {
        const ws = wsObj.socket;
        const timestamp = wsObj.timestamp;
        ws.send(`42[11,${timestamp},"${textToSend}"]`);
      });
      msgInput.value = "";
    }
  });
});
window.addEventListener('message', function(event) {
    if(event.data.startsWith("cmd.")){
	          let abtn=event.data.split("cmd.")[1];
	let nv=JSON.parse(abtn);console.log(nv);console.log(abtn);
    	switch(nv[0]){
    	case "join":
   let room=nv[1];
            let botssv = localStorage.getItem("bots");let botssp=JSON.parse(botssv);let itvl=parseInt(document.querySelector("#quantbot").value);
	botssp.slice(0, itvl).forEach(v=>{
 
            fetch("https://"+v.link+"/server/?check=1&v3=1&room="+room+"&__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8#",{"credentials":"include"}).then(x=>x.text()).then(x=>{
              let userServer = getSelectedServer(); 
              let extractedServer = x.split("https://")[1].split(".")[0]; 
              let finalServer = userServer ? `server${userServer}` : extractedServer;

              let ws = new WebSocket("wss://"+v.link +"/__cpw.php?u="+ btoa(`wss://${finalServer}.gartic.io/socket.io/?c=${x.split("?c=")[1]}&EIO=3&transport=websocket`) + "&o=aHR0cHM6Ly9nYXJ0aWMuaW8=");

            //let ws=new WebSocket("wss://"+v.link+"/__cpw.php?u="+btoa("wss://server03.gartic.io/socket.io/?c="+x.split("?c=")[1]+"&EIO=3&transport=websocket")+"&o=aHR0cHM6Ly9nYXJ0aWMuaW8="); 

         fetch("https://luva.cc/assign-token", {
          method: "GET",
        })
        .then(response => response.json())
        .then(data => {
          const token = data.token;
          console.log("Token:", token);
          console.log("Token length:", token.length);
          if(token){
ws.onopen = () => {
  let finalNick = "";

  if (nv[4] === '0' && nv[3] !== 'random') {
    finalNick = addHiddenCharToArabicName(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '1' && nv[3] !== 'random') {
    finalNick = nv[2] + getNextQueueNumber();
    ws.send(`42[3,{"v":20000,"token":"${token}","nick":"${finalNick}","avatar":"${nv[3]}","platform":0,"sala":"${room.substring(2)}"}]`);
  
  } else if (nv[4] === '0' && nv[3] == 'random') {
    finalNick = addHiddenCharToArabicName(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '1' && nv[3] == 'random') {
    finalNick = nv[2] + Math.ceil(Math.random()*10000+1);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '2' && nv[3] !== 'random') {
    finalNick = em(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '2' && nv[3] == 'random') {
    finalNick = em(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '3') {
    let c = JSON.parse(nv[5]);
    let r = c[Math.floor(Math.random() * c.length)];
    finalNick = r.nick;
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"' + finalNick + '","avatar":"' + r.avatar + '","platform":0,"sala":"' + room.substring(2) + '"}]');
  
  } else if (nv[4] === '4' && nv[3] !== 'random') {
    finalNick = gRcs().join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '4' && nv[3] == 'random') {
    finalNick = gRcs().join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '5' && nv[3] !== 'random') {
    finalNick = shuffle(etL).slice(0,18).join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '5' && nv[3] == 'random') {
    finalNick = shuffle(etL).slice(0,18).join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  }


  ws._finalNick = finalNick;
};
          
        }
        })

            
                ws.onmessage= (msg) => {
                let ve=msg.data.substring(2);
          if(Array.isArray(ve)){let vv=JSON.parse(vv)};
               
                	                if(msg.data.indexOf('42["5"')!=-1){

               let objlist=JSON.parse('["5"'+msg.data.split('42["5"')[1]);
               ws.longID=objlist[1];
               ws.id=objlist[2];  
                // 
                //let botNick = (objlist[4] && objlist[4].nick) ? objlist[4].nick : nv[2];
                                //    let botNick = objlist[5][0].nick;
               connectedBots[ws.id] = {
                 socket: ws,
                 nickname: ws._finalNick,
                 id: ws.id
               };
               updateBotSelector();
               //   
                  let tipo=objlist[4].tipo
                  let idioma=objlist[4].idioma
                    gSL(tipo,idioma)
               LUNA_("callbackbot",objlist[1]);                                    objlist[5].forEach(item=>{usersinroom.push(item)});
               let mj=JSON.parse(nv[6]);mj.forEach(m=>{switch(m.type){
case "broadcast":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;case "message":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');break;
case "answer":ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;
}})               
if(kickalljoin===true){
	objlist[5].forEach((u,i)=>{
		setTimeout(()=>{
ws.send('42[45,' + ws.id + ',["' + u.id + '",true]]');
},500*i)
		})
	}

                        ws.send('42[46,' + ws.id + ']');

                    let ikc=setInterval(()=>{
               ws.readyState==1?ws.send('2'):clearInterval(ikc)
                    },3000);

                   webSockets[ws.id] = { socket: ws, timestamp: ws.id};
                   LUNA(data, 'ev', (nV, oV) => {
      if (nV) {
        Object.values(webSockets).forEach(wsObj => {
          const ws = wsObj.socket;
          const timestamp = wsObj.timestamp;

          switch (nV[0]) {
            case "broadcast":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "broadcastspam":
            inv = shuffle(inv);
let fE= inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fE +'"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fE + '"]');
              break;
            case "msg":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "msgspam":
            inv = shuffle(inv);
let fM = inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fM +'"]');
              break;
            case "answer":
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "answerspam":
            inv = shuffle(inv);
let fA= inv.slice(0,3).join('');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fA + '"]');
              break;
            case "report":
              ws.send('42[35,' + timestamp + ']');
              break;
            case "jump":
              ws.send('42[25,' + timestamp + ']');
              break;
            case "accept1":
              ws.send('42[34,' + timestamp + ']');
              break;
            case "accept2":
              ws.send('42[34,' + timestamp + ',1]');
              break;
            case "tips":
              ws.send('42[30,' + timestamp + ',1]');
              break;
            case "exit":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "rejoin":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "afkconfirm":
              ws.send('42[42,' + timestamp + ']');
              break;
            case "kick":
              ws.send('42[45,' + timestamp + ',["' + nV[1] + '",true]]');
              break;
              case "0xbE":
       
              break;
          }
        });
      }
    });
                	}
 if(msg.data.indexOf('42["26"')!=-1 && autoguess===true){
                    let objlist=JSON.parse('["26"'+msg.data.split('42["26"')[1]);
                  let c= objlist[1];
                  LUNA_("answer",c)
}
                if(msg.data.indexOf('42["47"]')!=-1 && autoguess===true){

            let inter=parseInt(localStorage.getItem("autoguess"))
function wordsArray(arr) {
  let index = 0;
  if (wordsInterval) {
    clearInterval(wordsInterval);
  }
  wordsInterval = setInterval(() => {
      if (index < arr.length) {
        ws.send('42[13,'+ws.id+',"'+arr[index]+'"]')
        index++;
      } else {
        clearInterval(wordsInterval);


    }
  }, inter);
}



                }

               if(msg.data.indexOf('42["6"')!=-1 && autorejoin===true){
               	let o= JSON.parse('['+msg.data.split('42[')[1]);var rn=o[1];var reason=o[2];
               if(reason!==null){
              window.postMessage("dupejoin","*")}
               	}
                 	                                if(msg.data.indexOf('42["11"')!=-1 | msg.data.indexOf('42["13"')!=-1){
let objlist = JSON.parse('['+msg.data.split('42[')[1])
                    var id=objlist[1];
                    var m=objlist[2];
                    if(m.startsWith("$msg") && allcommand===true){
                 	ws.send('42[11,'+ws.id+',"'+m.substring(5)+'"]')
                    	}                    
                    if(m.startsWith("$answer") && allcommand===true){
                    	ws.send('42[13,'+ws.id+',"'+m.substring(8)+'"]')
                    	}

const botSpamIntervals = {};
const botSpamStates = {}; 

   // أوامر السبام العادي
    if (m.startsWith("$start") && allcommand === true) {
        // إيقاف أي سبام سابق لهذا البوت
        if (botSpamIntervals[ws.id]) {
            clearInterval(botSpamIntervals[ws.id]);
            delete botSpamIntervals[ws.id];
        }
        
        const parts = m.split(" ");
        const targetName = parts.length > 1 ? parts.slice(1).join(" ") : "اسم";
        const arrMsg = baseMsgs.map(msg => msg.replace(/اسم/g, targetName));
        
        // تعيين نوع السبام
        botSpamStates[ws.id] = 'insult';
        
        botSpamIntervals[ws.id] = setInterval(() => {
            try {
                if (ws.readyState === WebSocket.OPEN) {
                    const msg = arrMsg[Math.floor(Math.random() * arrMsg.length)];
                    ws.send('42[11,' + ws.id + ',"' + msg + '"]');
                } else {
                    clearInterval(botSpamIntervals[ws.id]);
                    delete botSpamIntervals[ws.id];
                    delete botSpamStates[ws.id];
                }
            } catch (err) {
                clearInterval(botSpamIntervals[ws.id]);
                delete botSpamIntervals[ws.id];
                delete botSpamStates[ws.id];
            }
        }, 960);
    }
    
    // أوامر لانا ديل ري
    if (m.startsWith("$lanadelrey") && allcommand === true) {
        // إيقاف أي سبام سابق لهذا البوت
        if (botSpamIntervals[ws.id]) {
            clearInterval(botSpamIntervals[ws.id]);
            delete botSpamIntervals[ws.id];
        }
        
        let index = 0;
        botSpamStates[ws.id] = 'lana';
        
        botSpamIntervals[ws.id] = setInterval(() => {
            try {
                if (ws.readyState === WebSocket.OPEN) {
                    const msg = arrLana[index];
                    ws.send('42[11,' + ws.id + ',"' + msg + '"]');
                    index = (index + 1) % arrLana.length;
                } else {
                    clearInterval(botSpamIntervals[ws.id]);
                    delete botSpamIntervals[ws.id];
                    delete botSpamStates[ws.id];
                }
            } catch (err) {
                clearInterval(botSpamIntervals[ws.id]);
                delete botSpamIntervals[ws.id];
                delete botSpamStates[ws.id];
            }
        }, 960);
    }
    
    // إيقاف السبام العادي
    if (m.startsWith("$stop") && allcommand === true) {
        // إيقاف جميع البوتات التي تستخدم السبام العادي
        Object.keys(botSpamIntervals).forEach(botId => {
            if (botSpamStates[botId] === 'insult') {
                clearInterval(botSpamIntervals[botId]);
                delete botSpamIntervals[botId];
                delete botSpamStates[botId];
            }
        });
    }
    
    // إيقاف سبام لانا
    if (m.startsWith("$slanadelrey") && allcommand === true) {
        // إيقاف جميع البوتات التي تستخدم سبام لانا
        Object.keys(botSpamIntervals).forEach(botId => {
            if (botSpamStates[botId] === 'lana') {
                clearInterval(botSpamIntervals[botId]);
                delete botSpamIntervals[botId];
                delete botSpamStates[botId];
            }
        });
    }

    
// ---- cla




                    if(m.startsWith("$nope") && allcommand===true){
         	let k=m.substring(6);
        let fc= usersinroom.find(e=>e.nick==k);
   ws.send('42[45,' + ws.id + ',["' + fc.id+ '",true]]');
   
                    	}                   
 if(m=="$report" && allcommand===true){ws.send('42[35,'+ws.id+']')}                   
if(m=="$jump" && allcommand===true){ws.send('42[25,'+ws.id+']')
                    	}                     
if(m=="$tips" && allcommand===true){ws.send('42[30,'+ws.id+',1]')
                    	}                                  
if(m=="$exit" && allcommand===true){ws.send('42[24,'+ws.id+']')
                    	}
                    }
                                                if(msg.data.indexOf('42["23"')!=-1){
                    let user=JSON.parse("{"+msg.data.split("{")[1].split("}")[0]+"}")

                    usersinroom.push(user);
                    if(kickonjoin===true){
   ws.send('42[45,' + ws.id + ',["' + user.id+ '",true]]');
                                        	}
                    let ck=JSON.parse(localStorage.getItem("customkick"));
                    if (ck.find(e=>e.user===user.nick)) {
   ws.send('42[45,' + ws.id + ',["' + user.id+ '",true]]');
}
}
                                    if(msg.data.indexOf('42["24"')!=-1){
                    let user=msg.data.split(",")[1].split('"')[1]
                    for(let i=0;i<usersinroom.length;i++){
                        typeof(usersinroom[i].id)==='undefined'?0:usersinroom[i].id==user?usersinroom.splice(i,1):0
                      }

                    }

                if(msg.data.indexOf('42["34"')!=-1){
                    let objlist=JSON.parse('["34"'+msg.data.split('42["34"')[1])
                    var c=objlist[1];
                    var tv=objlist[2];
                LUNA_("answerinput",c)
                                    if(autofarm===true){
                                     setTimeout(()=>{
                LUNA_("answer",c)},100)
                    }
                    if(giveanswer===true){
                    	let iC = ["឴", "‏", "឵"];
let r = "";

for (let i = 0; i < c.length; i++) {
  r+= c.charAt(i);
  if (i < c.length - 1) {
    let riC = iC[Math.floor(Math.random() * iC.length)];
    r+= riC;
  }
}
ws.send('42[11,'+ws.id+',"answer: '+r+'"]')
                    	}
  if(autotips===true){
  for(let i = 0; i < tv; i++){
ws.send('42[30,'+ws.id+',1]')}
}
}
if(msg.data.indexOf('42["16"')!=-1 && autofarm===true){
                    ws.send('42[34,'+ws.id+']')
 

    //ws.send(`42[10,${ws.id},[2,${points.join(',')}]]`);
    setTimeout(() => {
          ws.send(`42[10,${ws.id},[2,661,65,661,64,661,64,659,63,659,61,659,61,659,61,659,60,659,59,659,59,658,58,658,57,658,56,658,55,658,55,658,54]]`)
    ws.send(`42[10,${ws.id},[2,658,54,658,53,657,52,657,51,657,50,656,48,656,47,655,46,655,46,655,45,654,45,654,44,654,43,654,43,654,41,653,41]]`)
    ws.send(`42[10,${ws.id},[2,653,41,653,40,653,39,652,39,652,39,652,37,650,36,650,34,650,33,650,32,649,31,648,31,648,30,647,29,647,29,646,28]]`)
    // 
    ws.send(`42[10,${ws.id},[2,646,28,645,28,645,27,645,27,644,26,643,26,642,26,642,25,641,25,640,25,638,25,638,25,636,24,636,24,635,24,633,24]]`)
    ws.send(`42[10,${ws.id},[2,633,24,631,24,631,23,629,23,628,23,628,23,626,23,623,22,621,22,621,22,620,22,618,22,617,22,616,22,614,22,613,22]]`)
    ws.send(`42[10,${ws.id},[2,613,22,612,22,611,22,609,24,608,24,608,24,607,24,606,24,605,25,605,25,603,26,602,27,601,28,601,29,599,31,599,31]]`)

    ws.send(`42[10,${ws.id},[2,599,31,598,32,598,32,596,34,595,34,594,36,592,38,592,38,591,39,591,41,589,43,588,46,587,46,586,47,585,49,585,50]]`)
    ws.send(`42[10,${ws.id},[2,585,50,584,52,584,53,584,54,583,55,583,57,583,58,583,61,583,62,583,64,583,65,583,68,583,68,583,70,583,73,583,75]]`)
    ws.send(`42[10,${ws.id},[2,583,75,583,76,583,77,583,79,583,81,583,82,584,82,584,83,584,83,584,83,584,84,585,84,585,85,585,86,585,87,585,87]]`)

        ws.send(`42[10,${ws.id},[2,585,87,586,88,586,89,587,89,587,91,587,91,588,91,588,92,589,92,589,92,590,92,590,93,591,93,591,94,591,94,591,94]]`)
    ws.send(`42[10,${ws.id},[2,591,94,592,94,592,93,592,92,592,91,592,91,594,92,595,94,596,94,598,95,598,97,599,98,599,98,601,98,601,100,603,101]]`)
    ws.send(`42[10,${ws.id},[2,603,101,603,101,604,101,605,103,605,103,605,104,606,105,606,105,606,105,606,107,606,108,607,108,607,110,608,112,608,112,608,113]]`)

        ws.send(`42[10,${ws.id},[2,608,113,608,115,608,117,608,117,608,120,608,120,608,121,608,123,608,124,608,126,608,127,608,127,608,129,607,129,607,130,607,131]]`)
    ws.send(`42[10,${ws.id},[2,607,131,606,131,606,131,605,131,605,131,604,131,603,131,601,131,601,131,599,131,599,131,599,131,596,131,594,131,593,131,591,131]]`)
    ws.send(`42[10,${ws.id},[2,591,131,588,133,585,133,583,133,580,135,578,135,575,135,573,136,569,137,568,138,565,139,563,140,561,141,558,141,555,142,554,142]]`)
        ws.send(`42[10,${ws.id},[2,554,142,554,143,552,143,551,144,550,144,550,145,550,146,549,147,549,147,548,148,548,149,548,149,548,150,548,152,547,155,547,157]]`)

    ws.send(`42[10,${ws.id},[2,547,157,545,160,545,163,545,166,543,172,542,175,541,181,540,187,540,193,540,198,540,203,538,208,538,214,538,217,538,221,538,226]]`)
    ws.send(`42[10,${ws.id},[2,538,226,539,228,539,231,540,235,540,237,541,238,541,241,542,244,543,246,543,246,544,247,545,248,546,250,546,251,547,251,547,252]]`)
        ws.send(`42[10,${ws.id},[2,547,252,547,253,547,253,547,253,548,253,548,253,550,253,550,253,551,253,552,252,552,251,553,249,554,248,554,247,555,246,555,244]]`)
    ws.send(`42[10,${ws.id},[2,555,244,555,243,557,241,557,239,559,237,559,235,560,233,560,232,561,230,562,228,562,225,563,223,564,220,565,216,567,214,567,210]]`)

    ws.send(`42[10,${ws.id},[2,567,210,569,208,569,205,570,201,571,199,572,198,573,196,574,194,575,193,575,192,576,191,576,191,576,190,577,190,578,189,578,189]]`)
    ws.send(`42[10,${ws.id},[2,578,189,579,189,580,189,582,189,582,189,583,189,584,189,584,189,586,189,588,190,590,191,591,192,591,194,593,194,594,196,596,198]]`)
    ws.send(`42[10,${ws.id},[2,596,198,598,199,599,201,599,202,601,204,601,205,603,207,604,210,605,211,606,214,606,216,606,218,607,219,607,221,608,223,608,223]]`)


    ws.send(`42[10,${ws.id},[2,608,223,608,224,608,224,608,225,608,226,608,225,608,224,609,226,609,229,609,232,610,236,610,241,611,246,611,253,611,257,612,262]]`)
    ws.send(`42[10,${ws.id},[2,612,262,612,267,613,272,613,277,613,282,613,287,613,290,613,294,613,297,613,301,613,304,613,307,612,309,612,312,612,316,611,318]]`)
    ws.send(`42[10,${ws.id},[2,611,318,610,321,609,325,608,327,607,330,606,333,606,337,605,339,603,342,602,346,600,348,599,351,599,355,597,356,596,360,594,364]]`)
    ws.send(`42[10,${ws.id},[2,594,364,593,367,592,369,591,372,590,376,589,378,587,381,586,385,585,386,585,390,584,393,584,395,583,397,583,400,583,401,583,404]]`)

    ws.send(`42[10,${ws.id},[2,583,404,583,405,583,408,583,409,583,411,583,411,583,413,583,414,583,415,584,415,584,416,584,418,585,418,585,419,586,420,588,422]]`)
    ws.send(`42[10,${ws.id},[2,588,422,589,422,589,423,590,423,591,423,592,424,592,424,593,425,594,425,596,425,596,425,597,425,598,425,599,425,599,425,600,424]]`)
    ws.send(`42[10,${ws.id},[2,600,424,601,423,602,423,603,423,604,422,605,420,605,420,605,419,606,417,606,416,607,416,607,415,608,414,608,413,608,412,608,410]]`)
    ws.send(`42[10,${ws.id},[2,608,410,609,409,609,408,609,407,610,405,610,404,611,401,611,399,611,397,612,393,612,392,613,390,613,386,613,385,614,381,614,379]]`)
    ws.send(`42[10,${ws.id},[2,614,379,615,377,616,374,617,371,618,369,619,366,619,364,620,362,621,360,621,358,622,356,622,354,622,351,624,349,624,348,626,344]]`)
    ws.send(`42[10,${ws.id},[2,626,344,626,342,627,342,628,340,628,338,629,337,630,335,631,334,632,331,633,330,633,328,634,328,634,327,635,326,635,325,636,325]]`)
    ws.send(`42[10,${ws.id},[2,636,325,636,324,636,323,636,323,636,321,638,320,639,319,640,318,640,316,642,315,643,314,644,312,646,311,647,311,649,309,650,308]]`)
    ws.send(`42[10,${ws.id},[2,650,308,650,306,651,305,652,305,653,305,654,305,655,305,656,304,656,304,658,304,659,303,659,303,661,303,663,303,665,303,665,303]]`)
    },2500)

    setTimeout(() => {
    ws.send(`42[10,${ws.id},[2,665,303,667,303,668,303,672,304,672,304,674,304,676,304,677,305,679,305,680,306,680,307,680,307,681,308,682,309,682,310,683,310]]`)

    ws.send(`42[10,${ws.id},[2,683,310,683,311,684,311,684,312,684,312,684,312,684,313,684,314,684,315,684,316,684,316,684,317,684,318,684,319,684,319,684,321]]`)
    ws.send(`42[10,${ws.id},[2,684,321,684,321,684,323,684,325,684,325,684,327,684,329,684,331,684,334,684,335,684,339,684,342,684,344,686,348,686,350,686,353]]`)

        ws.send(`42[10,${ws.id},[2,686,353,686,358,686,362,687,365,687,369,688,373,688,379,689,385,690,392,690,396,691,401,691,406,691,409,692,413,692,415,693,418]]`)
    ws.send(`42[10,${ws.id},[2,693,418,693,420,694,423,695,425,695,427,695,428,696,430,697,431,697,432,698,432,698,433,698,433,698,434,699,434,700,434,701,434]]`)
    ws.send(`42[10,${ws.id},[2,701,434,702,434,702,434,704,434,705,433,707,432,708,431,709,430,710,429,712,427,714,426,714,424,716,423,717,420,717,418,718,416]]`)
    ws.send(`42[10,${ws.id},[2,718,416,719,415,720,411,720,409,721,407,721,404,722,401,722,399,722,397,722,393,722,393,722,389,721,387,721,384,721,381,720,378]]`)
    ws.send(`42[10,${ws.id},[2,720,378,720,375,719,372,719,369,718,365,718,362,717,358,717,356,717,352,717,349,717,345,716,342,716,338,716,335,715,333,714,329]]`)
    ws.send(`42[10,${ws.id},[2,714,329,713,327,712,323,711,320,710,318,710,316,709,312,709,312,708,309,707,306,707,304,706,302,706,300,705,298,705,297,705,295]]`)

    ws.send(`42[10,${ws.id},[2,705,295,704,293,704,293,704,291,704,290,704,290,704,289,704,288,704,287,704,286,704,286,704,285,704,284,704,284,704,283,704,283]]`)
    ws.send(`42[10,${ws.id},[2,704,283,704,284,703,284,703,283,703,283,702,281,702,278,702,276,702,275,701,272,701,271,700,269,700,267,699,265,699,263,699,262]]`)
        ws.send(`42[10,${ws.id},[2,699,262,698,260,698,259,697,258,697,256,697,254,696,252,696,250,695,249,695,247,695,246,693,244,693,242,693,240,693,238,693,237]]`)
    ws.send(`42[10,${ws.id},[2,693,237,692,235,692,233,691,232,691,231,690,229,690,228,690,224,690,223,690,222,690,221,690,219,690,216,690,214,690,212,689,210]]`)
    ws.send(`42[10,${ws.id},[2,689,210,689,209,689,207,689,205,689,205,689,203,689,202,689,201,689,201,689,200,689,199,689,198,689,197,689,196,689,196,689,194]]`)
    ws.send(`42[10,${ws.id},[2,689,194,689,194,689,194,689,193,689,193,689,192,689,192,689,191,690,191,690,191,691,191,691,191,691,189,692,189,693,189,693,189]]`)
    ws.send(`42[10,${ws.id},[2,693,189,695,188,695,188,695,187,696,187,697,187,698,187,699,187,700,187,701,187,702,187,702,187,703,187,703,187,704,187,705,187]]`)

    ws.send(`42[10,${ws.id},[2,705,187,707,187,707,187,708,187,709,187,710,187,710,187,711,188,712,188,712,189,713,190,714,190,714,191,714,191,716,192,716,193]]`)
    ws.send(`42[10,${ws.id},[2,716,193,716,193,716,194,717,196,717,198,718,200,719,201,720,203,721,204,721,207,721,209,723,211,723,214,724,216,724,217,725,219]]`)
    ws.send(`42[10,${ws.id},[2,725,219,725,221,726,223,727,225,728,226,729,228,730,230,730,231,731,231,732,233,732,234,732,235,732,235,732,236,732,237,733,237]]`)
        ws.send(`42[10,${ws.id},[2,733,237,733,237,734,237,735,237,736,236,737,235,738,235,739,234,740,232,742,231,742,231,743,230,745,229,746,228,746,227,746,226]]`)
    ws.send(`42[10,${ws.id},[2,746,226,747,226,748,225,749,224,749,223,749,223,749,222,750,220,750,219,750,219,750,218,750,217,750,217,750,216,750,216,749,215]]`)
    ws.send(`42[10,${ws.id},[2,749,215,749,214,748,213,748,211,746,209,746,207,745,205,743,201,742,200,740,195,739,193,738,191,736,187,735,183,734,179,733,177]]`)
    ws.send(`42[10,${ws.id},[2,733,177,732,173,730,171,730,168,730,166,729,164,728,163,727,161,727,159,726,158,726,157,726,156,726,156,726,155,725,154,725,154]]`)
    ws.send(`42[10,${ws.id},[2,725,154,725,153,724,152,724,151,724,151,723,151,723,151,723,150,722,150,721,150,721,150,721,149,719,148,719,146,717,144,717,142]]`)

    ws.send(`42[10,${ws.id},[2,717,142,716,142,714,141,714,139,714,138,713,138,712,137,712,136,712,135,712,135,711,135,710,135,710,134,709,134,709,134,709,134]]`)
    ws.send(`42[10,${ws.id},[2,709,134,708,134,707,134,707,134,705,134,705,134,704,133,703,133,702,133,701,133,699,133,698,131,697,131,695,131,695,131,694,131]]`)
    ws.send(`42[10,${ws.id},[2,694,131,692,130,691,130,689,130,688,130,687,129,686,129,686,129,685,129,684,128,683,128,682,127,682,127,681,127,681,126,680,126]]`)

        ws.send(`42[10,${ws.id},[2,680,126,680,126,679,124,679,123,677,122,676,120,675,119,675,119,673,117,672,115,672,113,671,112,671,111,670,108,669,106,668,104]]`)
    ws.send(`42[10,${ws.id},[2,668,104,668,101,666,99,666,98,666,95,665,93,665,91,665,91,664,87,664,86,664,84,663,83,663,82,663,81,662,79,662,78]]`)
    ws.send(`42[10,${ws.id},[2,662,78,662,78,662,77,661,76,661,76,661,76,661,75,659,75,659,75,659,74,659,73,658,71,658,70,658,69,658,68,658,66]]`)
        ws.send(`42[10,${ws.id},[2,658,66,658,65,658,64,658,63,658,61,658,61,658,61,658,60,658,59,658,59,659,60]]`)

    ws.send(`42[10,${ws.id},[2,642,249,636,251,628,254,620,258,610,261,600,265,592,268,584,270,576,272,570,274,563,275,558,277,554,279,548,281,543,283,538,284]]`)
    ws.send(`42[10,${ws.id},[2,538,284,532,286,529,287,525,289,522,289,518,290,516,290,513,291,511,291,508,292,506,293,504,294,503,295,501,295,499,297,499,297]]`)
        ws.send(`42[10,${ws.id},[2,499,297,498,297,497,297,496,298,495,298,495,300,495,300,495,301,495,302,495,302,496,303,498,304,499,305,499,305,501,306,502,307]]`)
    ws.send(`42[10,${ws.id},[2,502,307,503,308,503,308,504,309,504,309,505,309,506,309,506,309,508,309,509,309,510,310,510,311,511,312,513,312,515,314,515,314]]`)
    ws.send(`42[10,${ws.id},[2,515,314,517,315,517,316,518,316,520,317,520,318,522,318,524,318,525,318,525,318,527,318,528,318,530,318,532,318,532,318,534,317]]`)

    ws.send(`42[10,${ws.id},[2,534,317,536,317,538,316,540,316,540,316,541,316,543,315,545,314,546,314,547,312,550,312,553,311,554,309,557,308,559,307,561,305]]`)
        ws.send(`42[10,${ws.id},[2,561,305,562,305,566,304,567,304,569,302,571,302,574,300,576,298,578,298,580,297,584,296,585,295,589,294,590,293,592,292,594,291]]`)
    ws.send(`42[10,${ws.id},[2,594,291,596,290,598,290,599,289,600,289,601,288,603,288,605,288,606,286,607,286,609,286,610,285,610,285,612,284,613,284,613,284]]`)
    ws.send(`42[10,${ws.id},[2,613,284,613,284,613,284,614,284,615,284,615,284,617,284,618,283,619,283,619,283,621,283,621,283,622,283,622,283,623,283,624,283]]`)
    },5000)

    setTimeout(() =>{
        ws.send(`42[10,${ws.id},[2,624,283,624,283,624,283,624,284,624,284,624,285,624,286,624,286,624,287,624,288,623,289,623,290,623,290,622,291,622,291,622,293]]`)
        ws.send(`42[10,${ws.id},[2,622,293,622,293,622,294,622,295,622,297,622,297,622,297,622,298,623,299,624,300,624,301,626,302,626,302,627,302,628,303,628,303]]`)
    ws.send(`42[10,${ws.id},[2,628,303,628,303,629,303,630,303,631,303,631,303,632,302,633,302,635,300,635,299,636,297,637,296,638,295,638,295,639,294,640,293]]`)
        ws.send(`42[10,${ws.id},[2,640,293,641,293,642,293,642,293,642,294,642,296,643,297,643,297,643,298,643,298,643,300,643,300,645,300,645,301,646,301,647,301]]`)
    ws.send(`42[10,${ws.id},[2,647,301,647,301,649,301,650,301,652,300,654,299,658,298,658,297,661,296,663,294,665,292,666,290,669,289,670,288,672,286,672,284]]`)

        ws.send(`42[10,${ws.id},[2,672,284,673,283,673,281,673,280,674,279,674,278,674,277,674,277,674,275,674,275]]`)
        ws.send(`42[10,${ws.id},[2,66,79,66,78,65,76,65,75,64,73,64,71,64,70,64,68,64,66,64,65,64,64,64,62,64,60,64,59,64,57,64,55]]`)
    ws.send(`42[10,${ws.id},[2,64,55,64,54,64,52,64,50,66,49,66,47,66,46,66,46,67,44,67,42,67,41,68,38,70,36,71,35,72,33,73,31]]`)
        ws.send(`42[10,${ws.id},[2,73,31,74,30,76,28,76,25,80,25,82,24,82,22,84,20,86,19,88,18,89,17,90,17,94,16,95,15,96,15,98,14]]`)
    ws.send(`42[10,${ws.id},[2,98,14,99,14,101,14,104,14,105,14,108,14,109,14,111,14,113,14,116,14,117,14,119,14,120,14,123,15,124,15,127,15]]`)
        ws.send(`42[10,${ws.id},[2,127,15,128,15,131,17,133,17,135,17,136,17,138,17,140,18,141,19,143,20,145,21,145,21,146,22,147,22,148,22,148,23]]`)
    ws.send(`42[10,${ws.id},[2,148,23,148,23,149,24,150,24,150,25,152,26,153,27,154,29,155,31,155,31,155,32,157,34,157,36,158,39,159,39,160,43]]`)
        ws.send(`42[10,${ws.id},[2,160,43,160,45,161,46,161,50,161,53,161,55,161,58,161,59,161,61,161,63,161,64,161,66,161,67,161,68,161,69,161,70]]`)
    ws.send(`42[10,${ws.id},[2,161,70,161,72,161,73,161,74,161,76,160,76,160,76,159,77,159,78,159,78,158,80,157,80,157,81,157,81,156,81,155,82]]`)
        ws.send(`42[10,${ws.id},[2,155,82,154,82,154,83,152,83,151,83,150,84,148,85,148,85,146,87,145,87,143,87,143,88,141,89,141,89,141,89,141,91]]`)
    ws.send(`42[10,${ws.id},[2,141,91,140,91,140,91,139,91,139,92,138,92,138,93,138,95,138,96,138,96,138,97,138,98,138,99,138,100,138,101,138,103]]`)


        ws.send(`42[10,${ws.id},[2,138,103,138,105,138,107,138,109,138,112,138,113,138,115,138,117,138,119,138,120,138,121,138,123,138,124,138,124,138,126,138,127]]`)
        ws.send(`42[10,${ws.id},[2,138,127,138,127,138,127,138,128,138,129,139,129,140,129,141,129,141,129,141,128,142,128,143,127,143,127,144,127,145,127,147,127]]`)
    ws.send(`42[10,${ws.id},[2,147,127,148,127,148,127,150,127,152,126,153,126,154,126,155,126,156,126,157,126,159,126,161,126,162,126,163,126,166,126,168,126]]`)
        ws.send(`42[10,${ws.id},[2,168,126,169,126,171,126,174,126,177,126,178,126,181,126,184,126,185,126,188,126,191,126,192,126,193,127,195,127,196,127,200,127]]`)
    ws.send(`42[10,${ws.id},[2,200,127,200,127,202,127,204,129,205,129,207,131,208,131,210,133,213,134,215,135,216,137,218,140,220,142,222,144,222,147,224,150]]`)
        ws.send(`42[10,${ws.id},[2,224,150,226,152,227,154,228,157,229,159,229,163,229,166,231,168,231,172,231,175,233,179,233,182,233,184,233,187,233,190,233,193]]`)
    ws.send(`42[10,${ws.id},[2,233,193,233,195,233,196,233,200,233,201,233,203,233,205,233,207,233,207,233,209,233,209,233,210,232,210,231,211,229,211,229,211]]`)
        ws.send(`42[10,${ws.id},[2,229,211,228,211,228,211,226,211,224,211,222,211,222,210,221,209,220,208,219,207,217,206,217,205,216,203,215,201,214,198,213,196]]`)
    ws.send(`42[10,${ws.id},[2,213,196,212,193,212,191,211,188,210,187,209,184,208,182,207,180,207,179,207,179,206,177,206,175,204,175,203,173,202,172,201,171]]`)
        ws.send(`42[10,${ws.id},[2,201,171,200,170,199,168,197,166,195,166,193,164,192,164,189,162,187,161,185,160,183,159,181,157,179,157,178,157,177,156,175,156]]`)
    ws.send(`42[10,${ws.id},[2,175,156,173,156,171,154,170,154,168,154,168,154,166,154,164,154,163,154,163,154,161,156,159,156,159,157,157,157,155,159,155,159]]`)
        ws.send(`42[10,${ws.id},[2,155,159,154,161,153,161,152,163,150,164,149,164,148,166,148,167,148,169,147,170,147,170,147,171,146,172,146,173,145,174,145,175]]`)
    ws.send(`42[10,${ws.id},[2,145,175,145,177,145,179,145,179,144,180,144,182,144,183,144,185,144,186,144,189,144,190,144,193,144,194,144,196,144,200,144,201]]`)
        ws.send(`42[10,${ws.id},[2,144,201,144,203,144,205,144,207,144,209,144,210,144,212,144,212,144,214,144,215,144,216,144,214,144,213,145,214,145,216,145,217]]`)
    ws.send(`42[10,${ws.id},[2,145,217,145,217,145,219,145,221,147,223,147,226,147,228,147,231,147,235,148,238,148,242,148,247,148,253,148,258,150,263,151,268]]`)
        ws.send(`42[10,${ws.id},[2,151,268,152,274,152,279,153,283,154,290,155,295,156,302,157,309,157,315,159,321,159,328,162,334,162,337,163,342,163,345,166,349]]`)
    ws.send(`42[10,${ws.id},[2,166,349,166,353,168,356,170,359,170,362,171,364,171,367,173,369,175,372,176,374,178,377,178,379,180,381,182,383,183,386,185,387]]`)
        ws.send(`42[10,${ws.id},[2,185,387,186,390,187,392,188,394,190,396,191,399,192,401,192,402,192,406,194,408,194,409,194,412,194,415,194,416,194,418,194,420]]`)
    ws.send(`42[10,${ws.id},[2,194,420,194,422,192,423,192,425,191,427,191,427,189,428,189,429,186,430,185,430,181,430,178,430,176,430,173,430,171,430,169,430]]`)
        ws.send(`42[10,${ws.id},[2,169,430,167,429,164,427,163,425,161,424,159,423,156,420,155,417,153,415,151,411,149,408,148,406,147,402,146,399,145,395,144,393]]`)
    ws.send(`42[10,${ws.id},[2,144,393,142,389,141,386,141,382,140,379,140,375,139,371,138,369,137,365,136,362,135,359,134,356,134,354,133,352,133,349,132,348]]`)
        ws.send(`42[10,${ws.id},[2,132,348,132,346,131,342,130,342,129,339,128,337,127,334,127,334,126,332,126,330,124,328,122,326,122,324,120,322,120,321,119,319]]`)
    ws.send(`42[10,${ws.id},[2,119,319,118,318,116,318,115,317,115,317,113,316,111,316,111,316,110,316,108,314,107,314,106,314,104,314,104,314,103,314,101,314]]`)
        ws.send(`42[10,${ws.id},[2,101,314,100,314,99,314,97,314,96,314,96,314,94,314,94,315,93,316,92,317,90,318,90,319,89,321,87,324,87,327,86,329]]`)
    ws.send(`42[10,${ws.id},[2,86,329,85,332,83,334,82,337,82,340,81,342,80,345,80,346,79,349,79,351,78,355,78,357,78,361,78,364,78,366,78,370]]`)
        ws.send(`42[10,${ws.id},[2,78,370,78,373,78,376,78,379,78,383,78,387,79,392,79,395,80,399,80,403,81,407,81,410,82,413,82,415,82,418,82,420]]`)
    ws.send(`42[10,${ws.id},[2,82,420,82,423,82,427,82,429,81,431,80,434,80,437,79,438,78,440,77,441,76,443,74,444,74,445,74,445,73,446,71,446]]`)
        ws.send(`42[10,${ws.id},[2,71,446,69,445,67,445,66,445,64,443,62,443,60,439,57,438,55,434,52,429,48,425,46,420,45,415,42,409,41,405,39,400]]`)
    ws.send(`42[10,${ws.id},[2,39,400,39,393,37,388,37,385,37,380,37,376,37,372,37,369,37,365,37,360,38,356,38,353,38,349,38,347,38,344,38,342]]`)
        ws.send(`42[10,${ws.id},[2,38,342,38,341,38,338,38,336,38,335,38,334,38,334,38,332,38,332,38,331,38,330,38,330,39,330,39,329,39,328,39,327]]`)
    ws.send(`42[10,${ws.id},[2,39,327,40,323,40,319,41,315,41,309,43,304,43,298,43,295,43,291,43,288,43,284,43,283,45,279,45,275,45,272,45,268]]`)
        ws.send(`42[10,${ws.id},[2,45,268,45,265,46,261,46,258,46,254,46,251,48,247,48,246,48,242,48,239,48,237,48,234,48,231,48,230,48,228,48,226]]`)


            ws.send(`42[10,${ws.id},[2,48,226,48,223,48,221,48,219,47,217,47,216,46,213,45,211,45,210,45,209,45,207,45,205,43,203,43,203,43,201,42,201]]`)
        ws.send(`42[10,${ws.id},[2,42,201,41,200,41,200,41,199,40,198,39,198,38,198,37,198,37,198,36,198,35,198,34,198,32,198,30,198,28,200,25,200]]`)
    ws.send(`42[10,${ws.id},[2,25,200,23,201,22,201,18,203,17,204,15,205,15,207,13,208,13,209,13,209,11,210,11,212,11,212,11,214,11,215,11,216]]`)
        ws.send(`42[10,${ws.id},[2,11,216,11,217,11,218,11,219,13,221,13,223,13,225,13,229,13,232,15,235,15,239,15,243,15,246,15,250,15,253,15,257]]`)
    ws.send(`42[10,${ws.id},[2,15,257,15,260,15,261,15,263,15,264,15,266,15,267,15,267,15,268,15,268,15,269,15,270,15,270,15,270,14,270,13,270]]`)
        ws.send(`42[10,${ws.id},[2,13,270,13,270,11,270,10,270,8,268,8,268,7,268,5,266,3,264,2,263,0,261,-1,260,-1,259,-3,257,-4,254,-5,253]]`)
    ws.send(`42[10,${ws.id},[2,-5,253,-7,251,-7,249,-8,247,-10,246,-10,245,-10,243,-12,242,-12,238,-12,238,-14,236,-14,234,-14,231,-14,230,-15,228,-15,224]]`)
        ws.send(`42[10,${ws.id},[2,-15,224,-15,222,-15,218,-15,216,-15,213,-15,209,-15,207,-15,203,-15,201,-14,198,-14,194,-14,190,-14,187,-13,184,-13,180,-13,177]]`)
    ws.send(`42[10,${ws.id},[2,-6,143,-5,142,-4,142,-4,141,-2,140,-1,140,-1,139,0,138,0,137,2,136,4,136,5,135,6,135,8,135,9,134,11,134]]`)
        ws.send(`42[10,${ws.id},[2,11,134,13,133,13,133,15,132,16,132,16,131,18,131,20,131,22,131,22,129,23,129,25,129,25,128,27,127,29,127,30,126]]`)
    ws.send(`42[10,${ws.id},[2,30,126,30,126,32,125,33,125,35,124,36,123,37,122,38,122,40,120,41,120,42,120,44,120,45,119,46,118,47,117,48,117]]`)
        ws.send(`42[10,${ws.id},[2,48,117,49,117,50,116,51,115,52,115,52,115,53,113,53,113,53,113,54,113,54,112,55,112,55,111,56,109,57,108,58,107]]`)
    ws.send(`42[10,${ws.id},[2,58,107,58,105,59,105,59,103,60,102,60,101,60,99,60,98,61,97,61,96,61,94,61,93,62,92,62,91,62,89,62,88]]`)
        ws.send(`42[10,${ws.id},[2,62,88,62,86,62,83,62,82,62,80,62,77,63,75,63,73,64,69,64,68,64,64,65,63,65,61,66,61,66,61,66,60]]`)
    ws.send(`42[10,${ws.id},[2,66,60,66,59]]`)
        ws.send(`42[10,${ws.id},[2,102,253,108,253,117,252,128,251,140,249,148,248,157,247,165,246,171,245,180,245,187,244,196,244,202,244,210,244,216,244,222,242]]`)
    ws.send(`42[10,${ws.id},[2,222,242,226,242,231,242,233,242,237,242,240,242,242,242,244,242,247,242,250,242,252,242,254,242,256,242,258,242,259,242,261,242]]`)
        ws.send(`42[10,${ws.id},[2,261,242,262,242,263,241,264,241,265,240,266,240,266,239,266,239,268,238,269,238,269,238,270,238,272,237,272,237,273,235,274,235]]`)
    ws.send(`42[10,${ws.id},[2,274,235,275,234,275,233,275,233,276,233,277,232,277,232,278,232,279,232,281,232,281,232,283,233,285,234,286,235,288,235,289,237]]`)
        ws.send(`42[10,${ws.id},[2,289,237,291,238,292,238,293,239,294,240,296,242,296,242,296,244,298,244,298,246,298,246,298,247,298,247,298,249,298,250,297,251]]`)
    ws.send(`42[10,${ws.id},[2,297,251,296,252,296,253,296,253,294,253,293,254,291,256,290,256,288,258,286,258,283,258,282,259,281,260,279,260,276,261,274,262]]`)
        ws.send(`42[10,${ws.id},[2,274,262,273,262,272,263,270,264,268,265,266,265,265,265,263,265,261,265,259,265,256,265,254,263,251,263,249,261,247,260,245,260]]`)
    ws.send(`42[10,${ws.id},[2,245,260,244,259,244,258,243,257,242,257,242,256,241,256,240,256,240,256,239,256,237,256,237,256,235,258,233,258,231,259,229,260]]`)
        ws.send(`42[10,${ws.id},[2,229,260,225,260,222,263,216,265,210,267,205,269,200,271,195,272,191,274,185,275,181,276,178,277,172,277,168,278,163,279,157,280]]`)
    ws.send(`42[10,${ws.id},[2,157,280,155,281,151,282,148,282,146,283,143,283,141,283,140,283,140,284,139,284,139,284,138,284,138,284,138,286,137,286,137,286]]`)
        ws.send(`42[10,${ws.id},[2,137,286,137,287,138,288,138,288,138,288,139,288,140,288,141,289,141,289,142,290,144,290,146,291,147,291,147,292,147,293,148,295]]`)
    ws.send(`42[10,${ws.id},[2,148,295,148,295,148,296,148,297,150,298,150,298,150,299,150,300,150,302,149,302,148,304,148,305,147,305,147,307,145,308,143,309]]`)
        ws.send(`42[10,${ws.id},[2,143,309,141,310,141,311,140,311,138,311,135,311,134,311,133,311,131,311,128,309,127,309,124,309,122,307,120,306,119,305,118,305]]`)
    ws.send(`42[10,${ws.id},[2,118,305,117,304,115,302,115,302,114,302,114,301,114,300,115,300,115,301,116,302,116,303,117,304,117,304,117,305,117,305,117,305]]`)
        ws.send(`42[10,${ws.id},[2,117,305,117,306,115,307,115,309,114,309,111,311,110,312,108,313,104,314,103,316,99,316,96,317,92,318,89,318,85,318,82,317]]`)
    ws.send(`42[10,${ws.id},[2,82,317,78,316,76,315,74,312,73,311,71,309,69,306,67,304,67,301,67,298,67,297,67,296,67,293,67,292,67,291,67,290]]`)
        ws.send(`42[10,${ws.id},[2,322,60,322,59,322,59,321,57,321,56,321,55,321,55,321,54,321,53,321,52,321,52,321,51,321,49,321,48,321,48,321,46]]`)
    ws.send(`42[10,${ws.id},[2,321,46,321,46,321,45,321,44,321,42,321,41,321,40,321,39,322,37,322,36,323,35,324,33,325,31,325,31,326,30,326,28]]`)
        ws.send(`42[10,${ws.id},[2,326,28,326,27,327,26,329,24,330,24,330,22,332,22,333,21,333,20,334,18,335,18,337,17,337,16,338,15,339,15,340,13]]`)
    ws.send(`42[10,${ws.id},[2,340,13,340,13,342,13,342,12,344,11,346,10,347,9,348,9,349,9,350,9,352,9,353,9,355,8,356,8,359,8,360,7]]`)
        ws.send(`42[10,${ws.id},[2,360,7,362,7,363,7,365,6,367,6,368,6,370,6,372,5,375,5,376,5,378,5,380,5,382,5,383,5,385,5,387,5]]`)
    ws.send(`42[10,${ws.id},[2,387,5,389,5,390,5,391,5,392,5,393,6,395,6,397,7,398,7,399,7,400,8,402,8,403,9,404,9,406,9,407,9]]`)
    },7500)
    setTimeout(() =>{
        ws.send(`42[10,${ws.id},[2,407,9,407,10,411,11,413,12,414,13,414,13,416,14,418,15,419,15,420,16,421,17,421,17,422,17,423,18,424,18,425,19]]`)
    ws.send(`42[10,${ws.id},[2,425,19,425,20,425,21,426,21,427,22,427,22,427,23,427,24,427,24,428,24,429,26,429,27,429,27,429,29,429,30,430,31]]`)
        ws.send(`42[10,${ws.id},[2,430,31,430,31,430,33,430,34,430,34,431,36,431,37,432,38,432,39,433,39,433,40,433,41,433,43,433,45,433,45,433,46]]`)
    ws.send(`42[10,${ws.id},[2,433,46,433,48,433,50,433,50,433,52,433,54,433,55,433,55,432,57,432,59,432,59,432,60,431,61,431,62,430,62,430,63]]`)
        ws.send(`42[10,${ws.id},[2,430,63,430,64,430,64,429,65,429,66,429,66,429,67,428,67,428,68,427,68,427,68,427,68,427,69,426,69,425,70,425,71]]`)
    ws.send(`42[10,${ws.id},[2,425,71,425,72,423,73,423,74,423,75,423,76,423,76,422,78,422,80,422,81,422,82,422,83,422,84,422,85,422,87,422,89]]`)
        ws.send(`42[10,${ws.id},[2,422,89,422,89,422,91,422,92,423,93,423,94,423,95,423,96,423,96,423,98,423,98,423,99,423,99,423,100,423,101,425,101]]`)
    ws.send(`42[10,${ws.id},[2,425,101,425,102,425,102,426,102,427,102,427,102,428,101,429,101,429,101,430,100,430,100,431,100,432,100,434,100,435,99,436,99]]`)
        ws.send(`42[10,${ws.id},[2,436,99,439,99,440,99,442,99,443,99,444,99,446,99,449,99,450,99,453,99,455,100,458,100,462,100,466,101,469,102,473,103]]`)
    ws.send(`42[10,${ws.id},[2,473,103,474,103,477,103,480,105,481,105,483,106,485,106,485,106,487,107,488,108,488,109,488,110,489,110,490,111,491,113,492,113]]`)


        ws.send(`42[10,${ws.id},[2,492,113,492,115,494,118,494,120,495,121,495,122,495,124,495,127,496,129,497,131,497,134,498,135,498,138,499,140,500,143,501,145]]`)
        ws.send(`42[10,${ws.id},[2,501,145,502,148,503,152,503,155,503,157,504,161,505,164,506,168,507,170,508,173,508,175,509,178,509,180,510,182,510,184,510,185]]`)
    ws.send(`42[10,${ws.id},[2,510,185,510,186,510,186,510,187,510,188,510,189,510,189,510,190,510,191,510,191,509,192,508,192,506,192,506,192,504,192,504,192]]`)
        ws.send(`42[10,${ws.id},[2,504,192,503,192,503,192,501,191,501,190,500,189,499,187,497,187,497,186,495,184,495,182,494,182,493,180,492,178,490,177,490,175]]`)
    ws.send(`42[10,${ws.id},[2,490,175,488,173,488,171,487,169,485,166,485,164,483,162,482,159,481,157,480,156,479,152,478,150,477,149,476,146,474,144,473,142]]`)
        ws.send(`42[10,${ws.id},[2,473,142,473,140,472,138,472,138,471,137,471,135,471,135,471,135,470,134,470,133,469,131,468,129,467,129,466,127,466,127,465,126]]`)
    ws.send(`42[10,${ws.id},[2,465,126,464,126,464,125,464,124,463,124,462,124,461,124,460,124,460,124,458,125,457,126,455,127,453,129,451,131,450,133,448,135]]`)
        ws.send(`42[10,${ws.id},[2,448,135,444,136,444,136,444,138,442,139]]`)
    ws.send(`42[10,${ws.id},[2,323,61,325,62,325,64,328,66,330,68,333,69,334,71,337,73,340,75,342,76,345,78,347,78,349,80,352,82,354,83,355,85]]`)
        ws.send(`42[10,${ws.id},[2,355,85,355,85,357,87,359,88,360,89,360,89,361,90,362,91,362,91,362,91,363,92,363,93,363,94,363,94,363,95,364,97]]`)
    ws.send(`42[10,${ws.id},[2,364,97,364,98,365,98,365,100,366,102,366,103,366,105,367,107,367,108,367,110,367,111,367,112,367,113,367,113,367,114,367,115]]`)
        ws.send(`42[10,${ws.id},[2,367,115,367,115,367,116,366,117,365,117,365,118,363,119,363,119,362,119,362,119,362,119,361,119,360,119,359,119,358,119,356,119]]`)
    ws.send(`42[10,${ws.id},[2,356,119,355,119,353,119,351,119,348,119,347,120,344,120,341,122,339,122,336,122,333,124,330,124,327,126,325,127,323,127,322,128]]`)
        ws.send(`42[10,${ws.id},[2,322,128,320,130,318,132,316,134,315,135,314,136,312,137,311,138,311,140,310,142,309,143,309,144,308,146,307,148,306,150,306,152]]`)
    ws.send(`42[10,${ws.id},[2,306,152,306,154,305,156,305,158,305,160,305,163,305,164,305,168,305,169,307,172,307,174,309,176,309,179,309,180,311,182,311,184]]`)
        ws.send(`42[10,${ws.id},[2,311,184,311,186,312,187,313,189,314,191,316,193,317,194,318,196,318,198,319,199,319,200,320,200,321,201,322,201,323,201,323,202]]`)
    ws.send(`42[10,${ws.id},[2,323,202,324,202,325,202,325,201,325,201,325,201,325,201,325,200,326,200,326,199,326,198,326,197,326,196,326,195,326,194,326,193]]`)
        ws.send(`42[10,${ws.id},[2,326,193,326,192,326,190,326,188,327,187,327,184,328,182,329,179,329,178,330,175,331,173,332,172,333,170,333,168,333,167,334,166]]`)
    ws.send(`42[10,${ws.id},[2,334,166,335,164,336,163,338,162,339,160,340,158,342,157,344,156,345,154,347,154,348,152,350,150,351,150,353,150,354,150,355,149]]`)
        ws.send(`42[10,${ws.id},[2,355,149,356,149,356,149,357,149,358,149,359,149,361,149,362,149,362,149,363,149,365,149,365,149,366,150,367,150,369,151,369,152]]`)
    ws.send(`42[10,${ws.id},[2,369,152,370,153,371,154,372,156,374,157,375,157,376,159,377,161,378,162,379,163,379,164,380,165,381,166,382,168,382,169,382,170]]`)
        ws.send(`42[10,${ws.id},[2,382,170,383,172,383,172,383,172,383,173,383,173,383,174,383,175,383,176,383,177,383,175,383,175,383,174,383,175,383,177,383,179]]`)
    ws.send(`42[10,${ws.id},[2,383,179,383,180,383,183,383,186,383,188,383,191,383,193,383,194,383,197,383,200,383,202,383,205,383,209,383,210,381,212,381,215]]`)
        ws.send(`42[10,${ws.id},[2,381,215,381,216,381,219,381,221,381,223,381,224,381,226,381,228,381,229,381,231,381,231,381,233,381,234,381,236,379,237,379,238]]`)
    ws.send(`42[10,${ws.id},[2,379,238,379,241,379,243,377,245,377,246,377,247,377,249,377,250,377,251,377,252,377,253,377,253,377,254,376,254,376,255,376,256]]`)
        ws.send(`42[10,${ws.id},[2,376,256,376,256,376,257,375,257,375,258,374,259,374,260,374,260,373,260,372,261,372,261,372,261,372,262,371,262,371,263,371,263]]`)
    ws.send(`42[10,${ws.id},[2,371,263,371,262]]`)
        ws.send(`42[10,${ws.id},[2,394,265,394,267,394,269,393,271,392,274,392,276,391,279,390,281,390,283,389,285,388,287,388,289,388,290,387,291,387,292,386,293]]`)
    ws.send(`42[10,${ws.id},[2,386,293,386,293,386,294,386,295,386,296,386,295,386,294,386,293,386,292,386,290,386,290,386,289,387,287,387,284,387,283,388,283]]`)
        ws.send(`42[10,${ws.id},[2,388,283,388,282,389,280,389,279,389,279,390,278,390,277,390,277,391,277,391,276,392,276,392,276,393,276,393,275,393,274]]`)
    ws.send(`42[10,${ws.id},[2,414,314,414,312,416,310,417,307,418,305,420,303,421,301,421,300,422,298,422,297,423,297,423,295,424,295,425,294,425,293,426,293]]`)
        ws.send(`42[10,${ws.id},[2,426,293,426,292,427,291,427,290,427,290,427,290,427,290,427,290,427,290,427,291,427,292,425,293,425,295,424,297,422,298,421,301]]`)
    ws.send(`42[10,${ws.id},[2,421,301,421,303,420,304,419,305,418,306,418,307,418,307]]`)
        ws.send(`42[10,${ws.id},[2,356,330,356,330,355,330,355,329,355,328,354,328,353,327,353,327,352,327,352,327,351,325,351,325,351,324,350,323,350,323,349,323]]`)
    ws.send(`42[10,${ws.id},[2,349,323,349,322,348,321,348,320,348,319,347,319,346,319,346,318,346,317,344,316,344,315,344,314,343,313,343,312,342,312,342,311]]`)
        ws.send(`42[10,${ws.id},[2,342,311,342,310,342,309,342,309,342,307,342,307,342,306,342,305,343,305,343,305,343,304,344,304,345,303,346,302,346,302,347,300]]`)
    ws.send(`42[10,${ws.id},[2,347,300,347,300,348,298,349,298,349,297,350,297,351,297,351,295,353,295,353,294,354,294,355,293,355,293,355,293,356,293,356,292]]`)
        ws.send(`42[10,${ws.id},[2,356,292,356,292,358,291,358,291,360,290,360,290,362,290,362,290,362,290,363,290,363,290,364,290,365,290,365,290,367,290,367,291]]`)


        ws.send(`42[10,${ws.id},[2,367,291,368,291,369,292,369,292,370,293,370,293,371,293,372,294,373,295,374,296,375,296,376,297,376,297,377,297,377,297,377,297]]`)
        ws.send(`42[10,${ws.id},[2,377,297,378,297,378,295,378,295,378,294,378,293,378,293,379,293,379,292,379,291,379,290,380,290,380,290,381,289,381,288,381,286]]`)
    ws.send(`42[10,${ws.id},[2,381,286,381,286,381,286,382,285,383,284,383,284,383,283,384,283,384,283,384,283,385,283,386,283,386,283,387,283,388,283,388,284]]`)
        ws.send(`42[10,${ws.id},[2,388,284,388,284,388,285,388,286,388,287,388,288,388,288,388,289,388,290,388,290,388,290,388,291,388,292,388,293,388,293,388,294]]`)
    ws.send(`42[10,${ws.id},[2,388,294,388,295,387,295,387,297,386,297,386,297,386,297,386,298,386,298,386,298,386,299,386,300,385,300,385,300,385,302,384,302]]`)
        ws.send(`42[10,${ws.id},[2,384,302,384,303,384,304,384,304,384,305,384,306,384,307,384,307,384,308,384,309,384,309,384,311,384,311,384,312,384,312,384,312]]`)
    ws.send(`42[10,${ws.id},[2,384,312,384,313,384,314,385,315,386,316,386,316,386,317,387,318,388,318,388,319,390,319,390,320,391,321,392,321,392,321,392,321]]`)
        ws.send(`42[10,${ws.id},[2,392,321,393,322,394,322,395,323,395,323,395,323,396,323,397,325,397,325,397,325,398,325,399,325,399,325,400,325,400,325,401,325]]`)
    ws.send(`42[10,${ws.id},[2,401,325,402,324,402,324,403,323,404,323,405,322,406,321,407,321,407,319,408,319,409,318,409,316,410,316,410,315,411,314,412,312]]`)
        ws.send(`42[10,${ws.id},[2,412,312,412,312,413,312,413,311,413,311,413,311,413,310,414,309,414,309,414,308,414,307,415,307,416,307,417,307,418,307,418,307]]`)
    ws.send(`42[10,${ws.id},[2,418,307,419,307,420,307,420,307,421,307,421,309,421,309,422,309,422,310,422,311,422,311,422,312,422,312,422,313,422,314,422,314]]`)
        ws.send(`42[10,${ws.id},[2,422,314,422,315,422,316,422,316,422,317,422,318,422,319,422,319,421,319,421,320,421,321,421,322,420,323,420,323,420,324,419,324]]`)
    ws.send(`42[10,${ws.id},[2,419,324,419,325,418,325,418,325,418,325]]`)
        ws.send(`42[10,${ws.id},[2,361,309,362,309,362,309,363,307,363,307,363,306,364,305,364,305,365,305,365,305,365,305,365,304,367,304,367,304,367,302,367,302]]`)
    ws.send(`42[10,${ws.id},[2,367,302,367,303,367,304,366,304,366,305,365,305,365,307,364,307,364,309,363,309,363,309,362,310,362,312,361,312,360,312,360,313]]`)
        ws.send(`42[10,${ws.id},[2,360,313,359,314,358,315,357,316,356,316,356,316,356,316,356,316,356,314,356,314,356,313,358,312,359,311]]`)
    ws.send(`42[10,${ws.id},[2,422,318,422,319,422,319,421,319,421,320,421,321,421,321,421,322,420,323,420,324,420,325,419,326,418,327,418,327,418,328,416,330]]`)
        ws.send(`42[10,${ws.id},[2,416,330,414,332,414,333,414,334,414,334,413,335,413,336,413,337,413,337,412,337,412,338,412,339,412,339,412,340,412,341,412,342]]`)
    ws.send(`42[10,${ws.id},[2,412,342,412,342,412,342,413,343,413,344,413,346,413,347,413,349,413,349,413,351,414,353,414,354,414,355,414,356,414,356,415,357]]`)
        ws.send(`42[10,${ws.id},[2,415,357,415,358,416,358,416,358,416,359,416,359,417,359,418,359,418,359,420,359,420,359,421,359,421,359,421,359,422,359,423,360]]`)
    ws.send(`42[10,${ws.id},[2,423,360,425,360,425,360,426,362,428,362,429,362,430,362,431,363,433,363,434,363,435,364,436,364,438,364,439,364,441,364,443,364]]`)
        ws.send(`42[10,${ws.id},[2,443,364,444,364,446,364,448,364,451,364,453,364,456,364,458,364,460,364,464,362,467,362,471,360,473,360,476,358,478,358,480,358]]`)
    ws.send(`42[10,${ws.id},[2,480,358,482,357,485,356,487,356,488,355,490,354,491,352,493,351,495,350,496,349,497,349,499,349,500,348,502,346,503,345,504,344]]`)
        ws.send(`42[10,${ws.id},[2,504,344,508,343,510,342,510,341,512,341,514,339,516,337,517,337,518,336,519,335,521,334,522,334,524,334,525,333,526,331,528,330]]`)
    ws.send(`42[10,${ws.id},[2,528,330,530,328,531,327,534,327,534,325,536,325,538,323,539,323,540,321,541,320,542,319,544,318,545,316,547,315,547,313,548,312]]`)
        ws.send(`42[10,${ws.id},[2,548,312,548,312,549,311,550,309,550,308,551,307,551,305,552,304,552,301,552,300,552,298,552,298,552,297,552,297,552,296,552,295]]`)
    ws.send(`42[10,${ws.id},[2,552,295,552,294,552,293,552,293,552,292,551,291,550,291,549,291,548,291,548,292,548,293,548,293,548,295,548,296,548,297,549,298]]`)
        ws.send(`42[10,${ws.id},[2,549,298,549,299,549,301,550,302,550,304,550,305,550,305,551,305,551,306,552,307,553,308,554,309,554,309,554,310,554,311,555,311]]`)
    ws.send(`42[10,${ws.id},[2,555,311,555,311,556,311,557,312,558,312,559,312,559,312,560,312,561,312,561,311,562,311,562,310,562,309,562,307,563,305,563,305]]`)
        ws.send(`42[10,${ws.id},[2,563,305,563,304,563,303,563,302,563,301,563,300,563,299,563,298,563,297,562,297,562,297,562,296,561,296,561,295,562,296,562,297]]`)
    ws.send(`42[10,${ws.id},[2,562,297,562,297,562,298,562,298,562,299,562,300,563,301,563,302,564,303,564,304,564,304,564,305,565,305,565,305,566,305,567,305]]`)
        ws.send(`42[10,${ws.id},[2,567,305,568,305,568,305,569,305,569,305,569,305,571,305,571,305,572,305,573,305,573,305,573,305,574,305,574,304,574,304,574,303]]`)
    },10000)

    setTimeout(() =>{
      
            ws.send(`42[10,${ws.id},[2,574,303,574,302,574,301,574,300,574,299,573,298,573,297,573,297,573,297,573,297,572,296,572,295,571,295,570,294,570,293,570,292]]`)
        ws.send(`42[10,${ws.id},[2,570,292,571,292,572,292,572,293,573,294,573,294,574,295,575,295,575,295,576,295,576,295,577,296,578,296,578,296,579,296,580,296]]`)
    ws.send(`42[10,${ws.id},[2,580,296,580,296,582,296,582,296,583,296,583,295,583,295,583,294,583,293,583,292,582,291,582,290,582,289,581,286,580,284,579,283]]`)
        ws.send(`42[10,${ws.id},[2,579,283,578,281,577,277,577,276,576,275,576,274,576,274,576,272,576,271,576,270,576,270,576,269]]`)
    ws.send(`42[10,${ws.id},[2,554,288]]`)
        ws.send(`42[10,${ws.id},[2,578,293,578,294,576,297,576,299,575,302,573,305,571,307,569,310,568,312,567,315,565,317,563,319,562,321,560,323,558,325,556,328]]`)
    ws.send(`42[10,${ws.id},[2,556,328,554,330,552,332,550,335,547,337,546,339,543,341,540,344,538,346,535,348,532,349,530,351,527,353,525,355,523,356,521,357]]`)
        ws.send(`42[10,${ws.id},[2,521,357,518,359,517,360,515,362,514,363,511,364,510,365,508,366,506,367,503,369,503,369,499,371,497,372,496,372,495,374,493,374]]`)
    ws.send(`42[10,${ws.id},[2,493,374,491,375,490,376,488,377,487,378,486,379,485,379,483,379,482,379,481,380,481,381,480,381,480,381,479,381,479,380,479,379]]`)
        ws.send(`42[10,${ws.id},[2,479,379,479,380,478,381,476,381,476,383,476,383,475,383,474,384,474,385,473,385,473,386,473,386,473,386,471,388,471,388,470,389]]`)
    ws.send(`42[10,${ws.id},[2,470,389,469,391,469,392,469,392,467,393,467,394,467,395,466,395,466,396,466,397,466,399,466,400,466,401,466,401,464,402,464,403]]`)
        ws.send(`42[10,${ws.id},[2,464,403,464,405,464,406,464,406,464,407,464,408,464,409,464,409,464,410,464,411,464,412,464,413,464,415,464,415,464,415,466,415]]`)
    ws.send(`42[10,${ws.id},[2,466,415,466,416,466,416,466,417,466,417,467,417,468,417,469,416,471,416,471,416,473,416,475,416,477,415,480,415,483,415,485,414]]`)
        ws.send(`42[10,${ws.id},[2,485,414,488,413,492,412,494,411,497,410,501,409,503,409,506,409,509,408,511,408,514,408,516,408,518,408,519,408,521,408,522,408]]`)
    ws.send(`42[10,${ws.id},[2,522,408,523,408,524,408,525,408,525,408,525,409,526,409,526,411,527,411,527,411,527,413,527,413,527,415,527,417,527,419,527,422]]`)
        ws.send(`42[10,${ws.id},[2,527,422,527,423,527,425,527,427,525,430,525,430,525,434,524,436,524,437,522,438,521,440,520,441,518,445,517,446,516,446,515,448]]`)
    ws.send(`42[10,${ws.id},[2,515,448,513,450,511,452,510,452,508,453,505,455,503,456,501,457,498,459,495,460,492,460,488,462,485,463,482,464,478,466,474,467]]`)
        ws.send(`42[10,${ws.id},[2,474,467,473,467,469,468,465,470,461,471,458,473,453,473,450,475,448,475,444,475,441,475,437,475,434,475,430,475,428,475,424,475]]`)
    ws.send(`42[10,${ws.id},[2,424,475,421,475,418,475,415,475,414,475,413,475,411,475,409,475,409,475,407,475,407,475,406,473,406,473,404,473,403,472,403,471]]`)
        ws.send(`42[10,${ws.id},[2,403,471,402,471,402,470,402,469,402,468,402,467,402,466,402,464,402,462,402,462,402,460,402,460,402,459,402,459,403,458,404,457]]`)
    ws.send(`42[10,${ws.id},[2,404,457,405,457,405,457,406,457,407,457,407,457,409,457,409,457,410,457,411,457,413,457,414,456,416,456,418,455,419,455,421,454]]`)
        ws.send(`42[10,${ws.id},[2,421,454,422,453,423,452,425,452,428,452,429,451,431,450,433,449,434,448,436,448,437,448,439,446,441,446,443,445,444,445,444,445]]`)
    ws.send(`42[10,${ws.id},[2,444,445,445,444,446,443,447,443,447,442,448,441,449,440,450,439,450,439,450,438,450,438,450,438,450,437,450,436,450,435,450,434]]`)
        ws.send(`42[10,${ws.id},[2,450,434,450,434,450,434,450,433,449,432,448,432,447,432,446,432,446,432,445,432,444,432,444,432,444,432,443,432,442,432,441,432]]`)
    ws.send(`42[10,${ws.id},[2,441,432,441,432,440,432,439,432,439,432,437,432,437,432,436,432,436,432,436,432,436,432,435,432,434,433,433,433,432,433,432,433]]`)
        ws.send(`42[10,${ws.id},[2,432,433,431,433,430,433,429,434,429,434,428,434,427,434,425,436,424,436,422,436,421,436,421,436,419,437,418,437,416,438,415,438]]`)
    ws.send(`42[10,${ws.id},[2,415,438,414,438,413,438,413,438,411,439,410,439,409,439,408,439,407,439,406,439,406,439,404,439,403,439,402,439,401,439,399,439]]`)
        ws.send(`42[10,${ws.id},[2,399,439,397,438,395,438,394,437,392,436,390,434,388,433,386,431,384,430,383,429,381,428,379,427,377,425,377,424,375,423,373,422]]`)
    ws.send(`42[10,${ws.id},[2,373,422,372,420,372,418,370,418,370,416,370,415,369,413,368,410,367,409,366,408,365,406,365,404,365,402,363,401,363,399,363,397]]`)
        ws.send(`42[10,${ws.id},[2,363,397,362,394,362,393,362,390,362,388,362,386,360,385,360,383,360,381,360,379,360,378,360,376,360,374,360,373,360,371,360,370]]`)
    ws.send(`42[10,${ws.id},[2,360,370,360,369,360,368,360,367,359,366,359,365,359,364,358,364,358,362,358,362,358,361,358,360,357,358,357,356,356,355,356,353]]`)
        ws.send(`42[10,${ws.id},[2,356,353,356,351,356,351,356,350,356,349,356,349,355,349,355,348,355,347,355,346,355,346,355,345,355,344,355,344,355,344,355,342]]`)
    ws.send(`42[10,${ws.id},[2,355,342,355,342,354,342,354,341,353,341,353,340,353,339,352,337,352,337,352,336,351,335,351,335,351,334,349,334,350,334,351,334]]`)
        ws.send(`42[10,${ws.id},[2,351,334,351,334,351,335,351,336,352,337]]`)
    ws.send(`42[10,${ws.id},[2,388,428,386,428,381,429,377,430,374,430,370,431,367,432,363,433,362,434,359,435,357,435,355,436,355,436,353,438,351,438,350,438]]`)
        ws.send(`42[10,${ws.id},[2,350,438,349,439,349,440,348,441,348,441,348,442,348,443,348,444,348,445,348,445,348,446,348,447,348,448,349,449,349,450,350,450]]`)
    ws.send(`42[10,${ws.id},[2,350,450,351,450,351,451,351,451,353,452,353,452,354,452,355,452,355,452,356,452,357,452,358,453,359,453,360,453,361,453,362,453]]`)
        ws.send(`42[10,${ws.id},[2,362,453,362,453,363,453,365,453,366,453,369,453,371,452,374,451,377,450,380,448,383,447,384,445,387,445,389,444,390,443,392,442]]`)
    ws.send(`42[10,${ws.id},[2,392,442,393,442,394,441,395,441,396,441]]`)
    
    
        ws.send(`42[10,${ws.id},[2,356,338,355,338,349,337,346,336,342,335,336,333,329,330,322,328,314,325,305,321,298,318,291,314,283,309,276,305,269,304,263,300]]`)
    ws.send(`42[10,${ws.id},[2,263,300,257,297,251,295,248,293,244,291,242,290,238,290,237,288,235,286,234,286,233,285,233,285,232,284,231,284,231,284,232,284]]`)
        ws.send(`42[10,${ws.id},[2,232,284,233,284,233,285,235,285,235,285,237,285,237,285,237,284,237,284,235,283,235,282,234,281,233,281,233,279,233,278,231,277]]`)
    ws.send(`42[10,${ws.id},[2,231,277,231,276,229,275,229,275,228,274,228,272,227,272,226,271,226,270,226,269,225,268,224,268,223,267,223,266,223,265,222,265]]`)
        ws.send(`42[10,${ws.id},[2,222,265,222,264,222,264,222,263,222,263,222,262,222,262]]`)
    ws.send(`42[10,${ws.id},[2,216,237,217,238,217,240,218,242,220,245,221,247,222,249,223,253,224,254,225,258,226,260,227,262,228,265,228,267,228,269,229,270]]`)
        ws.send(`42[10,${ws.id},[2,229,270,229,271,229,272,229,274,229,274,229,275,228,275,226,275,226,275,224,275,222,274,220,272,218,270,217,268,215,266,214,265]]`)
    ws.send(`42[10,${ws.id},[2,214,265,212,263,212,262,211,260,210,260,210,258,210,258,208,257,208,256,208,256,209,256,210,256,210,256,211,256,212,257,212,258]]`)
        ws.send(`42[10,${ws.id},[2,212,258,212,260,212,260,213,260,213,261,214,263,214,263,214,265,214,265,214,267,214,268,213,269,212,270,212,271,210,272,208,273]]`)
    ws.send(`42[10,${ws.id},[2,208,273,206,274,205,274,201,274,200,272,195,270,192,268,190,267,188,265,187,263,185,260,184,259,184,257,182,254,182,253,182,253]]`)
        ws.send(`42[10,${ws.id},[2,182,253,182,252,182,251,183,251,184,251,184,252,184,253,184,254,185,254,185,256,185,256,185,258,185,259,185,260,185,260,185,261]]`)
    ws.send(`42[10,${ws.id},[2,185,261,185,263,185,264,185,266,185,267,185,268,184,268,183,269,182,270,180,270,178,270,177,270,176,270,174,270,172,268,171,268]]`)
        ws.send(`42[10,${ws.id},[2,171,268,170,267,170,267,168,265,168,264,168,262,166,261,166,260,166,259,165,258,165,256,165,256,165,255,165,254,165,254,166,254]]`)
    ws.send(`42[10,${ws.id},[2,166,254,166,255,166,256,168,258,168,258,168,259,169,260,170,261,170,262,171,264,173,266,175,268,177,271,178,273,180,276,182,278]]`)
    
    
        ws.send(`42[10,${ws.id},[2,182,278,184,282,185,284,189,289,191,291,192,294,194,295,196,298,197,300,198,301,200,303,200,305,200,305,202,307,203,307,205,308]]`)
    ws.send(`42[10,${ws.id},[2,205,308,205,309,207,311,208,311,208,312,210,313,212,314,213,314,214,316,215,317,216,318,218,319,219,319,221,321,223,321,225,323]]`)
        ws.send(`42[10,${ws.id},[2,225,323,228,325,230,325,234,327,237,328,240,330,244,331,245,332,248,333,251,334,253,335,256,335,259,337,261,339,264,339,266,341]]`)
    ws.send(`42[10,${ws.id},[2,266,341,269,342,272,342,274,344,278,344,281,347,286,348,288,349,291,349,295,351,296,352,299,353,301,353,303,355,306,356,309,356]]`)
        ws.send(`42[10,${ws.id},[2,309,356,311,358,314,358,317,360,320,362,323,362,326,364,329,365,332,365,333,367,335,367,337,369,339,369,340,369,342,370,342,370]]`)
    ws.send(`42[10,${ws.id},[2,342,370,344,371,344,371,345,371,346,371,346,371,347,372,348,372,348,372,349,372,349,371]]`)
        ws.send(`42[10,${ws.id},[2,377,258,377,260,376,261,375,265,373,267,372,268,371,270,370,272,370,274,369,275,369,275,369,276,369,278,369,279,368,279,368,280]]`)
    ws.send(`42[10,${ws.id},[2,368,280,367,281,367,281,366,281,366,283,366,283,365,284,365,286,365,286,364,287,363,288,363,288,363,289,363,290,362,290,362,291]]`)
        ws.send(`42[10,${ws.id},[2,362,291,361,291,361,291,361,290]]`)

            ws.send(`42[10,${ws.id},[2,469,346,471,348,471,348,471,349,472,350,473,351,473,352,473,353,474,354,474,355,474,356,474,356,474,357,475,358,475,358,476,360]]`)
        ws.send(`42[10,${ws.id},[2,476,360,476,361,476,362,476,362,476,364,477,364,477,365,478,366,478,367,478,367,478,368,478,369,478,370,479,368,479,367]]`)
    ws.send(`42[10,${ws.id},[2,429,295,429,296,431,297,433,297,434,297,435,299,436,300,436,300,437,302,438,302,438,303,439,304,439,304,441,305,441,305,441,306]]`)
        ws.send(`42[10,${ws.id},[2,441,306,442,307,442,307,443,307,443,308,443,309,443,309,443,310,444,310,444,311,444,312,444,312,444,312,444,313,444,314,444,314]]`)
    ws.send(`42[10,${ws.id},[2,444,314,444,315,444,316,444,317,444,318,444,318,444,319,444,319,444,319,444,321,444,321,444,322,443,322,443,323,443,323,442,324]]`)
        ws.send(`42[10,${ws.id},[2,442,324,441,324,440,325,439,326,439,326,438,326,437,326,437,326,436,326,436,326,435,326,434,326,434,325,433,325,432,325,432,324]]`)
    ws.send(`42[10,${ws.id},[2,432,324,431,324,430,323,429,323,429,322,429,322,428,321,427,321,427,320,425,320,425,319,424,319,423,319,423,319,422,319,421,318]]`)
        ws.send(`42[10,${ws.id},[2,421,318,421,318,421,317]]`)
    ws.send(`42[10,${ws.id},[2,299,39,300,39,301,39,302,39,302,39,302,39,303,40,303,41,303,42,303,43,303,43,303,44,302,44,302,45,302,45,302,45]]`)
        ws.send(`42[10,${ws.id},[2,302,45,301,45,300,45,299,45,298,45,298,45,297,45,296,45,295,44,295,43,294,42,293,41,293,41,292,40,291,39,290,39]]`)
    ws.send(`42[10,${ws.id},[2,290,39,291,39,292,39,293,39,293,39,294,40,295,40,295,41,295,41,296,43,296,43,296,44,297,45,297,45,297,46,297,47]]`)
        ws.send(`42[10,${ws.id},[2,297,47,297,48,297,48,297,49,296,49,296,50,296,50,295,50,295,51,295,51,294,51,293,51,293,51,292,51,291,51,290,51]]`)
    ws.send(`42[10,${ws.id},[2,290,51,289,51,289,50,288,50,288,49,286,48,286,48,284,46,282,45,282,45,281,45,280,44,279,43,279,43,277,43,277,42]]`)
        ws.send(`42[10,${ws.id},[2,277,42,276,42,276,41,276,41,277,42,278,43,279,43,280,43,281,44,281,45,282,45,282,46,283,46,284,47,284,48,284,48]]`)
    ws.send(`42[10,${ws.id},[2,284,48,284,50,284,51,284,52,283,54,283,56,282,59,281,61,279,64,277,67,275,68,274,71,272,73,272,75,271,75,270,76]]`)
        ws.send(`42[10,${ws.id},[2,270,76,270,76,268,76,268,77,268,77,268,78,269,78,269,76,270,76,270,76,271,76,272,75,272,75,274,73,275,72,277,71]]`)
    ws.send(`42[10,${ws.id},[2,277,71,279,69,281,68,282,67,286,66,288,66,288,64,290,64,292,64,293,64,293,64,294,64,295,64,295,64,296,64,296,64]]`)
    },12500)
    setTimeout(() => {
        ws.send(`42[10,${ws.id},[2,296,64,297,64,298,64,298,65,298,66,298,67,298,68,298,68,298,69,298,71,297,73,296,74,295,76,295,78,293,80,289,83]]`)
    ws.send(`42[10,${ws.id},[2,289,83,288,84,286,86,284,88,282,89,281,89,279,91,277,91,276,91,274,91,272,91,270,90,268,89,267,87,265,85,261,83]]`)
        ws.send(`42[10,${ws.id},[2,261,83,258,82,254,79,249,76,244,71,237,68,233,65,228,61,224,56,221,54,218,51,216,48,215,46,214,45,214,45,214,43]]`)
        ws.send(`42[10,${ws.id},[2,214,43,213,42]]`)
    ws.send(`42[10,${ws.id},[2,305,92,305,92,307,94,309,94,309,95,310,96,311,96,311,98,312,98,312,98,313,98,314,99,314,98]]`)
        ws.send(`42[10,${ws.id},[2,237,79,238,79,241,79,244,80,245,80,246,81,248,81,250,82,251,82,251,82,252,83,254,83,254,83,254,83,255,83,256,83]]`)
    ws.send(`42[10,${ws.id},[2,256,83,256,84,258,85,258,85,258,86,258,87,258,87,258,88,257,89,256,89,256,89,254,91,252,91,252,92,251,94,249,94]]`)
    ws.send(`42[10,${ws.id},[2,249,94,248,95,247,96,246,97,245,98,244,98,244,98,244,98,243,98,243,99,242,99,242,98,243,97,244,96]]`)
    ws.send(`42[10,${ws.id},[2,110,93,111,93,113,94,113,94,115,96,117,96,117,96,118,96,119,97,119,97,120,98,120,98,120,98,121,98,122,98,122,99]]`)
    ws.send(`42[10,${ws.id},[2,122,99,122,99,122,100,122,101,122,101,121,102,121,103,120,104,120,105,119,106,117,109,115,112,111,115,109,119,107,122,105,125]]`)
    ws.send(`42[10,${ws.id},[2,105,125,104,127,102,129,100,131,99,131,98,133,97,133,96,133,96,133,95,133,94,133,93,133,92,133,92,131,91,131,90,131]]`)
    ws.send(`42[10,${ws.id},[2,90,131,90,130,90,129,90,128,90,127,90,127,90,126,90,125,90,124,90,123,90,122,90,122,91,121,92,121,94,121,94,121]]`)
    ws.send(`42[10,${ws.id},[2,94,121,95,121,96,121,97,122,98,123,100,124,102,126,104,127,106,129,106,130,108,133,110,135,110,138,111,142,111,145,113,149]]`)
    ws.send(`42[10,${ws.id},[2,113,149,113,154,113,157,112,160,112,161,111,163,111,164,111,165,111,166,111,166,110,167]]`)
    ws.send(`42[10,${ws.id},[2,124,143,126,142,126,141,126,139,127,137,128,135,129,135,129,135,129,134,129,133,130,133,130,133,131,133,131,132,132,132,132,131]]`)
    ws.send(`42[10,${ws.id},[2,132,131,132,130,132,129,132,131,132,132,132,133]]`)
    ws.send(`42[10,${ws.id},[2,71,135,73,135,74,135,74,136,76,136,78,136,78,138,79,138,80,139,81,140,82,140,82,141,82,142,83,142,83,142,83,143]]`)
    ws.send(`42[10,${ws.id},[2,83,143,83,143,83,144,83,145,83,145,83,147,83,147,83,148,83,149,82,149,82,149,81,149,80,149,79,148,78,147,77,146]]`)
    ws.send(`42[10,${ws.id},[2,77,146,76,146,75,145,75,145,74,145,74,144,73,144,73,143,73,142,74,143,74,143,75,143,76,144,76,145,77,145,78,146]]`)
    ws.send(`42[10,${ws.id},[2,78,146,79,147,79,148,80,148,80,149,80,149,80,150,80,150,80,150,80,151,80,152,80,153,80,154,78,154,78,154,76,155]]`)

        ws.send(`42[10,${ws.id},[2,67,150,68,150,69,150,71,150,71,152,71,152,72,152,73,152,73,153,74,154,74,154,74,155,74,156,74,157,74,158,74,160]]`)
    ws.send(`42[10,${ws.id},[2,74,160,74,162,74,164,73,166,72,167,72,169,70,170,70,171,69,172,67,172,67,172,65,173,63,174,61,175,60,175,59,175]]`)
        ws.send(`42[10,${ws.id},[2,59,175,56,175,55,175,53,175,52,175,50,174,48,173,46,172,45,172,45,172,44,170,43,169,43,168,43,166,43,166,43,165]]`)
    ws.send(`42[10,${ws.id},[2,43,165,43,164,43,164,44,164,45,164,45,164,45,164,46,164,47,164,48,164,48,165,49,165,50,166,50,166,52,166,52,168]]`)

    // 

        ws.send(`42[10,${ws.id},[2,52,168,52,168,52,169,52,170,53,170,53,171,53,172,53,173,53,175,52,176,52,179,50,181,48,184,46,187,45,188,41,191]]`)
    ws.send(`42[10,${ws.id},[2,41,191,37,193,34,194,31,194,28,195,24,195,22,195,20,195,18,194,16,194,15,193,14,193,13,191,13,189,13,187,13,187]]`)
        ws.send(`42[10,${ws.id},[2,13,187,13,185,13,183,13,182,13,180,14,179,15,179,15,177]]`)
    ws.send(`42[10,${ws.id},[2,27,149,28,149,29,149,29,149,30,150,30,150,30,150,30,150]]`)


        ws.send(`42[10,${ws.id},[2,445,369,446,369,446,371,446,371,446,371,447,371,447,371,448,372,448,372,448,372,448,373,450,373,450,374,450,374,450,375,450,376]]`)
    ws.send(`42[10,${ws.id},[2,450,376,450,376,450,377,450,378,450,378,450,379,450,379,449,379,449,380,448,380,448,381,448,381,447,381,446,381,446,381,445,381]]`)
    ws.send(`42[10,${ws.id},[2,445,381,444,381,444,381,443,381,442,381,441,381,440,381,439,381,438,381,437,381,436,381,434,381,432,381,430,381,429,381,428,381]]`)
    ws.send(`42[10,${ws.id},[2,428,381,425,381,425,381,423,379,422,379,421,379,421,379,420,379,420,379,421,380,421,380,421,380,422,380,423,380,423,380,425,380]]`)
    ws.send(`42[10,${ws.id},[2,425,380,426,380,427,380,428,380,429,380,429,380,430,380,431,380,433,380,434,380,435,380,436,380,437,380,437,380,438,380,439,380]]`)
    ws.send(`42[10,${ws.id},[2,439,380,440,380,440,381,441,381,441,381,441,381,441,382,441,383,441,383,440,384,439,385,438,386,438,386,437,386,437,387,437,389]]`)
    ws.send(`42[10,${ws.id},[2,437,389,437,390,437,392,436,393,436,395,436,397,436,398,436,401,435,402,435,404,435,405,435,407,435,408,434,409,434,409,434,410]]`)
    ws.send(`42[10,${ws.id},[2,434,410,434,411,433,411,433,412,432,413,432,415,432,415,431,415,430,416,430,416,429,418,429,418,428,418,427,419,427,419,425,419]]`)
    ws.send(`42[10,${ws.id},[2,425,419,424,419,423,419,423,419,421,419,420,419,418,418,416,416,414,415,412,414,409,413,407,412,406,411,404,409,404,409]]`)
    ws.send(`42[10,${ws.id},[2,447,395,448,396,449,397,450,397,450,398,451,399,451,399,451,400,453,401,453,401,453,402,453,402,453,403,453,402]]`)
    ws.send(`42[10,${ws.id},[2,384,358,384,360,386,362,388,364,390,365,392,366,393,368,395,370,396,371,398,373,399,375,401,376,402,378,404,379,404,380,406,381]]`)
    ws.send(`42[10,${ws.id},[2,406,381,407,381,407,383,407,383,408,384,409,385,410,385,411,385,411,386,411,386,411,386,412,386,412,388,413,388,413,388,413,388]]`)
    ws.send(`42[10,${ws.id},[2,413,388,413,389]]`)
    ws.send(`42[10,${ws.id},[2,394,379,393,380,393,381,393,383,392,383,392,384,392,385,392,385,392,386,392,386,392,387,392,388,392,388,392,388,392,389,393,389]]`)
    ws.send(`42[10,${ws.id},[2,393,389,393,390,393,390,393,390,394,391,395,391,395,391,396,391,397,391,397,390,398,390,398,390,399,390,399,389,399,389,399,388]]`)
    ws.send(`42[10,${ws.id},[2,399,388,399,388,399,388,400,388,400,388,400,386,402,386,402,386,402,387,401,388,401,388,400,388,400,389,399,390,399,390,399,392]]`)
    ws.send(`42[10,${ws.id},[2,399,392,397,393,397,393,396,395,395,395,395,397,394,397,394,397,394,398,394,399]]`)
    ws.send(`42[10,${ws.id},[2,679,146,679,147,680,149,680,150,682,150,682,152,684,154,686,155,687,156,687,157,689,158,689,159,690,159,691,160,691,160,693,161]]`)
    ws.send(`42[10,${ws.id},[2,693,161,693,162,694,162,694,163,695,163,695,163,695,163,696,162,696,161,696,160,696,159,696,159,696,158,695,157,695,156,694,154]]`)
    ws.send(`42[10,${ws.id},[2,694,154,693,154,693,153,693,152,692,151,691,150,691,150,690,149,689,149,689,148,688,148,687,148,687,148,687,147,686,147,686,147]]`)
    ws.send(`42[10,${ws.id},[2,686,147,686,147,685,147,684,147,683,147,682,147,682,147,682,147,681,148,681,149,680,150,680,152,677,155,675,157,672,161,669,167]]`)
    ws.send(`42[10,${ws.id},[2,669,167,666,172,662,175,658,179,656,184,653,186,652,187,650,188,650,189,649,190,648,190,647,190,646,189,645,187,645,186,643,185]]`)
    ws.send(`42[10,${ws.id},[2,643,185,643,183,643,180,642,177,642,173,642,171,640,167,640,164,640,159,640,156,640,152,640,150,640,148,640,146,640,145,640,143]]`)
    ws.send(`42[10,${ws.id},[2,640,143,640,142,640,142,640,142,640,141,641,141,642,141,642,141,643,141,643,141,644,142,645,142,645,142,647,142,649,142,649,142]]`)
    ws.send(`42[10,${ws.id},[2,649,142,650,142,652,143,653,143,654,144,656,144,657,145,658,145,658,145,658,146,659,147,659,147,659,149,659,150,659,150,659,152]]`)
    ws.send(`42[10,${ws.id},[2,659,152,659,153,659,154,659,156,659,157,659,158,658,160,658,161,657,161,656,163,656,164,656,164,655,164,653,164,652,164,652,164]]`)
    ws.send(`42[10,${ws.id},[2,652,164,650,164,650,164,649,164,649,164,648,162,647,161,647,161,647,159,647,158,647,157,647,156,647,154,647,153,647,152,648,152]]`)
    ws.send(`42[10,${ws.id},[2,648,152,649,151,649,150,650,150,650,150,650,150,651,150,652,150,652,150,653,150,654,150,655,150,656,151,656,152,656,154,656,154]]`)
    ws.send(`42[10,${ws.id},[2,656,154,656,155,656,156,656,157,656,159,655,161,654,163,654,164,652,168,650,170,649,173,649,175,647,177,646,178,644,179,643,179]]`)
    ws.send(`42[10,${ws.id},[2,643,179,642,179,641,179,640,179,638,179,636,179,636,179,635,179,633,178,633,177,631,176,630,175,628,173,628,172,627,171,626,170]]`)
    ws.send(`42[10,${ws.id},[2,626,170,626,168,625,166,624,166,623,164,623,164,622,163,622,163,622,163,622,162,622,162,623,163,624,164,625,164,626,165,626,166]]`)
    ws.send(`42[10,${ws.id},[2,626,166,626,167,627,168,628,169,628,170,629,170,629,170,629,172,629,172,629,172,630,172,630,173,630,173,630,174,630,175,630,176]]`)
    ws.send(`42[10,${ws.id},[2,630,176,630,177,629,177,629,178,628,179,627,179,626,179,624,180,623,180,621,180,621,180,619,180,618,180,616,180,615,179,614,179]]`)
    ws.send(`42[10,${ws.id},[2,614,179,613,177,611,177,610,176,608,174,606,172,606,172,605,170,603,169,602,167,600,166,599,164,599,164,599,163,598,162,597,162]]`)
    ws.send(`42[10,${ws.id},[2,597,162,597,161,596,161,596,159,596,159,596,159,598,159,598,160,598,161,599,161,599,161,599,163,600,164,601,164,602,164,603,164]]`)
    ws.send(`42[10,${ws.id},[2,603,164,603,165,603,166,604,166,605,166,605,166,605,167,606,167,606,168,606,169,607,170,607,170,607,171,607,172,607,172,607,172]]`)
    ws.send(`42[10,${ws.id},[2,607,172,606,173,606,174,605,175,603,177,603,179,601,180,599,182,598,184,596,185,594,187,592,187,592,187,591,187,590,187,589,188]]`)
    ws.send(`42[10,${ws.id},[2,589,188,589,188,588,188,588,187,588,187,589,187,589,187,591,186,591,186,591,185,592,184,592,184,594,183,595,183,596,182,597,181]]`)

        ws.send(`42[10,${ws.id},[2,597,181,598,181,599,180,599,180,599,180,600,179,601,179,601,179,601,178,602,178,602,177,602,176,603,176,604,175,604,174]]`)
    ws.send(`42[10,${ws.id},[2,606,154,606,156,606,156,606,157,606,157,606,157,606,157,607,157,608,157,608,157,610,157,610,157,611,157,612,157,612,157,613,157]]`)
        ws.send(`42[10,${ws.id},[2,613,157,613,157,613,157,613,158,613,158,613,158,612,158,612,157,611,157,610,157,608,156,608,156,607,155,606,154,606,154,606,154]]`)
    ws.send(`42[10,${ws.id},[2,606,154,606,153,605,153,605,152,605,152,605,151,605,150,606,150,606,150,606,151]]`)
        ws.send(`42[10,${ws.id},[2,363,63,363,64,365,64,365,65,366,65,367,65,367,66,369,66,370,67,370,67,370,67,372,68,373,68,374,68,374,69,375,69]]`)
    ws.send(`42[10,${ws.id},[2,375,69,376,69,376,69,376,70,377,70,377,70,378,71,379,71,379,71,380,71,381,71,382,71,383,71,383,71,384,71,384,71]]`)

        ws.send(`42[10,${ws.id},[2,384,71,386,71,387,71,388,71,388,71,389,71,391,70,392,70,393,69,393,69,394,69,395,68,397,68,397,68,398,68,399,67]]`)
        ws.send(`42[10,${ws.id},[2,399,67,399,66,400,65,401,65,402,64,402,64,403,64,403,63,404,62,405,61,405,61,406,61,406,60,406,59,406,59,406,57]]`)
    ws.send(`42[10,${ws.id},[2,406,57,406,56,406,55,406,55,406,54,406,54,406,54,406,52,406,54]]`)
        ws.send(`42[10,${ws.id},[2,388,29,389,29,390,29,392,29,393,28,395,28,395,28,397,27,399,27,399,26,400,26,401,25,402,25,402,25,403,25,405,25]]`)
    ws.send(`42[10,${ws.id},[2,405,25,406,25,407,25,407,24,409,24,409,24,410,24,411,24,413,24,413,24,414,24,414,24,414,24,416,24,416,24,415,24]]`)
        ws.send(`42[10,${ws.id},[2,415,24,415,25,414,25,414,26,414,27,413,27,411,27,411,29,409,29,407,29,407,29,407,29,406,29,404,30,404,30,403,30]]`)
    ws.send(`42[10,${ws.id},[2,403,30,402,30,401,30,400,30,399,30,399,30,399,30,398,30,397,30,397,30,397,29,397,29,397,27,397,27,398,27,398,27]]`)
        ws.send(`42[10,${ws.id},[2,398,27,399,27,399,26,400,26,401,26,402,26,403,26,404,26,405,26,406,26,406,26,407,26,407,26,407,26,409,26]]`)
    ws.send(`42[10,${ws.id},[2,344,36,344,36,346,36,348,36,348,36,349,36,351,36,352,36,353,35,355,35,356,34,356,34,358,34,359,34,360,34,360,34]]`)
        ws.send(`42[10,${ws.id},[2,360,34,362,34,362,34,363,34,363,34,364,34,365,34,366,34,367,34,367,34,368,34,368,34,368,36,368,36,367,37,367,38]]`)
    ws.send(`42[10,${ws.id},[2,367,38,365,38,365,39,364,39,363,40,362,40,362,40,360,40,360,40,359,40,357,40,356,40,355,40,354,40,353,40,351,40]]`)
        ws.send(`42[10,${ws.id},[2,351,40,351,40,350,40,349,39,348,39,348,39,347,39,347,38,347,38,346,38,346,37,346,36,346,35,347,35,348,35,348,35]]`)
    ws.send(`42[10,${ws.id},[2,348,35,349,35,349,35,350,35,351,35,353,35,353,35,354,35,355,35,355,35,356,35,357,35,358,35,358,35,359,35,360,35]]`)
        ws.send(`42[10,${ws.id},[2,360,35,360,35,362,35,362,35,362,36,362,36,362,37,361,37,360,37,360,37,359,37,358,37,356,37,356,37,355,37,355,37]]`)
    ws.send(`42[10,${ws.id},[2,355,37,355,37,354,37,353,37,352,37,351,37,351,36,353,35,354,35]]`)
        ws.send(`42[10,${ws.id},[2,399,67,401,67,406,67,409,66,413,66,416,65,420,65,423,65,425,64,429,64,432,64,435,64,437,64,440,64,443,64,444,64]]`)
    ws.send(`42[10,${ws.id},[2,444,64,446,64,448,64,450,64,451,64,452,64,453,64,453,64,455,64,456,64,457,64,457,64,458,64,458,65,458,66,458,66]]`)
        ws.send(`42[10,${ws.id},[2,458,66,458,67,458,68,458,69,458,69,457,70,457,71,457,73,457,73,456,74,456,75,456,76,455,76,455,77,454,77,454,78]]`)
    ws.send(`42[10,${ws.id},[2,454,78,453,78,453,79,453,79,453,80,452,80,451,80,451,80,451,80,450,80,449,80,448,80,447,80,446,80,446,80,444,80]]`)
        ws.send(`42[10,${ws.id},[2,444,80,444,79,443,79,443,78,441,78,439,78,438,78,437,78,436,76,434,76,432,76,430,76,427,75,425,75,422,75,420,75]]`)
    ws.send(`42[10,${ws.id},[2,420,75,417,73,414,73,412,73,409,73,407,73,404,72,404,72,402,71,402,71,400,71,399,71,399,71,399,70,398,70,397,70]]`)
        ws.send(`42[10,${ws.id},[2,397,70,396,70,395,70,395,70,394,70,393,70,393,70,392,70,392,70,392,69,392,69]]`)
    ws.send(`42[10,${ws.id},[2,456,60,456,58,456,56,456,55,455,52,455,50,455,46,455,43,455,40,455,37,455,34,456,31,456,29,457,26,458,24,459,22]]`)
        ws.send(`42[10,${ws.id},[2,459,22,460,20,461,18,463,17,464,15,464,14,465,13,466,13,468,11,469,10,470,9,472,8,473,6,474,4,476,3,478,2]]`)
    ws.send(`42[10,${ws.id},[2,478,2,478,2,480,1,480,-1,481,-1,482,-2,482,-3,483,-3,484,-3,485,-4,485,-4,486,-5,486,-6,488,-6,488,-7,488,-8]]`)
        ws.send(`42[10,${ws.id},[2,488,-8,489,-10,491,-10,492,-12,492,-13,494,-14,494,-15,495,-15,496,-17,497,-18,498,-19,499,-19,500,-20,501,-21,502,-22,503,-23]]`)
    ws.send(`42[10,${ws.id},[2,503,-23,503,-24,504,-24,505,-25,506,-25,506,-26,507,-26,508,-26,508,-26,509,-26]]`)
        ws.send(`42[10,${ws.id},[2,522,8,522,8,522,7,523,6,523,6,524,5,524,4,524,4,524,3,525,3,525,2,525,2,526,2,527,2,527,3,527,4]]`)
    ws.send(`42[10,${ws.id},[2,527,4,527,6,527,6,527,7,527,8,527,9,527,9,527,10,527,12,527,13,526,14,526,16,525,17,525,17,525,19,525,20]]`)
        ws.send(`42[10,${ws.id},[2,525,20,525,22,525,23,524,24,524,25,523,27,522,28,522,29,522,31,521,31,520,32,519,33,518,34,518,34,517,34,515,35]]`)
    ws.send(`42[10,${ws.id},[2,515,35,515,36,513,36,511,37,510,37,510,37,508,38,507,38,506,38,504,38,504,39,504,39,504,40,504,41,504,41,504,42]]`)
        ws.send(`42[10,${ws.id},[2,504,42,504,43,503,44,503,45,503,46,503,46,503,46,502,48,501,49,500,50,500,50,499,52,499,52,498,52,497,52,495,53]]`)
    ws.send(`42[10,${ws.id},[2,495,53,495,53,495,54,494,54,492,54,491,54,489,54,488,54,488,54,487,54,487,54,485,54,484,54,483,54,483,54,482,54]]`)
        ws.send(`42[10,${ws.id},[2,482,54,481,55,480,55,480,56,480,56,479,57,478,57,478,57,476,58,476,59,476,59,476,59,475,59,475,61,474,61,474,61]]`)
    ws.send(`42[10,${ws.id},[2,474,61,473,61,473,61,472,61,471,61,471,60,470,60,469,60,467,60,467,59,466,59,466,59,464,59,463,59,462,59,461,59]]`)
        ws.send(`42[10,${ws.id},[2,461,59,460,59,459,59,458,59,458,59,457,59,457,59,455,59]]`)
    },15000)


}
                                  if(msg.data.indexOf('42["16"') && autoskip===true){
    setTimeout(()=>{
      ws.send('42[25,'+ws.id+']');},1000)

                                  }
                if(msg.data.indexOf('42["47"]')!=-1 && autoreport===true){

      ws.send('42[35,'+ws.id+']')

                }

                if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 | msg.data.indexOf(''+ws.longID+',1')!=-1) && antikick===true){

      ws.send('42[24,'+ws.id+']');
      LUNA_("rejoin",window.location.href.split("/")[2],nv[1],nv[2],nv[3],nv[4])
}
      if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 || msg.data.indexOf(''+ws.longID+',1')!=-1) && autokick === true) {
  let msgautokick = msg.data.split(',');
  let autokickid = msgautokick[1].replace(/"/g, '');
                   LUNA_("kick",autokickid)
                }
                if(msg.data.indexOf('42["16"')!=-1){
                    let objlist=JSON.parse('["16"'+msg.data.split('42["16"')[1])
                    var word1=objlist[1]
                    var word2=objlist[3]
                LUNA_("word1",word1)
                LUNA_("word2",word2)

}


}})}) 
      break;
case "broadcast":let b=nv[1];g('broadcast',b);break;
case "broadcastspam":let be=nv[1];g('broadcastspam',be);break;
case "msg":let m=nv[1];g('msg',m);break;
case "msgspam":let me=nv[1];g('msgspam',me);break;
case "answer":let a=nv[1];g('answer',a);break;
case "answerspam":let ae=nv[1];g('answerspam',ae);break;
case "exit":g('exit','1');break;
case "report":g('report','1');break;
case "0xbE":g('0xbE','1');break;
case "jump":g('jump','1');break;
case "tips":g('tips','1');break;
case "accept1":g('accept1','1');break;
case "accept2":g('accept2','1');break;
case "kick":let k=nv[1];g('kick',k);break;
case "rejoin":g('rejoin','1');break;
case "afkconfirm":g('afkconfirm','1');break;
case "kicknewset":break;
case "kickjoinset":break;
case "autoreport":autoreport=nv[1];break;
case "autoskip":autoskip=nv[1];break;
case "antikick":antikick=nv[1];break;
case "autokick":autokick=nv[1];break;
case "antiafk":antiafk=nv[1];if(nv[1]===true){intervalantiafk = setInterval(()=> {g('afkconfirm','1'); }, 10000);} else {clearInterval(intervalantiafk);}break;
case "autofarm":autofarm=nv[1];break;
case "autoguess":autoguess=nv[1];break;
case "giveanswer":giveanswer=nv[1];break;
case "autorejoin":autorejoin=nv[1];break;
case "kickalljoin":kickalljoin=nv[1];break;
case "kickonjoin":kickonjoin=nv[1];break;
case "allcommand":allcommand=nv[1];break;
case "autotips":autotips=nv[1];break;
  
      
  
      
    
  }
}});
if(botsv!=="[]" && 1==2){
setTimeout(()=>{let obj=JSON.parse(localStorage.getItem("bots")); obj.forEach(links=>{var ifrm = document.createElement("iframe"); ifrm.setAttribute("src", "https://"+links.link+"/favicon.ico?__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8"); ifrm.style.width = "100px"; ifrm.style.height = "180px";ifrm.style.display = "none"; document.body.appendChild(ifrm);})},1000)}

chrome.storage.onChanged.addListener(function(changes, namespace) {
  if (changes.message) {
    let ne = changes.message.newValue;
    let nv = JSON.parse(ne)
    switch(nv[0]){
    	case "nextURL":
            let obj=JSON.parse(localStorage.getItem("bots"))
        localStorage.getItem("bots").indexOf(nv[1])==-1?obj.push({"link":nv[1],"timestamp":new Date().getTime()}):0
        
        localStorage.getItem("bots").indexOf(nv[1])==-1?document.querySelector("#icebot5").innerHTML += `<input type="submit" style="width:100%; height:40px; position: relative; font-weight: bold;" id="proxy-`+nv[1]+`" onclick="window.postMessage('proxyrmv.`+nv[1]+`','*')" value="`+nv[1]+`">`:0
        localStorage.setItem("bots",JSON.stringify(obj))        
    document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length;


    break;
    case "answerinput":
    document.querySelector('#answer').value=nv[1]
    break;
    case "word1":
        document.querySelector('#word1').value=nv[1]
    break;
    case "word2":
        document.querySelector('#word2').value=nv[1]
    break;
    case "answer":
    __0x70("answer",nv[1])
    break;
    case "kick":
    __0x70("kick",nv[1])
    break;
    case "rejoin":
    __0x52("join",nv[1],nv[2],nv[3],nv[4],nv[5])
    break;
    case "callbackbot":
    setTimeout(()=>{window.postMessage('colorbot.'+nv[1],'*')},60)
    break;
    }
  }
});

function injectScript (src) { const s = document.createElement('script'); s.src = chrome.runtime.getURL(src); s.type = "module";
 s.onload = () => s.remove(); (document.head || document.documentElement).append(s); }
function is2 (src) { const s = document.createElement('script'); s.src = chrome.runtime.getURL(src);
 (document.head || document.documentElement).append(s); } injectScript('wsProxy.js');is2('sweetalert2@10.js');
        	}
                if(window.location.href.indexOf("aHR0cHM6Ly9nYXJ0aWMuaW8")!=-1){
                	    let kicknewstat=false,kickjoinstat=false,autoreport=false,autoskip=false,antiafk=false,antikick=false,antikickDelay=1,autokick=false,autoguess,autofarm=false,waitforkick=0
function rnext(kelime) { const hd = kelime.split(''); const hu = hd.length; const yh = []; const invisibleChars = ['\u200B', '\u200C', '\u200D', '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u17b4', '\u17b5', '\u2068', '\u2069']; let charCount = 0; for (let i = 0; i < hu; i++) {yh.push(hd[i]);charCount++;if (charCount < 18 && i < hu - 1) { const invisibleChar = invisibleChars[Math.floor(Math.random() * invisibleChars.length)]; yh.push(invisibleChar); charCount++;}if (charCount >= 18) { break;} } return yh.join('');}
function LUNA(o, pN, c) {let v = o[pN];Object.defineProperty(o, pN, {  get() { return v;    },set(nV) {  if (nV !== v) {  const oV = v;  v = nV; c(nV, oV);    }},  });};
let usersinroom=[]
const data = {ev: 10};
function g(e, x) {
  data.ev = [e,x,Math.ceil(Math.random()*100000+1)]
}
     let inv= ['឴','‏','឵','­','͏','‎','𝅹','⁡'];
  const webSockets = {};
window.addEventListener('message', function(event) {
	                let abtn=event.data.split("cmd.")[1]
	let nv=JSON.parse(abtn);
    	switch(nv[0]){
    	case "join":
   let room=nv[1];
            fetch("https://"+window.location.href.split("/")[2]+"/server/?check=1&v3=1&room="+room+"&__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8#").then(x=>x.text()).then(x=>{
            let ws=new WebSocket("wss://"+window.location.href.split("/")[2]+"/__cpw.php?u="+btoa("wss://"+x.split("https://")[1].split(".")[0]+".gartic.io/socket.io/?c="+x.split("?c=")[1]+"&EIO=3&transport=websocket")+"&o=aHR0cHM6Ly9nYXJ0aWMuaW8="); 
ws.onopen=()=>{
	if (nv[4] === '0') {
  ws.send('42[3,{"v":20000,"nick":"'+rnext(nv[2])+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]')
} else if (nv[4] === '1') {
  ws.send('42[3,{"v":20000,"nick":"'+nv[2]+Math.ceil(Math.random()*10000+1)+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]')
}
else if (nv[4] === '2') {
	
let c = JSON.parse(nv[5]);
function e() {
  return c[Math.floor(Math.random() * c.length)];
};
let r = e();
ws.send('42[3,{"v":20000,"nick":"' + r.nick + '","avatar":"' + r.avatar + '","platform":0,"sala":"' + room.substring(2) + '"}]');
}

            	}
                ws.onmessage= (msg) => {
                	                if(msg.data.indexOf('42["5"')!=-1){
               let objlist=JSON.parse('["5"'+msg.data.split('42["5"')[1]);
               ws.longID=objlist[1];
               ws.id=objlist[2];      
               LUNA_("callbackbot",objlist[1]);                                    objlist[5].forEach(item=>{usersinroom.push(item)});
               let mj=JSON.parse(nv[6]);mj.forEach(m=>{switch(m.type){
case "broadcast":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;case "message":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');break;
case "answer":ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;
}})               

                        ws.send('42[46,' + ws.id + ']');
                    setInterval(()=>{ws.send('2')},3000)
                   webSockets[ws.id] = { socket: ws, timestamp: ws.id};
                   LUNA(data, 'ev', (nV, oV) => {
      if (nV) {
        Object.values(webSockets).forEach(wsObj => {
          const ws = wsObj.socket;
          const timestamp = wsObj.timestamp;

          switch (nV[0]) {
            case "broadcast":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "broadcastspam":
            inv = shuffle(inv);
let fE= inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fE +'"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fE + '"]');
              break;
            case "msg":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "msgspam":
            inv = shuffle(inv);
let fM = inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fM +'"]');
              break;
            case "answer":
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "answerspam":
            inv = shuffle(inv);
let fA= inv.slice(0,3).join('');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fA + '"]');
              break;
            case "report":
              ws.send('42[35,' + timestamp + ']');
              break;
            case "jump":
              ws.send('42[25,' + timestamp + ']');
              break;
            case "accept1":
              ws.send('42[34,' + timestamp + ']');
              break;
            case "accept2":
              ws.send('42[34,' + timestamp + ',1]');
              break;
            case "tips":
              ws.send('42[30,' + timestamp + ',1]');
              break;
            case "exit":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "rejoin":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "afkconfirm":
              ws.send('42[42,' + timestamp + ']');
              break;
            case "kick":
              ws.send('42[45,' + timestamp + ',["' + nV[1] + '",true]]');
              break;
              case "0xbE":
           
              break;
          }
        });
      }
    });
                	}
                if(msg.data.indexOf('42["34"')!=-1){
                    let objlist=JSON.parse('["34"'+msg.data.split('42["34"')[1])
                    var correct=objlist[1]

                LUNA_("answerinput",correct)
                                    if(autofarm===true){
                                     setTimeout(()=>{
                LUNA_("answer",correct)},100)
                    }
}
if(msg.data.indexOf('42["16"')!=-1 && autofarm===true){
                    ws.send('42[34,'+ws.id+']')
                                 }
                                  if(msg.data.indexOf('42["16"')!=-1 && autoskip===true){
    setTimeout(()=>{
      ws.send('42[25,'+ws.id+']');},1000)

                                  }
                if(msg.data.indexOf('42["47"]')!=-1 && autoreport===true){

      ws.send('42[35,'+ws.id+']')

                }

                if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 | msg.data.indexOf(''+ws.longID+',1')!=-1) && antikick===true){

      ws.send('42[24,'+ws.id+']');
      LUNA_("rejoin",window.location.href.split("/")[2],nv[1],nv[2],nv[3],nv[4])
}
      if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 || msg.data.indexOf(''+ws.longID+',1')!=-1) && autokick === true) {
  let msgautokick = msg.data.split(',');
  let autokickid = msgautokick[1].replace(/"/g, '');
                   LUNA_("kick",autokickid)
                }
                if(msg.data.indexOf('42["16"')!=-1){
                    let objlist=JSON.parse('["16"'+msg.data.split('42["16"')[1])
                    var word1=objlist[1]
                    var word2=objlist[3]
                LUNA_("word1",word1)
                LUNA_("word2",word2)

}

}})
      break;
case "broadcast":let b=nv[1];g('broadcast',b);break;
case "broadcastspam":let be=nv[1];g('broadcastspam',be);break;
case "msg":let m=nv[1];g('msg',m);break;
case "msgspam":let me=nv[1];g('msgspam',me);break;
case "answer":let a=nv[1];g('answer',a);break;
case "answerspam":let ae=nv[1];g('answerspam',ae);break;
case "exit":g('exit','1');break;
case "report":g('report','1');break;
case "0xbE":g('0xbE','1');break;
case "jump":g('jump','1');break;
case "tips":g('tips','1');break;
case "accept1":g('accept1','1');break;
case "accept2":g('accept2','1');break;
case "kick":let k=nv[1];g('kick',k);break;
case "rejoin":g('rejoin','1');break;
case "afkconfirm":g('afkconfirm','1');break;
case "kicknewset":break;
case "kickjoinset":break;
case "autoreport":autoreport=nv[1];break;
case "autoskip":autoskip=nv[1];break;
case "antikick":antikick=nv[1];break;
case "autokick":autokick=nv[1];break;
case "antiafk":antiafk=nv[1];if(nv[1]===true){intervalantiafk = setInterval(()=> {g('afkconfirm','1'); }, 10000);} else {clearInterval(intervalantiafk);}break;
case "autofarm":autofarm=nv[1];break;
case "autoguess":break;

    
  }
});
}

if(window.location.href.indexOf("?__cpo=")!=-1){
    LUNA_("nextURL",window.location.href.split("/")[2])

}

if(window.location.href.indexOf("?proxyset")!=-1){setTimeout(()=>{
document.querySelector("#quickLinks > a:nth-child(1)").setAttribute("data-href","https://gartic.io/favicon.ico")
setInterval(()=>{
    document.querySelector("#quickLinks > a:nth-child(1)").click()},1)},1000)}
    if(window.location.href.indexOf("?2proxyset")!=-1){setTimeout(()=>{
document.querySelector("#unique-form-control").value="https://gartic.io/favicon.ico";setTimeout(()=>{document.querySelector("#unique-btn-blue").click()},200)},1000)}
case "join":

   let room = nv[1];
   let botssv = localStorage.getItem("bots");
   let botssp = JSON.parse(botssv);
   let itvl = parseInt(document.querySelector("#quantbot").value);
   let serverNum = document.querySelector("#servernum").value.trim();
   
   // 🚀 جيب كل التوكنات والسيرفرات بنفس الوقت مع توكن فريد لكل بوت
   let allPromises = botssp.slice(0, itvl).map((v, botIndex) => {
      // إضافة timestamp + random number لكل request عشان نجيب توكن مختلف
      let uniqueParam = Date.now() + Math.random();
      
      let tokenPromise = fetch("https://www.xsw.work.gd/assign-token?_=" + uniqueParam + "&bot=" + botIndex, {
         method: "GET",
            'Cache-Control': 'no-cache'
         
      }).then(response => response.json()).then(data => data.token);
      
      let fetchUrl = "https://"+v.link+"/server/?check=1&v3=1&room="+room+"&__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8#";
      let serverPromise = fetch(fetchUrl, {"credentials":"include"}).then(x => x.text());
      
      return Promise.all([tokenPromise, serverPromise]).then(([token, serverData]) => ({
         link: v.link,
         serverData: serverData,
         token: token,
         botIndex: botIndex
      }));
   });
   
   // 🚀 بعد ما كل التوكنات والسيرفرات تجي، دخّل كل البوتات مرة وحدة
   Promise.all(allPromises).then(results => {
      console.log("✅ All tokens and servers loaded! Connecting bots...");
      
      // الحين كل البوتات تدخل طلقة وحدة
      results.forEach(server => {
         let serverDomain;
         if(serverNum && serverNum.length === 2 && /^0[1-7]$/.test(serverNum)) {
            let baseDomain = server.serverData.split("https://")[1].split(".")[0];
            let domainWithoutNum = baseDomain.replace(/\d+$/, '');
            let maxServer = parseInt(serverNum);
            let targetServer = ((server.botIndex % maxServer) + 1).toString().padStart(2, '0');
            serverDomain = domainWithoutNum + targetServer;
            console.log("Bot #" + server.botIndex + " → " + serverDomain + " (Token: " + server.token.substring(0, 10) + "...)");
         } else {
            serverDomain = server.serverData.split("https://")[1].split(".")[0];
         }
         
         const token = server.token;
         if(token){
            let ws = new WebSocket("wss://"+server.link+"/__cpw.php?u="+btoa("wss://"+serverDomain+".gartic.io/socket.io/?c="+server.serverData.split("?c=")[1]+"&EIO=3&transport=websocket")+"&o=aHR0cHM6Ly9nYXJ0aWMuaW8="); 
            
            ws.onopen = () => {
               console.log("🟢 Bot #" + server.botIndex + " connected!");
               
               if (nv[4] === '0' && nv[3] !== 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+addHiddenCharToArabicName(nv[2])+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '1' && nv[3] !== 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+nv[2]+getNextQueueNumber()+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '0' && nv[3] == 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+addHiddenCharToArabicName(nv[2])+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '1' && nv[3] == 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+nv[2]+Math.ceil(Math.random()*10000+1)+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '2' && nv[3] !== 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+em(nv[2])+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '2' && nv[3] == 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+em(nv[2])+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '3') {
                  let c = JSON.parse(nv[5]);
                  function e() {
                     return c[Math.floor(Math.random() * c.length)];
                  }
                  let r = e();
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+r.nick+'","avatar":"'+r.avatar+'","platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '4' && nv[3] !== 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+gRcs().join('')+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '4' && nv[3] == 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+gRcs().join('')+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '5' && nv[3] !== 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+shuffle(etL).slice(0,18).join('')+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               } else if (nv[4] === '5' && nv[3] == 'random') {
                  ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+shuffle(etL).slice(0,18).join('')+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
               }
            };