"use strict";

/**
 * ═══════════════════════════════════════════════════════════════
 * ⸸ ɨƈɛɮօȶ V6 ⸸ ᴜʟᴛɪᴍᴀᴛᴇ ʙʏᴘᴀꜱꜱ ꜱʏꜱᴛᴇᴍ ⸸
 * 💀 ᴛʜᴇ ᴅᴀʀᴋ ᴄᴏᴅᴇʀ: ˢᵃᶤᶠ ₉₁ 💀
 * ═══════════════════════════════════════════════════════════════
 * 
 * ᴘᴏᴡᴇʀꜱ:
 * ⸸ ᴄᴏᴍᴘʟᴇᴛᴇ ʀᴀᴛᴇ ʟɪᴍɪᴛ ʙʏᴘᴀꜱꜱ
 * ⸸ ᴡᴇʙꜱᴏᴄᴋᴇᴛ ʜᴇᴀᴅᴇʀ ꜱᴘᴏᴏꜰɪɴɢ
 * ⸸ ᴄʟᴏᴜᴅꜰʟᴀʀᴇ ᴅᴇᴛᴇᴄᴛɪᴏɴ ʙʏᴘᴀꜱꜱ
 * ⸸ ᴀɴᴛɪ-ʀᴇꜰʀᴇꜱʜ ʀᴏᴏᴍ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ
 * ⸸ ɪᴍᴍᴏʀᴛᴀʟ ᴄᴏɴɴᴇᴄᴛɪᴏɴ 
 * ⸸ ꜱᴇᴛᴛɪɴɢs
 * ⸸ ɢʜᴏꜱᴛ ᴍᴏᴅᴇ (ᴜɴᴅᴇᴛᴇᴄᴛᴀʙʟᴇ)
 * ═══════════════════════════════════════════════════════════════
 */

// ═══════════════════════════════════════════════════════════════
// 💀 SECTION 1: BROWSER FINGERPRINT SPOOFING (FIXED)
// ═══════════════════════════════════════════════════════════════

const FingerprintSpoofer = {
    // Random User-Agent Generator
    getRandomUA: () => {
        const browsers = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0',
            'Mozilla/5.0 (compatible; Konqueror/3.5; Windows NT 6.0) KHTML/3.5.6 (like Gecko)'

        ];
        return browsers[Math.floor(Math.random() * browsers.length)];
    },

    // FIXED: Spoof navigator properties safely
    spoofNavigator: () => {
        try {
            // Only define if not already defined
            const props = ['userAgent', 'platform', 'hardwareConcurrency', 'deviceMemory', 'language', 'languages'];

            props.forEach(prop => {
                try {
                    const descriptor = Object.getOwnPropertyDescriptor(Navigator.prototype, prop);
                    if (!descriptor || descriptor.configurable) {
                        Object.defineProperty(Navigator.prototype, prop, {
                            get: function () {
                                switch (prop) {
                                    case 'userAgent':
                                        return FingerprintSpoofer.getRandomUA();
                                    case 'platform':
                                        return ['Win32', 'MacIntel', 'Linux x86_64'][Math.floor(Math.random() * 3)];
                                    case 'hardwareConcurrency':
                                        return [4, 8, 12, 16][Math.floor(Math.random() * 4)];
                                    case 'deviceMemory':
                                        return [4, 8, 16, 32][Math.floor(Math.random() * 4)];
                                    case 'language':
                                        return ['en-US', 'en-GB', 'pt-BR', 'es-ES'][Math.floor(Math.random() * 4)];
                                    case 'languages':
                                        return [['en-US', 'en'], ['pt-BR', 'pt'], ['es-ES', 'es']][Math.floor(Math.random() * 3)];
                                }
                            },
                            configurable: true,
                            enumerable: true
                        });
                    }
                } catch (e) {
                    // Property already defined, skip
                }
            });
        } catch (e) {
            console.warn('[BYPASS] Navigator spoofing partially blocked (browser restriction)');
        }
    },

    // Canvas fingerprint randomization
    randomizeCanvas: () => {
        try {
            const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;

            const injectNoise = (data) => {
                const noise = Math.random() * 0.1;
                for (let i = 0; i < data.length; i += 4) {
                    data[i] = Math.min(255, data[i] + noise);
                    data[i + 1] = Math.min(255, data[i + 1] + noise);
                    data[i + 2] = Math.min(255, data[i + 2] + noise);
                }
                return data;
            };

            CanvasRenderingContext2D.prototype.getImageData = function (...args) {
                const imageData = originalGetImageData.apply(this, args);
                injectNoise(imageData.data);
                return imageData;
            };
        } catch (e) {
            console.warn('[BYPASS] Canvas randomization blocked');
        }
    },

    // WebGL fingerprint randomization
    randomizeWebGL: () => {
        try {
            const getParameter = WebGLRenderingContext.prototype.getParameter;

            WebGLRenderingContext.prototype.getParameter = function (parameter) {
                if (parameter === 37445) {
                    return ['Intel Inc.', 'NVIDIA Corporation', 'AMD'][Math.floor(Math.random() * 3)];
                }
                if (parameter === 37446) {
                    const renderers = [
                        'ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0)',
                        'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 Ti Direct3D11 vs_5_0 ps_5_0)',
                        'ANGLE (AMD, AMD Radeon RX 580 Series Direct3D11 vs_5_0 ps_5_0)'
                    ];
                    return renderers[Math.floor(Math.random() * renderers.length)];
                }
                return getParameter.call(this, parameter);
            };
        } catch (e) {
            console.warn('[BYPASS] WebGL randomization blocked');
        }
    },

    init: () => {
        FingerprintSpoofer.spoofNavigator();
        FingerprintSpoofer.randomizeCanvas();
        FingerprintSpoofer.randomizeWebGL();
        console.log('%c⸸ Fingerprint spoofing activated', 'color: #ff0000; font-weight: bold;');
    }
};

// ═══════════════════════════════════════════════════════════════
// 💀 SECTION 2: WEBSOCKET RATE LIMIT BYPASS
// ═══════════════════════════════════════════════════════════════

const WebSocketBypass = {
    originalSend: null,

    bypassThrottle: function (ws, data) {
        try {
            if (ws.readyState === WebSocket.OPEN) {
                WebSocketBypass.originalSend.call(ws, data);
            }
        } catch (e) {
            // Silent error handling
        }
    },

    hookSend: function () {
        const OriginalWebSocket = window.WebSocket;

        window.WebSocket = function (...args) {
            const ws = new OriginalWebSocket(...args);
            const _origSend = ws.send.bind(ws);
            const _queue = [];
            let _busy = false;
            function _flush() {
                if (!_queue.length) { _busy = false; return; }
                _busy = true;
                try { _origSend(_queue.shift()); } catch (e) { }
                setTimeout(_flush, 20);
            }
            ws.send = function (data) {
                _queue.push(data);
                if (!_busy) _flush();
            };

            if (!WebSocketBypass.originalSend) {
                WebSocketBypass.originalSend = ws.send;
            }

            ws.send = function (data) {
                WebSocketBypass.bypassThrottle(this, data);
            };

            const originalClose = ws.close;
            ws.close = function (...closeArgs) {
                if (ws.explicitExit === true) {
                    originalClose.apply(this, closeArgs);
                }
            };

            return ws;
        };

        window.WebSocket.CONNECTING = OriginalWebSocket.CONNECTING;
        window.WebSocket.OPEN = OriginalWebSocket.OPEN;
        window.WebSocket.CLOSING = OriginalWebSocket.CLOSING;
        window.WebSocket.CLOSED = OriginalWebSocket.CLOSED;

        console.log('%c⸸ WebSocket rate limit bypass activated', 'color: #ff0000; font-weight: bold;');
    },

    init: function () {
        WebSocketBypass.hookSend();
    }
};

// ═══════════════════════════════════════════════════════════════
// 💀 SECTION 3: CLOUDFLARE BYPASS
// ═══════════════════════════════════════════════════════════════

const CloudflareBypass = {
    generateHeaders: () => {
        return {
            'User-Agent': FingerprintSpoofer.getRandomUA(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0',
            'DNT': '1'
        };
    },

    hookFetch: () => {
        const originalFetch = window.fetch;

        window.fetch = async function (...args) {
            const [url, options = {}] = args;

            const headers = {
                ...CloudflareBypass.generateHeaders(),
                ...(options.headers || {})
            };

            const randomDelay = Math.random() * 50;
            await new Promise(resolve => setTimeout(resolve, randomDelay));

            return originalFetch(url, {
                ...options,
                headers,
                credentials: 'include'
            });
        };

        console.log('%c⸸ Cloudflare bypass activated', 'color: #ff0000; font-weight: bold;');
    },

    init: () => {
        CloudflareBypass.hookFetch();
    }
};

// ═══════════════════════════════════════════════════════════════
// 💀 SECTION 4: SERVER BYPASS
// ═══════════════════════════════════════════════════════════════

const ServerBypass = {
    antiRoomRefresh: () => {
        const originalPostMessage = window.postMessage;

        window.postMessage = function (message, ...args) {
            if (typeof message === 'string') {
                if (message.includes('reload') ||

                    message.includes('42["6"')) {
                    console.log('%c⸸ Blocked room refresh command', 'color: #ff6600; font-weight: bold;');
                    return;
                }
            }

            return originalPostMessage.call(this, message, ...args);
        };

        console.log('%c⸸ Anti-room-refresh activated', 'color: #ff0000; font-weight: bold;');
    },

    bypassValidation: () => {
        const originalAddEventListener = EventTarget.prototype.addEventListener;

        EventTarget.prototype.addEventListener = function (type, listener, ...args) {
            if (type === 'message' && this instanceof WebSocket) {
                const wrappedListener = function (event) {
                    try {
                        const data = event.data;

                        if (typeof data === 'string') {
                            if (data.includes('42["6"') ||
                                data.includes('42["45"') ||
                                data.includes('"banned"') ||
                                data.includes('"error"')) {
                                console.log('%c⸸ Blocked server validation', 'color: #ff6600; font-weight: bold;');
                                return;
                            }
                        }

                        return listener.call(this, event);
                    } catch (e) {
                        return listener.call(this, event);
                    }
                };

                return originalAddEventListener.call(this, type, wrappedListener, ...args);
            }

            return originalAddEventListener.call(this, type, listener, ...args);
        };

        console.log('%c⸸ Server validation bypass activated', 'color: #ff0000; font-weight: bold;');
    },

    init: () => {
        ServerBypass.antiRoomRefresh();
        ServerBypass.bypassValidation();
    }
};

// ═══════════════════════════════════════════════════════════════
// 💀 SECTION 5: PERSISTENT CONNECTION
// ═══════════════════════════════════════════════════════════════

const PersistentConnection = {
    connections: new Map(),

    monitorConnection: (ws) => {
        const wsId = Math.random().toString(36);
        PersistentConnection.connections.set(wsId, ws);

        const originalOnError = ws.onerror;
        ws.onerror = function (error) {
            console.log('%c⸸ Connection error intercepted', 'color: #ff6600; font-weight: bold;');
        };

        const originalOnClose = ws.onclose;
        ws.onclose = function (event) {
            if (event.code === 1000 && event.wasClean) {
                PersistentConnection.connections.delete(wsId);
                if (originalOnClose) originalOnClose.call(this, event);
            } else {
                console.log('%c⸸ Blocked forced disconnect', 'color: #ff6600; font-weight: bold;');
            }
        };

        const keepAlive = setInterval(() => {
            if (ws.readyState === WebSocket.OPEN) {
                try {
                    ws.send('2');
                } catch (e) {
                    clearInterval(keepAlive);
                }
            } else if (ws.readyState === WebSocket.CLOSED) {
                clearInterval(keepAlive);
                PersistentConnection.connections.delete(wsId);
            }
        }, 5000);
    },

    init: () => {
        const OriginalWebSocket = window.WebSocket;

        window.WebSocket = function (...args) {
            const ws = new OriginalWebSocket(...args);
            const _origSend = ws.send.bind(ws);
            const _queue = [];
            let _busy = false;
            function _flush() {
                if (!_queue.length) { _busy = false; return; }
                _busy = true;
                try { _origSend(_queue.shift()); } catch (e) { }
                setTimeout(_flush, 20);
            }
            ws.send = function (data) {
                _queue.push(data);
                if (!_busy) _flush();
            };
            PersistentConnection.monitorConnection(ws);
            return ws;
        };

        Object.setPrototypeOf(window.WebSocket, OriginalWebSocket);
        window.WebSocket.prototype = OriginalWebSocket.prototype;

        console.log('%c⸸ Persistent connection activated', 'color: #ff0000; font-weight: bold;');
    }
};

// ═══════════════════════════════════════════════════════════════
// 💀 SECTION 6: ANTI-DETECTION
// ═══════════════════════════════════════════════════════════════

const AntiDetection = {
    hideAutomation: () => {
        try {
            Object.defineProperty(Navigator.prototype, 'webdriver', {
                get: () => false,
                configurable: true
            });
        } catch (e) { }

        try {
            delete window.navigator.__proto__.webdriver;
        } catch (e) { }

        console.log('%c⸸ Anti-detection activated', 'color: #ff0000; font-weight: bold;');
    },

    init: () => {
        AntiDetection.hideAutomation();
    }
};

// ═══════════════════════════════════════════════════════════════
// 💀 MASTER INITIALIZATION
// ═══════════════════════════════════════════════════════════════

const GarticBypassSystem = {
    version: '6.6.6',
    author: 'ˢᵃᶤᶠ ₉₁ ⸸ ᴛʜᴇ ᴅᴀʀᴋ ᴄᴏᴅᴇʀ',

    init: () => {
        console.log('%c═══════════════════════════════════════════════════════════════', 'color: #ff0000; font-weight: bold; font-size: 12px;');
        console.log('%c⸸ ɨƈɛɮօȶ V6 ⸸ ᴜʟᴛɪᴍᴀᴛᴇ ʙʏᴘᴀꜱꜱ ꜱʏꜱᴛᴇᴍ ⸸', 'color: #ff0000; font-weight: bold; font-size: 16px; text-shadow: 0 0 10px #ff0000;');
        console.log(`%cVersion: ${GarticBypassSystem.version} | By: ${GarticBypassSystem.author}`, 'color: #ff6600; font-weight: bold; font-size: 12px;');
        console.log('%c═══════════════════════════════════════════════════════════════', 'color: #ff0000; font-weight: bold; font-size: 12px;');

        FingerprintSpoofer.init();
        WebSocketBypass.init();
        CloudflareBypass.init();
        ServerBypass.init();
        PersistentConnection.init();
        AntiDetection.init();

        console.log('%c═══════════════════════════════════════════════════════════════', 'color: #00ff00; font-weight: bold; font-size: 12px;');
        console.log('%c💀 ALL DARK POWERS ACTIVATED SUCCESSFULLY 💀', 'color: #00ff00; font-weight: bold; font-size: 14px; text-shadow: 0 0 10px #00ff00;');
        console.log('%c═══════════════════════════════════════════════════════════════', 'color: #00ff00; font-weight: bold; font-size: 12px;');
        console.log('%cᴘᴏᴡᴇʀꜱ ᴀᴄᴛɪᴠᴇ:', 'color: #ffff00; font-weight: bold;');
        console.log('%c  ⸸ Rate Limit Bypass', 'color: #00ff00;');
        console.log('%c  ⸸ WebSocket Manipulation', 'color: #00ff00;');
        console.log('%c  ⸸ Cloudflare Bypass', 'color: #00ff00;');
        console.log('%c  ⸸ Server Validation Bypass', 'color: #00ff00;');
        console.log('%c  ⸸ Anti-Room-Refresh', 'color: #00ff00;');
        console.log('%c  ⸸ Persistent Connection', 'color: #00ff00;');
        console.log('%c  ⸸ Ghost Mode (Undetectable)', 'color: #00ff00;');
        console.log('%c═══════════════════════════════════════════════════════════════', 'color: #00ff00; font-weight: bold; font-size: 12px;');
    }
};

// ═══════════════════════════════════════════════════════════════
// AUTO-INITIALIZE
// ═══════════════════════════════════════════════════════════════

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        GarticBypassSystem.init();
    });
} else {
    GarticBypassSystem.init();
}

window.GarticBypass = GarticBypassSystem;