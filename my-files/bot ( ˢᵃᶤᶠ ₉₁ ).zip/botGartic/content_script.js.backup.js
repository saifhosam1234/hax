function LUNA_(...v){
  let obj = [];obj = obj.concat(v, Math.random() * 10000);chrome.storage.local.set({message: JSON.stringify(obj)});
}
function __0x70(...a){
  let o= [];o = o.concat(a);window.postMessage('cmd.'+JSON.stringify(o), '*');
}
function __0x11(...a){
  let o= [];o = o.concat(a);document.querySelectorAll('iframe').forEach(function(c) {c.contentWindow.postMessage('cmd.'+JSON.stringify(o), '*');
});
}

function __0x52(...a){console.log(a[1]);
  let o= [];o = a.slice(0, 1).concat(a.slice(2));document.querySelectorAll('iframe').forEach(function(c) {if(c.src.includes(a[1])){c.contentWindow.postMessage('cmd.'+JSON.stringify(o), '*');
}});
}
function f(ICE){return document.querySelector(ICE)}
function fa(ICE){return document.querySelectorAll(ICE)}

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}


    function addStyle(css) {
      const style = document.createElement('style');
      style.textContent = css;
      document.documentElement.appendChild(style);
    };

    function addHtml(html) {
      document.documentElement.insertAdjacentHTML('beforeend', html);
    }
    function setmenu(menu) {
  const elements = [
    '#icebot1','#icebot2','#icebot3','#icebot4',
    "#icebot5","#icebot6","#icebot7",
    '#avatarlist','#cavatarlist','#custombotnick'
  ];
  elements.forEach(element => {
    if (element === `#${menu}`) {
      f(element).style.display = 'block';
    } else {
      f(element).style.display = 'none';
    }
  });
}
    let cmd="",wss=[],tojoin=0,usersinroom=[],customkickitems=[],messagejoinitems=[],tfr,tg,intervalbroadcast,intervalmsg,intervalanswer,intervalantiafk,rainbowdraw,rainbowdrawmode=false,botsidvalue=[],wordsInterval,wordsIntervalPlayer,botID,botlongID,theme,tipo,idioma,am,avatar=localStorage.getItem("avatar"),botnick=localStorage.getItem("botnick"),nick=localStorage.getItem("nick")
    let lastRejoinTime = 0;
const REJOIN_COOLDOWN = 5000; // 5 seconds cooldown
function getSelectedServer() {
  const input = document.getElementById("serverInput");
  if (!input) return null;

  const val = parseInt(input.value);
  if (isNaN(val) || val < 1 || val > 9) return null;

  return val.toString().padStart(2, '0');
}

        if(window.location.href.indexOf("gartic.io")!=-1){
let red=["#cc0010","#a3000c","#820009","#680007","#530005","#FFFFFF"],orange=["#cc5b00","#a34800","#FFA500","#682d00","#532400","#FFFFFF"],yellow=["#ccbf00","#a39800","#FFFF00","#686000","#534c00","#000000"],green=["#66cc00","#51a300","#408200","#336800","#285300","#FFFFFF"],blue=["#2100cc","#1a00a3","#140082","#100068","#0c0053","#FFFFFF"],indigo=["#3c0068","#300053","#260042","#1e0034","#180029","#FFFFFF"],violet=["#6500cc","#5000a3","#400082","#330068","#280053","#FFFFFF"],pink=["#eb8898","#a33058","#FFC0CB","#681e38","#53182c","#FFFFFF"],crimson=["#b01030","#8c0c26","#70091e","#590718","#470513","#FFFFFF"],brown=["#793000","#602600","#4c1e00","#3c1800","#301300","#FFFFFF"],gray=["#787878","#606060","#4c4c4c","#3c3c3c","#303030","#FFFFFF"],white=["#cccccc","#a3a3a3","#FFFFFF","#686868","#535353","#000000"],black=["#191919","#141414","#101010","#0c0c0c","#090909","#80FF00"],magenta=["#cc00cc","#a300a3","#820082","#680068","#530053","#FFFFFF"];function colorChanger($){let e=[];switch($){case"red":e=red;break;case"orange":e=orange;break;case"yellow":e=yellow;break;case"green":e=green;break;case"blue":e=blue;break;case"indigo":e=indigo;break;case"violet":e=violet;break;case"pink":e=pink;break;case"crimson":e=crimson;break;case"brown":e=brown;break;case"gray":e=gray;break;case"white":e=white;break;case"black":e=black;break;case"magenta":e=magenta}let c=document.querySelectorAll(".icebot button"),o=document.querySelectorAll(".icebot"),r=document.querySelector(".option"),l=document.querySelectorAll(".option button"),a=document.querySelectorAll(".userlist"),t=document.querySelectorAll('.userlist input[type="submit"]'),F=document.querySelectorAll('.icebot input[type="range"]'),n=document.querySelectorAll(".icebot h2"),s=document.querySelectorAll('.icebot input[type="submit"]');n.forEach($=>{$.style.color=e[5]}),r.style.backgroundColor=e[2],F.forEach($=>{$.style.accentColor=e[0]}),o.forEach($=>{$.style.backgroundColor=e[2]}),c.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5],$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})}),l.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5]}),s.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5],$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})}),a.forEach($=>{$.style.backgroundColor=e[2],$.style.color=e[5]}),t.forEach($=>{$.style.backgroundColor=e[0],$.style.color=e[5]});let b=document.querySelectorAll(".option button");document.querySelectorAll(".option button svg").forEach($=>{$.style.stroke=e[5]}),b.forEach($=>{$.addEventListener("mouseover",function(){this.style.background=e[4]}),$.addEventListener("mouseout",function(){this.style.background=e[0]})})}function setmenu(menu){const elements=['#icebot1','#icebot2','#icebot3','#icebot4',"#icebot5","#icebot6","#icebot7",'#avatarlist','#cavatarlist','#custombotnick'];elements.forEach(element=>{if(element===`#${menu}`){f(element).style.display='block';}else{f(element).style.display='none';}})};
function xmv() { const userAgent = navigator.userAgent.toLowerCase(); const dM = ['android', 'webos', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone']; for (let d of dM) {if (userAgent.includes(d)) { function x(){ let ice = document.querySelectorAll(".icebot");let optionBtn= document.querySelectorAll(".option button");let option= document.querySelectorAll(".option");ice.forEach(icebot=>{icebot.style.width="220px";icebot.style.left="110px"});option.forEach(option=>{option.style.left="180px";option.style.top="600px";option.style.width="320px";option.style.height="auto";});optionBtn.forEach(option=>{option.style.width="13%"});setTimeout(()=>{document.querySelector("#avatarlist").style.width="360px";document.querySelector("#avatarlist").style.left="187px";
document.querySelector("#cavatarlist").style.width="360px";document.querySelector("#cavatarlist").style.left="187px";
document.querySelector("#custombotnick").style.width="360px";document.querySelector("#custombotnick").style.left="187px"},200) };x();}}};setTimeout(()=>{xmv();},200)

 addStyle(`        @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');        .userlist *{box-sizing:border-box;}        .userlist {            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;font-style:italic;            position:fixed;left:50%;top:3px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto !important;width:200px !important;        }        .userlist input[type=text]{height:20px;border-radius:3px;font-size:9pt;background:brown;color:white;padding-left:3px;}        .userlist input[type=submit]{height:25px;border-radius:3px;background:#FFD700;}        .userlist input[type=checkbox]{margin-top:2px;}        #background{        z-index:999;width:0px;height:0px;position:fixed;left:0px;top:0px;        }        .option *{box-sizing:border-box;}        .option {            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:14%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto;width:40px;        }        .option input[type=submit],.option button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .option input[type=checkbox]{margin-top:2px;}        .option input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .option button:hover{background:#ccad00;transition:0.2s;}        .option button:hover svg {stroke: #9e6e1c;}        .option button{width:90%;}        .icebot *{box-sizing:border-box;}        #avatarlist,#custombotnick,#cavatarlist {            overflow-x:hidden;width:100%;max-height:450px;overflow-y:scroll;            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:50px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:400px;        .avatarbtn{display:flex;align-items:center;justify-content:center;}        .avatarbtn button,.avatarbtn button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:50px;font-size:11pt;margin-top:5px;}        .avatarbtn button:hover{background:#ccad00;transition:0.2s;}        }        #icebot1,#icebot2,#icebot6,#icebot7,#icebotlog,#wordlist{            overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;            display:block;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:block;height:auto;width:240px;        }        #icebot3 {            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .broadcastspamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .messagespamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .answerspamvalue{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .broadcastspam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .messagespam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        .answerspam{margin-top:3px; text-align:left; color:#FFD700; font-size:16px;}        #broadcaststop{display:none;}        #msgstop{display:none;}        #answerstop{display:none;}     .msgjointext{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;}       }        #icebot4 {            overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;            display:none;text-align:center;opacity:none;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .kicklistbox{display:flex;align-items:center;justify-content:center;}        .kicklistbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .kicklistbox input[type=submit],.kicklistbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .kicklistbox input[type=submit]:hover{background:#ccad00;transition:0.2s;}        #kicklistaddbtn{width:40%;}        #kicklistremoveallbtn{width:40%;}        .customkickremove{width:30%;}        .customkick{margin-top:3px; text-align:center; color:#FFD700; font-size:17px;}        }        #icebot5 {            display:none;text-align:center;opacity:none;overflow-x:hidden;width:100%;max-height:300px;overflow-y:scroll;font-size:10pt;color:#FFD700;            position:fixed;left:28%;top:20px;padding:5px 3px !important;margin:0px;background:#333333;font-family: 'Roboto', sans-serif;border:2px solid #303132;            transform:translate(-50%,0);border-radius:15px;z-index:999999999;display:none;height:auto !important;width:240px;;        .autoguess{width:40%;}        #autoguessenable{align-items:center;justify-content:center;}        #autoguessdisable{display:none;align-items:center;justify-content:center;}        .autoguessstyle{display:flex;align-items:center;justify-content:center;}        .mimicmode{width:40%;}        #mimicmodeenabled{align-items:center;justify-content:center;}        #mimicmodedisabled{display:none;align-items:center;justify-content:center;}        .mimicmodestyle{display:flex;align-items:center;justify-content:center;}        .rainbowdraw{width:30%;}        #rainbowdrawenabled{align-items:center;justify-content:center;}        #rainbowdrawdisabled{display:none;align-items:center;justify-content:center;}        .rainbowdrawstyle{display:flex;align-items:center;justify-content:center;}        .msgjoinremoveall{width:40%;}        }        .icebot input[type=submit],.icebotbtn button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .icebot input[type=checkbox]{margin-top:2px;}        .icebot input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .icebot input[type=range]{accent-color:#FFD700;}        .icebot input[type=range]:focus::-webkit-slider-runnable-track { background: #3071A9; }        #join{width:20%;}        .roomlink{display:flex;align-items:center;justify-content:center;}        .roomlink input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .roomlink input[type=submit],.broadcastbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .roomlink button:hover{background:#ccad00;transition:0.2s;}        .botnick input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .broadcastbox{display:flex;align-items:center;justify-content:center;}        .broadcastbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .broadcastbox input[type=submit],.broadcastbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .broadcastbox button:hover{background:#ccad00;transition:0.2s;}        .msgbox{display:flex;align-items:center;justify-content:center;}        .msgbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .msgbox input[type=submit],.msgbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .msgbox button:hover{background:#ccad00;transition:0.2s;}        .answerbox{display:flex;align-items:center;justify-content:center;}        .answerbox input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .answerbox input[type=submit],.answerbox button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .answerbox button:hover{background:#ccad00;transition:0.2s;}        .msgboxjoin{display:flex;align-items:center;justify-content:center;}        .msgboxjoin input[type=text]{margin-top:4px !important;width:75% !important;height:23px !important;}        .msgboxjoin input[type=submit],.msgboxjoin button{cursor:pointer;border:none;background:#FFD700;color:#000000;padding:5px 0px;border-radius:5px;font-size:11pt;margin-top:5px;}        .msgboxjoin button:hover{background:#ccad00;transition:0.2s;}        .botnick0{width:50%;}        .botnick1{width:50%;} .botnick2{width:50%;} .botnick3{width:50%;} .botnick4{width:50%;}   .cbotnick{width:80%;}        .chooseavatar{width:80%;}        .broadcastbtn{width:20%;},.broadcastbtn input[type=submit]:hover{background:#ccad00;transition:0.2s;}        .msgbtn{width:20%;}        .answerbtn{width:20%;}        .report{width:40%;} .0xbE{width:40%;}  .dupejoin{width:40%;}      .kickall{width:40%;}        .jump{width:40%;}        .exit{width:40%;}        .rejoin{width:40%;}        .active-afk{width:40%;}        .acceptdraw1{width:40%;}        .acceptdraw2{width:40%;}        .tips{width:40%;}        .autoreport input[type=checkbox]{margin-top:32px}        .autoskip{margin-top:32px;}        .antikick{margin-top:32px;}        .antiafk{margin-top:32px;}        .autokick{margin-top:32px;}        .about{position:absolute;left:20px;top:-3px;width:10%}        .roomconsole{margin-top:3px; text-align:left; color:#FFD700; font-size:17px;}        .roomtheme{margin-top:3px; text-align:left; color:#FFD700; font-size:17px;}.switch {  position: relative;  display: block;  width: 60px;  height: 34px;}.switch input {  opacity: 0;  width: 0;  height: 0;}.slider {  position: absolute;  cursor: pointer;  top: 0;  left: 0;  right: 0;  bottom: 0;  background-color: #ccc;  -webkit-transition: .1s;  transition: .1s;}.slider:before {  position: absolute;  content: "";  height: 26px;  width: 26px;  left: 4px;  bottom: 4px;  background-color: white;  -webkit-transition: .1s;  transition: .1s;}input:checked + .slider {  background-color: #FFD700;}input:focus + .slider {  box-shadow: 0 0 1px #FFD700;}input:checked + .slider:before {  -webkit-transform: translateX(26px);  -ms-transform: translateX(26px);  transform: translateX(26px);}/* Rounded sliders */.slider.round {  border-radius: 34px;}.slider.round:before {  border-radius: 50%;}        .colorthemesbtn1{width:40%;}        .colorthemesbtn2{width:60%;}.swal2-popup.swal2-toast{flex-direction:column;align-items:stretch;width:auto;padding:1.25em;overflow-y:hidden;background:#fff;box-shadow:0 0 .625em #d9d9d9}.swal2-popup.swal2-toast .swal2-header{flex-direction:row;padding:0}.swal2-popup.swal2-toast .swal2-title{flex-grow:1;justify-content:flex-start;margin:0 .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.3125em auto;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{position:static;width:.8em;height:.8em;line-height:.8}.swal2-popup.swal2-toast .swal2-content{justify-content:flex-start;margin:0 .625em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container{padding:.625em 0 0}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-icon{width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:700}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{font-size:.25em}}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{flex:1;flex-basis:auto!important;align-self:stretch;width:auto;height:2.2em;height:auto;margin:0 .3125em;margin-top:.3125em;padding:0}.swal2-popup.swal2-toast .swal2-styled{margin:.125em .3125em;padding:.3125em .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-styled:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(100,150,200,.5)}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.8em;left:-.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-toast-animate-success-line-tip .75s;animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-toast-animate-success-line-long .75s;animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:swal2-toast-show .5s;animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:swal2-toast-hide .1s forwards;animation:swal2-toast-hide .1s forwards}.swal2-container{display:flex;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;flex-direction:row;align-items:center;justify-content:center;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:0 0!important}.swal2-container.swal2-top{align-items:flex-start}.swal2-container.swal2-top-left,.swal2-container.swal2-top-start{align-items:flex-start;justify-content:flex-start}.swal2-container.swal2-top-end,.swal2-container.swal2-top-right{align-items:flex-start;justify-content:flex-end}.swal2-container.swal2-center{align-items:center}.swal2-container.swal2-center-left,.swal2-container.swal2-center-start{align-items:center;justify-content:flex-start}.swal2-container.swal2-center-end,.swal2-container.swal2-center-right{align-items:center;justify-content:flex-end}.swal2-container.swal2-bottom{align-items:flex-end}.swal2-container.swal2-bottom-left,.swal2-container.swal2-bottom-start{align-items:flex-end;justify-content:flex-start}.swal2-container.swal2-bottom-end,.swal2-container.swal2-bottom-right{align-items:flex-end;justify-content:flex-end}.swal2-container.swal2-bottom-end>:first-child,.swal2-container.swal2-bottom-left>:first-child,.swal2-container.swal2-bottom-right>:first-child,.swal2-container.swal2-bottom-start>:first-child,.swal2-container.swal2-bottom>:first-child{margin-top:auto}.swal2-container.swal2-grow-fullscreen>.swal2-modal{display:flex!important;flex:1;align-self:stretch;justify-content:center}.swal2-container.swal2-grow-row>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-grow-column{flex:1;flex-direction:column}.swal2-container.swal2-grow-column.swal2-bottom,.swal2-container.swal2-grow-column.swal2-center,.swal2-container.swal2-grow-column.swal2-top{align-items:center}.swal2-container.swal2-grow-column.swal2-bottom-left,.swal2-container.swal2-grow-column.swal2-bottom-start,.swal2-container.swal2-grow-column.swal2-center-left,.swal2-container.swal2-grow-column.swal2-center-start,.swal2-container.swal2-grow-column.swal2-top-left,.swal2-container.swal2-grow-column.swal2-top-start{align-items:flex-start}.swal2-container.swal2-grow-column.swal2-bottom-end,.swal2-container.swal2-grow-column.swal2-bottom-right,.swal2-container.swal2-grow-column.swal2-center-end,.swal2-container.swal2-grow-column.swal2-center-right,.swal2-container.swal2-grow-column.swal2-top-end,.swal2-container.swal2-grow-column.swal2-top-right{align-items:flex-end}.swal2-container.swal2-grow-column>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-no-transition{transition:none!important}.swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)>.swal2-modal{margin:auto}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-container .swal2-modal{margin:0!important}}.swal2-popup{display:none;position:relative;box-sizing:border-box;flex-direction:column;justify-content:center;width:32em;max-width:100%;padding:1.25em;border:none;border-radius:5px;background:#fff;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-header{display:flex;flex-direction:column;align-items:center;padding:0 1.8em}.swal2-title{position:relative;max-width:100%;margin:0 0 .4em;padding:0;color:#595959;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:100%;margin:1.25em auto 0;padding:0}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-loader{display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 transparent #2778c4 transparent}.swal2-styled{margin:.3125em;padding:.625em 1.1em;box-shadow:none;font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#2778c4;color:#fff;font-size:1em}.swal2-styled.swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#d14529;color:#fff;font-size:1em}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#757575;color:#fff;font-size:1em}.swal2-styled:focus{outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1.25em 0 0;padding:1em 0 0;border-top:1px solid #eee;color:#545454;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;height:.25em;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:1.25em auto}.swal2-close{position:absolute;z-index:2;top:0;right:0;align-items:center;justify-content:center;width:1.2em;height:1.2em;padding:0;overflow:hidden;transition:color .1s ease-out;border:none;border-radius:5px;background:0 0;color:#ccc;font-family:serif;font-size:2.5em;line-height:1.2;cursor:pointer}.swal2-close:hover{transform:none;background:0 0;color:#f27474}.swal2-close:focus{outline:0;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}.swal2-close::-moz-focus-inner{border:0}.swal2-content{z-index:1;justify-content:center;margin:0;padding:0 1.6em;color:#545454;font-size:1.125em;font-weight:400;line-height:normal;text-align:center;word-wrap:break-word}.swal2-checkbox,.swal2-file,.swal2-input,.swal2-radio,.swal2-select,.swal2-textarea{margin:1em auto}.swal2-file,.swal2-input,.swal2-textarea{box-sizing:border-box;width:100%;transition:border-color .3s,box-shadow .3s;border:1px solid #d9d9d9;border-radius:.1875em;background:inherit;box-shadow:inset 0 1px 1px rgba(0,0,0,.06);color:inherit;font-size:1.125em}.swal2-file.swal2-inputerror,.swal2-input.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-file:focus,.swal2-input:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:0 0 0 3px rgba(100,150,200,.5)}.swal2-file::-moz-placeholder,.swal2-input::-moz-placeholder,.swal2-textarea::-moz-placeholder{color:#ccc}.swal2-file:-ms-input-placeholder,.swal2-input:-ms-input-placeholder,.swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-file::placeholder,.swal2-input::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em auto;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-input[type=number]{max-width:10em}.swal2-file{background:inherit;font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:inherit;color:inherit;font-size:1.125em}.swal2-checkbox,.swal2-radio{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-checkbox label,.swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-checkbox input,.swal2-radio input{flex-shrink:0;margin:0 .4em}.swal2-input-label{display:flex;justify-content:center;margin:1em auto}.swal2-validation-message{align-items:center;justify-content:center;margin:0 -2.7em;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:1.25em auto 1.875em;border:.25em solid transparent;border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-.25em;left:-.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:0 0 1.25em;padding:0;background:inherit;font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{right:auto;left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@supports (-ms-accelerator:true){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@-webkit-keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@-webkit-keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@-webkit-keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@-webkit-keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-container{top:auto;right:auto;bottom:auto;left:auto;max-width:calc(100% - .625em * 2);background-color:transparent!important}body.swal2-no-backdrop .swal2-container>.swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}body.swal2-no-backdrop .swal2-container.swal2-top{top:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-top-left,body.swal2-no-backdrop .swal2-container.swal2-top-start{top:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-top-end,body.swal2-no-backdrop .swal2-container.swal2-top-right{top:0;right:0}body.swal2-no-backdrop .swal2-container.swal2-center{top:50%;left:50%;transform:translate(-50%,-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-left,body.swal2-no-backdrop .swal2-container.swal2-center-start{top:50%;left:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-end,body.swal2-no-backdrop .swal2-container.swal2-center-right{top:50%;right:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom{bottom:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom-left,body.swal2-no-backdrop .swal2-container.swal2-bottom-start{bottom:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-bottom-end,body.swal2-no-backdrop .swal2-container.swal2-bottom-right{right:0;bottom:0}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static!important}}body.swal2-toast-shown .swal2-container{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}`);addHtml(`
<div class="userlist" style="display:none">
    <div class="userkickmenu"></div>
    <input type="submit" style="width:90px; background:red" onclick="window.postMessage('kickall','*')" value="KICK ALL">
    <input type="checkbox" class="kickonjoin">&nbsp;Kick on join<br>
    <input type="checkbox" class="kickallwhenjoin">&nbsp;Kick when join<hr>
</div>
<div class="option">
    <button class="hidemenu" onclick="window.postMessage('hidemenu','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg></button>
    <button class="menu1" onclick="window.postMessage('menu1','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>
    <button class="menu2" onclick="window.postMessage('menu2','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 9v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9"/><path d="M9 22V12h6v10M2 10.6L12 2l10 8.6"/></svg></button>
    <button class="menu3" onclick="window.postMessage('menu3','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></button>
    <button class="menu4" onclick="window.postMessage('menu4','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="8" x2="23" y2="13"></line><line x1="23" y1="8" x2="18" y2="13"></line></svg></button>
    <button class="menu5" onclick="window.postMessage('menu5','*')"><span>🆕️</span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg></button>
    <button class="menu6" onclick="window.postMessage('menu6','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></button>
    <button class="menu7" onclick="window.postMessage('menu7','*')"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f5a623" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></button>
</div>
<div id="avatarlist" class="icebot">
    <input type="submit" class="hideavatarlist" onclick="window.postMessage('hideavatarlist','*')" value="CLOSE">
    <div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/0.svg" class="selectedavatar" onclick="window.postMessage('avatar.0','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/1.svg" class="selectedavatar" onclick="window.postMessage('avatar.1','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/2.svg" class="selectedavatar" onclick="window.postMessage('avatar.2','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/3.svg" class="selectedavatar" onclick="window.postMessage('avatar.3','*')"></button></div>
    <div class="avatarbtn"><button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/36.svg" class="selectedavatar" onclick="window.postMessage('avatar.36','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://garticphone.com/images/avatar/31.svg" class="selectedavatar" onclick="window.postMessage('avatar.null','*')"></button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/subjects/1.svg?v=1" class="selectedavatar" onclick="window.postMessage('avatar.random','*')"></button></div><br>
</div>

<div id="icebot1" style="display:none;" class="icebot">
    <h2 style="color:white;">ICEbot V6      <span id="botnumber"></span><input type="submit" class="about" onclick="window.postMessage('info','*')" value="ⓘ"></h2>
    <h2 style="color:white;">Bot amount: &nbsp;&nbsp;<span><input type="text" id="quantbot" style="width:15%" oninput="window.postMessage('quantbot','*')"  value="`+localStorage.getItem("quant")+`"><span></h2><br>
    <div class="roomlink"><input type="text" id="roomlink" placeholder="Room link"></div>
    <div class="botnick"><input type="text" oninput="window.postMessage('nick','*')" placeholder="Bot nick" value="`+localStorage.getItem("nick")+`"></div>
    <input type="submit" class="botnick0" onclick="window.postMessage('botnick0','*')" value="Bot nick 1">
    <input type="submit" class="botnick1" onclick="window.postMessage('botnick1','*')" value="Bot nick 2"><input type="submit" class="botnick2" onclick="window.postMessage('botnick2','*')" value="Bot nick 3"><input type="submit" class="botnick3" onclick="window.postMessage('botnick3','*')" value="Bot nick 4"><input type="submit" class="botnick4" onclick="window.postMessage('botnick4','*')" value="Bot nick 5"><input type="submit" class="cbotnick" onclick="window.postMessage('cnickshow','*')" value="custom bot nick"><br><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/`+localStorage.getItem("avatar")+`.svg" id="avatar" class="selectedavatar">
    <input type="submit" class="chooseavatar" onclick="window.postMessage('showavatarlist','*')" value="CHOOSE AVATAR">
</div>

<div id="icebot2" class="icebot" style="display:block;">
    <div class="broadcastbox">
        <input type="text" id="botnick" oninput="window.postMessage('nick','*')" placeholder="Bot Nickname" value="`+localStorage.getItem("nick")+`">
        <input type="number" id="serverInput" min="1" max="9" placeholder="Sv" style="width:50px; margin-left:5px;">
        <button class="msgbtn" style="width:20%; margin-left:5px;" onclick="window.postMessage('join','*')" value="JOIN">JOIN</button>
    </div>
    
    <div class="msgbox">
        <input type="text" id="message" placeholder="Message">
        <button class="msgbtn" onclick="window.postMessage('chat','*')" value="Message"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button>
        <button class="msgbtn" style="width:10%" onclick="window.postMessage('chatspam','*')" value="Message"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button>
    </div>
    
    <input type="submit" class="report" style="width:100%; margin-top:5px; background:#2196F3; color:white;" onclick="window.postMessage('refreshall','*')" value="REFRESH ALL PROXIES">
    
    <div class="bot-selection" style="display:flex; justify-content:center; width:100%; margin-top:5px;">
      <select id="botSelector" style="width:68%;">
        <option value="">Select a bot</option>
      </select>
      <button class="exit-single-btn" style="width:28%; background:#c62828; color:white; margin-left:4%;" onclick="window.postMessage('exitSingleBot','*')">EXIT BOT</button>
    </div>

    <div class="answerbox" style="margin-top:5px;">
        <input type="text" id="botChatMessage" placeholder="Bot Chat (Enter to send)...">
        <button class="answerbtn" onclick="window.postMessage('sendBotChat','*')" value="Send"><svg width="16" height="16" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m22.34 10.642-.007-.003-20.02-8.303a1.104 1.104 0 0 0-1.04.1 1.156 1.156 0 0 0-.523.966v5.31a1.125 1.125 0 0 0 .915 1.105l10.919 2.02a.187.187 0 0 1 0 .368L1.665 14.224a1.125 1.125 0 0 0-.915 1.104v5.31a1.105 1.105 0 0 0 .496.924 1.123 1.123 0 0 0 1.066.097l20.02-8.256.008-.004a1.5 1.5 0 0 0 0-2.757Z"></path></svg></button>
    </div>

    <div style="display:flex; justify-content:space-between; margin-top:5px;">
        <input type="submit" class="exit" style="background:red; width:32%;" onclick="window.postMessage('exit','*')" value="EXIT">
        <input type="submit" class="kickall" style="width:32%;" onclick="window.postMessage('kickall','*')" value="KICK ALL">
        <input type="submit" class="report" style="width:32%;" onclick="window.postMessage('report','*')" value="REPORT">
    </div>

    <div style="display:flex; align-items:center; justify-content:center; width:100%; margin-top:10px;">
        <span style="color:#FFD700; font-size:12px; margin-right:8px; font-weight:bold;">REJOIN</span>
        <label class="switch" style="position:relative; width:40px; height:20px; margin:0;">
            <input type="checkbox" id="autorejoin" checked>
            <span class="slider round"></span>
        </label>
        <input type="submit" class="dupejoin" style="width:40%; margin-left:15px;" onclick="window.postMessage('dupejoin','*')" value="DUPE JOIN">
        <input type="submit" class="0xbE" style="display:none;" onclick="window.postMessage('0xbE','*')" value="0xbE">
    </div>
    <br>
    <h2 class="roomconsole"></h2><span><h2 class="roomtheme"></h2></span>
</div>
<div id="icebot3" class="icebot">
    <div class="broadcastbox"><input type="text" id="broadcastspam" placeholder="Broadcast (spam)"><button class="broadcastbtn" id="broadcaststart" onclick="window.postMessage('broadcastspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="broadcastbtn" id="broadcaststop" onclick="window.postMessage('stopbroadcast','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div>
    <div class="msgbox"><input type="text" id="messagespam" placeholder="Message (spam)"><button class="msgbtn" id="msgstart" onclick="window.postMessage('chatspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="msgbtn" id="msgstop" onclick="window.postMessage('stopmsg','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div>
    <div class="answerbox"><input type="text" id="answerspam" placeholder="Answer (spam)"><button class="answerbtn" id="answerstart" onclick="window.postMessage('answerspamtoggle','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M12 21.6a9.6 9.6 0 1 0 0-19.2 9.6 9.6 0 0 0 0 19.2Zm-.534-12.998A1.2 1.2 0 0 0 9.6 9.6v4.8a1.2 1.2 0 0 0 1.866.998l3.6-2.4a1.2 1.2 0 0 0 0-1.996l-3.6-2.4Z" clip-rule="evenodd"></path></svg>  </button>  <button class="answerbtn" id="answerstop" onclick="window.postMessage('stopanswer','*')">  <svg width="20" height="20" fill="#ffffff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M21.6 12a9.6 9.6 0 1 1-19.2 0 9.6 9.6 0 0 1 19.2 0ZM8.4 9.6a1.2 1.2 0 1 1 2.4 0v4.8a1.2 1.2 0 1 1-2.4 0V9.6Zm6-1.2a1.2 1.2 0 0 0-1.2 1.2v4.8a1.2 1.2 0 1 0 2.4 0V9.6a1.2 1.2 0 0 0-1.2-1.2Z" clip-rule="evenodd"></path></svg>  </button></div><h2 class="broadcastspamvalue" id="broadcastms"></h2><input class="broadcastspam" type="range" oninput="postMessage('broadcastspam')" min="1000" max="10000"><h2 class="messagespamvalue" id="messagems"></h2><input class="messagespam" type="range" oninput="postMessage('messagespam')" min="1000" max="10000"><h2 class="answerspamvalue" id="answerms"></h2><input class="answerspam" type="range" oninput="postMessage('answerspam')" min="1000" max="10000">
</div>
<div id="icebot4" class="icebot">
    <h2 class="customkick">Custom kick</h2> <div class="kicklistbox">      <input type="text" id="kicklistinput" placeholder="Player name"></input>  <input type="submit" id="kicklistaddbtn" onclick="window.postMessage('customkickadd','*')" value="add"></input></div><input type="submit" id="kicklistremoveallbtn" onclick="window.postMessage('customkickremoveall','*')" value="remove all">
</div>
<div id="icebot5" class="icebot"><h2 id="proxylist">Proxy list • ACTIVE</h2><input type="submit" class="report" onclick="window.postMessage('getlocation','*')" value="get location"><input type="submit" class="report" onclick="window.postMessage('refreshall','*')" value="refresh all"> </div>
<div id="icebot6" class="icebot" style="display:none;height:300px;">
    <h2>Options</h2>
    <h2 id="swtext" style="top:40px;left:10px;position:absolute;">Auto report &nbsp;</h2><label class="switch" style="top:10px;left:150px"><input type="checkbox" id="autoreport"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:80px;left:10px;position:absolute;">Auto skip &nbsp;</h2><label class="switch" style="top:16px;left:150px"><input type="checkbox" id="autoskip"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:120px;left:10px;position:absolute;">Anti kick &nbsp;</h2><label class="switch" style="top:22px;left:150px"><input type="checkbox" id="antikick"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:160px;left:10px;position:absolute;">Anti afk &nbsp;</h2><label class="switch" style="top:28px;left:150px"><input type="checkbox" id="antiafk"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:200px;left:10px;position:absolute;">Auto kick &nbsp;</h2><label class="switch" style="top:34px;left:150px"><input type="checkbox" id="autokick"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:240px;left:10px;position:absolute;">Auto farm &nbsp;</h2><label class="switch" style="top:40px;left:150px"><input type="checkbox" id="autofarm"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:280px;left:10px;position:absolute;">Auto guess &nbsp;</h2><label class="switch" style="top:46px;left:150px"><input type="checkbox" id="autoguess" onchange="window.postMessage('autoguess','*')"><span class="slider round"></span></label><h2 class="autoguessvalue" id="autoguessms" style="top:320px;position:absolute;"></h2><input class="autoguessrange" style="top:360px;left:60px;position:absolute;" type="range" oninput="postMessage('autoguess')" min="130" max="10000">
    <h2 id="swtext" style="top:390px;left:10px;position:absolute;">Mimic mode &nbsp;</h2><label class="switch" style="top:120px;left:150px"><input type="checkbox" id="mimicmode" onchange="window.postMessage('mimicmode','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:430px;left:10px;position:absolute;">Rainbow draw &nbsp;</h2><label class="switch" style="top:126px;left:150px"><input type="checkbox" id="rainbowdraw" onchange="window.postMessage('rainbowdraw','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:470px;left:10px;position:absolute;">Give answer &nbsp;</h2><label class="switch" style="top:132px;left:150px"><input type="checkbox" id="giveanswer" onchange="window.postMessage('giveanswer','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:550px;left:10px;position:absolute;">Kick all (join) &nbsp;</h2><label class="switch" style="top:144px;left:150px"><input type="checkbox" id="kickalljoin" onchange="window.postMessage('kickalljoin','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:590px;left:10px;position:absolute;">Kick on join &nbsp;</h2><label class="switch" style="top:150px;left:150px"><input type="checkbox" id="kickonjoin" onchange="window.postMessage('kickonjoin','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:630px;left:10px;position:absolute;">All command &nbsp;</h2><label class="switch" style="top:156px;left:150px"><input type="checkbox" id="allcommand" onchange="window.postMessage('allcommand','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:670px;left:10px;position:absolute;">Auto tips &nbsp;</h2><label class="switch" style="top:162px;left:150px"><input type="checkbox" id="autotips" onchange="window.postMessage('autotips','*')"><span class="slider round"></span></label>
    <h2 id="swtext" style="top:710px;left:10px;position:absolute;">Join spam (3s)&nbsp;</h2><label class="switch" style="top:168px;left:150px"><input type="checkbox" id="joinspam" onchange="window.postMessage('joinspam','*')"><span class="slider round"></span></label>
    <h2 style="top:870px;left:50px;position:absolute;">GUI theme color</h2>
    <input type="submit" style="top:900px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.red','*')" value="RED">
    <input type="submit" style="top:900px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.orange','*')" value="ORANGE">
    <input type="submit" style="top:940px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.yellow','*')" value="YELLOW">
    <input type="submit" style="top:940px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.green','*')" value="GREEN">
    <input type="submit" style="top:980px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.blue','*')" value="BLUE">
    <input type="submit" style="top:980px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.indigo','*')" value="INDIGO">
    <input type="submit" style="top:1020px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.violet','*')" value="VIOLET">
    <input type="submit" style="top:1020px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.pink','*')" value="PINK">
    <input type="submit" style="top:1060px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.crimson','*')" value="CRIMSON">
    <input type="submit" style="top:1060px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.brown','*')" value="BROWN">
    <input type="submit" style="top:1100px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.gray','*')" value="GRAY">
    <input type="submit" style="top:1100px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.white','*')" value="WHITE">
    <input type="submit" style="top:1140px;left:20px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.black','*')" value="BLACK">
    <input type="submit" style="top:1140px;left:130px;position:absolute;" class="colorthemesbtn1" onclick="window.postMessage('color.magenta','*')" value="MAGENTA">
    <input type="submit" style="top:1180px;left:50px;position:absolute;" class="colorthemesbtn2" onclick="javascript:location.reload();localStorage.removeItem('theme')" value="RESET THEME">
    <h2 style="top:1220px;left:70px;position:absolute;">User options</h2>
    <h2 id="swtext" style="top:1250px;left:10px;position:absolute;">Auto guess &nbsp;</h2><label class="switch" style="top:675px;left:150px"><input type="checkbox" id="autoguessplayer" onchange="window.postMessage('autoguessp','*')"><span class="slider round"></span></label><h2 class="autoguessvalueplayer" id="autoguessmsplayer" style="top:1320px;position:absolute;"></h2><input class="autoguessrangeplayer" style="top:1285px;left:60px;position:absolute;" type="range" oninput="postMessage('autoguessplayer')" min="130" max="10000">
    <input type="file" id="wordlist" style="top:1330px;left:50px;position:absolute;display:none;" onchange="window.postMessage('wordlist','*')" value="add new word list">
</div>
<div id="cavatarlist" class="icebot">
    <input type="submit" class="hidecavatarlist" onclick="window.postMessage('hidecavatarlist','*')" value="CLOSE"><div class="avatarbtn"><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/0.svg" class="selectedavatar" onclick="window.postMessage('cavt.0','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/1.svg" class="selectedavatar" onclick="window.postMessage('cavt.1','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/2.svg" class="selectedavatar" onclick="window.postMessage('cavt.2','*')"></button><button><img width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/3.svg" class="selectedavatar" onclick="window.postMessage('cavt.3','*')"></button></div>
    </div>
<div id="custombotnick" style="display:none;" class="icebot">
    <img onclick="window.postMessage('customavatar','*')" id="cavatar" width="100" style="margin-top:-5px;" height="100" src="https://gartic.io/static/images/avatar/svg/`+localStorage.getItem("cavatar")+`.svg" ><div id="cstbtn" class="icebotbtn"><button onclick="window.postMessage('cnickclose','*')" style="width:15%;top:5px;left:5px;position:absolute;">CLOSE</button><button onclick="window.postMessage('cnickenable','*')" style="width:15%;top:5px;left:60px;position:absolute;">ENABLE</button><input type="text" id="customnick" maxlength="18" style="width:45%;" placeholder="Set custom nick here..."></input><button onclick="window.postMessage('customavatar','*')">AVATAR</button>&nbsp;&nbsp;&nbsp;&nbsp;<button onclick="window.postMessage('setcustomnick','*')" style="width:16%">SET</button>
</div></div>
<div class="icebot" id="icebot7" style="display:none;"><h2 class="msgjointext">Message when join</h2>
<input type="text" placeholder="Message..." id="msgjoin" style="width:100%"></input><input type="submit" onclick="window.postMessage('msgjoin.broadcast','*')" style="width:33.3%" value="Broadcast"></input><input type="submit" onclick="window.postMessage('msgjoin.message','*')" style="width:33.3%" value="Message"></input><input type="submit" onclick="window.postMessage('msgjoin.answer','*')" style="width:33.3%" value="Answer"></input>
<hr>
</div>
`);
// Add this code after the HTML is loaded (around line 200-300 in your script)

// Add this code after the HTML is loaded (around line 200-300 in your script)

// Track when room link was first set
let roomLinkSetTime = 0;
let roomLinkLocked = false;
const LOCK_DURATION = 10000; // 10 seconds in milliseconds

function autoFillRoomLink() {
    // Stop updating after 10 seconds
    if (roomLinkLocked) {
        console.log("⏸️ Room link locked - not updating");
        return;
    }
    
    const currentUrl = window.location.href;
    const roomInput = document.querySelector("#roomlink");
    
    if (!roomInput) return;
    
    // Don't update if /viewer is in URL (disconnected state)
    if (currentUrl.includes('/viewer')) {
        console.log("⚠️ Viewer URL detected - keeping original room link");
        return;
    }
    
    // Check if URL matches gartic.io pattern with room code
    const roomMatch = currentUrl.match(/gartic\.io\/([a-zA-Z0-9]+)/);
    
    if (roomMatch && roomMatch[1]) {
        let roomCode = roomMatch[1];
        
        // Skip if it's just "viewer"
        if (roomCode === 'viewer') return;
        
        // Remove /viewer if it exists at the end
        roomCode = roomCode.replace(/\/viewer$/, '');
        
        // Construct the clean room link
        const cleanRoomLink = `https://gartic.io/${roomCode}`;
        
        // Only update if it's different
        if (roomInput.value !== cleanRoomLink) {
            roomInput.value = cleanRoomLink;
            console.log("✅ Room link auto-filled:", cleanRoomLink);
            
            // Set lock timer on first successful fill
            if (roomLinkSetTime === 0) {
                roomLinkSetTime = Date.now();
                console.log("⏱️ Room link lock timer started (10 seconds)");
                
                setTimeout(() => {
                    roomLinkLocked = true;
                    console.log("🔒 Room link LOCKED - will not auto-update anymore");
                }, LOCK_DURATION);
            }
        }
    }
}

// Call the function when the page loads
window.addEventListener("load", () => {
    setTimeout(() => {
        autoFillRoomLink();
    }, 500);
});

// Also monitor for URL changes (if using single-page navigation)
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        autoFillRoomLink();
    }
}).observe(document, {subtree: true, childList: true});

let avataritem = localStorage.getItem("avatar");
if (!avataritem) {
  localStorage.setItem("avatar", 1);
  avatar=1
}
        if (avataritem=='null') {setTimeout(()=>{
f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";},1000)
                                }
        if (avataritem=='random') {setTimeout(()=>{
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";},1000)
                                }
                                
    let customkick = localStorage.getItem("customkick");
if (!customkick) {
  localStorage.setItem("customkick", "[]");
}

if (customkick) {
    let list=JSON.parse(localStorage.getItem("customkick"))

        list.forEach(user=>{
            setTimeout(()=>{
        f("#icebot4").innerHTML+=`<h2 class="customkick" id="customkick.`+user.user+`">`+user.user+`</h2>
    <input type="submit" class="customkickremove" id="customkickuser.`+user.user+`" onclick="window.postMessage('customkickremove.`+user.user+`','*')" value="remove">`

            },3000)
        })
}
     let botnickitem = localStorage.getItem("botnick");
if (!botnickitem) {
  localStorage.setItem("botnick", "0");
}
     let botsv = localStorage.getItem("bots");
if (!botsv) {
  localStorage.setItem("bots", '[{"link": "108.181.21.229"},{"link": "108.181.33.135"},{"link": "108.181.33.117"},{"link": "108.181.33.119"},{"link": "108.181.34.57"},{"link": "108.181.34.71"},{"link": "108.181.30.85"},{"link": "108.181.34.149"},{"link": "108.181.32.49"},{"link": "108.181.32.73"},{"link": "108.181.32.55"},{"link": "108.181.32.61"},{"link": "108.181.32.59"},{"link": "108.181.43.67"},{"link": "108.181.34.45"},{"link": "108.181.24.243"},{"link": "108.181.34.177"},{"link": "108.181.34.157"},{"link": "195.3.223.166"},{"link": "195.3.223.164"},{"link": "146.19.24.89"},{"link": "195.3.222.15"},{"link": "185.16.39.161"},{"link": "95.214.53.145"},{"link": "95.214.53.152"},{"link": "108.181.8.179"},{"link": "108.181.9.39"},{"link": "108.181.11.39"},{"link": "108.181.6.89"},{"link": "208.87.240.203"},{"link": "208.87.240.219"},{"link": "208.87.240.251"},{"link": "208.87.241.149"},{"link": "108.181.4.237"},{"link": "208.87.241.209"},{"link": "108.181.4.241"},{"link": "208.87.240.35"},{"link": "108.181.5.29"},{"link": "208.87.242.233"},{"link": "208.87.240.67"},{"link": "95.214.53.48"},{"link": "195.3.222.40"},{"link": "185.225.191.49"},{"link": "185.225.191.57"},{"link": "108.181.11.173"},{"link": "108.181.11.193"},{"link": "108.181.11.137"},{"link": "108.181.11.171"},{"link": "108.181.11.175"},{"link": "185.16.39.144"},{"link": "185.16.39.213"},{"link": "178.211.139.238"},{"link": "185.246.84.18"},{"link": "185.246.84.66"},{"link": "108.181.90.163"},{"link": "108.181.90.129"},{"link": "208.87.241.75"},{"link": "199.71.214.121"},{"link": "108.181.5.31"},{"link": "108.181.54.41"},{"link": "185.246.87.210"},{"link": "95.214.53.28"},{"link": "185.246.85.103"},{"link": "195.3.223.101"},{"link": "185.246.85.105"},{"link": "195.3.220.223"},{"link": "185.16.38.230"},{"link": "146.19.24.59"},{"link": "195.3.220.74"},{"link": "108.181.88.29"},{"link": "108.181.88.105"},{"link": "108.181.88.107"},{"link": "199.71.214.89"},{"link": "185.246.86.208"},{"link": "185.246.87.7"},{"link": "185.246.86.211"},{"link": "95.214.53.33"}]');
}
if(botsv){
	document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length
let botsp=JSON.parse(botsv);
	botsp.forEach(x=>{
	document.querySelector("#icebot5").innerHTML += `<input type="submit" style="width:100%; height:40px; position: relative; font-weight: bold;" id="proxy-`+x.link+`" onclick="window.postMessage('proxyrmv.`+x.link+`','*')" value="`+x.link+`">`;})
	}
	 let msgjoin = localStorage.getItem("messagejoin");
if (!msgjoin) {
  localStorage.setItem("messagejoin", "[]");
}

if (msgjoin) {
	let es=JSON.parse(msgjoin);
	es.forEach(d=>{
document.querySelector("#icebot7").innerHTML += `
<h2 class="msgjoinvalue" id="msgjoinvalue.${d.msg}">${d.type} : ${d.msg}</h2>
<input type="submit" class="msgjoinremove" id="msgjoin.${d.msg}" onclick="window.postMessage('messagejoinremove.${d.msg}','*')" value="remove">
`;})
  
}
	let cbotnickitems= localStorage.getItem("custom-nicks");
if (!cbotnickitems) {
  localStorage.setItem("custom-nicks", "[]");
}
if (cbotnickitems) {
	let xm=JSON.parse(cbotnickitems);
	xm.forEach(e=>{
	    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;" id="custom-`+e.nick+`" onclick="window.postMessage('cbtnrmv.`+e.nick+`','*')">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+e.avatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+e.nick+`</span>
</button>
`;})
}
     let nickitem = localStorage.getItem("nick");
if (!nickitem) {
  localStorage.setItem("nick", "ICEbot");
}
     let quantitem = localStorage.getItem("quant");
if (!quantitem) {
  localStorage.setItem("quant", 15);
}
     let theme = localStorage.getItem("theme");
if (theme) {setTimeout(()=>{colorChanger(theme)},300)
}
     window.addEventListener("message",function(msg){
        if(typeof(msg.data)==="string"){
        	    if(msg.data=="hidemenu"){setmenu('none')}
    if(msg.data=="menu1"){setmenu('icebot1')}
    if(msg.data=="menu2"){setmenu('icebot2')}
    if(msg.data=="menu3"){setmenu('icebot3')}
    if(msg.data=="menu4"){setmenu('icebot4')}
    if(msg.data=="menu5"){setmenu('icebot5')}
    if(msg.data=="menu6"){setmenu('icebot6')}
    if(msg.data=="menu7"){setmenu('icebot7')}

    if(msg.data.indexOf("color.")!=-1){
 let color = event.data.split("color.")[1];localStorage.setItem("theme",color)
                colorChanger(color)
            }
                        if(msg.data=="quantbot"){
            localStorage.setItem("quant",f("#quantbot").value)

    }
            if(msg.data=="nick"){
            localStorage.setItem("nick",f("#botnick").value)

    }
        if(msg.data=="botnick0"){
botnick=0
localStorage.setItem("botnick",0)
}
if(msg.data=="botnick1"){
botnick=1
localStorage.setItem("botnick",1)
    }
    
if(msg.data=="botnick2"){
botnick=2
localStorage.setItem("botnick",2)
    }
    if(msg.data=="botnick3"){
botnick=4
localStorage.setItem("botnick",4)
    }
    if(msg.data=="botnick4"){
botnick=5
localStorage.setItem("botnick",5)
    }
    if(msg.data=="showavatarlist"){
        f("#icebot1").style.display="none"
        f("#avatarlist").style.display="block"
    }
    if(msg.data=="hideavatarlist"){
        f("#icebot1").style.display="block"
        f("#avatarlist").style.display="none"
    }
                if(msg.data.indexOf("proxyrmv.")!=-1){
 let proxym = msg.data.substring(9);
let storage = JSON.parse(localStorage.getItem("bots"));
if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].link === proxym) {
      storage.splice(i, 1);
          setTimeout(()=>{document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length},70)
      break;
    }
  }
  localStorage.setItem("bots", JSON.stringify(storage));
}
      let proxyel= document.getElementById("proxy-"+proxym)
      proxyel.remove()
            }

 if(msg.data.indexOf("avatar.")!=-1){
                let a=msg.data.split("avatar.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#avatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
avatar=a
localStorage.setItem("avatar",a)
    break;
    case 'null':

f("#avatar").src = "https://garticphone.com/images/avatar/31.svg";
    avatar=null
localStorage.setItem("avatar",null)
break;
    case 'random':
f("#avatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
    avatar='random'
localStorage.setItem("avatar",'random')
        break
            }}
                if(msg.data.indexOf("cavt.")!=-1){
                let a=msg.data.split("cavt.")[1]
switch(a) {
  case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':case '10':case '11':case '12':case '13':case '14':case '15':case '16':case '17':case '18':case '19':case '20':case '21':case '22':case '23':case '24':case '25':case '26':case '27':case '28':case '29':case '30':case '31':case '32':case '33':case '34':case '35':case '36':
f("#cavatar").src = "https://gartic.io/static/images/avatar/svg/"+a+".svg";
localStorage.setItem("cavatar",a)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    break;
    case 'null':

f("#cavatar").src = "https://garticphone.com/images/avatar/31.svg";
localStorage.setItem("cavatar",null)
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
break;
    case 'random':
f("#cavatar").src = "https://gartic.io/static/images/subjects/1.svg?v=1";
localStorage.setItem("cavatar",'random')
  document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
        break
            }}
                if (msg.data === 'cnickenable') {
          	localStorage.setItem("botnick",3)
                	}
    if (msg.data === 'setcustomnick') {
    	let cavatar=parseInt(localStorage.getItem("cavatar"))
    	let cnick=document.querySelector("#customnick").value
let customnicks = JSON.parse(localStorage.getItem("custom-nicks")) || [];
if (!customnicks.some(i => i.nick === cnick)) {
    customnicks.push({
        avatar: cavatar,
        nick: cnick,
        isenabled: true
    });
    }
    localStorage.setItem('custom-nicks', JSON.stringify(customnicks));
    	document.querySelector("#cstbtn").innerHTML += `
<button style="width:100%; height:60px;position: relative;" id="custom-`+cnick+`" onclick="window.postMessage('cbtnrmv.`+cnick+`','*')">
    <img width="50" height="50" style="position: absolute; left: 0; top: 0;" src="https://gartic.io/static/images/avatar/svg/`+cavatar+`.svg">
    <span style="position: relative; top: -0px; left: 30px;">`+cnick+`</span>
</button>
`;
}
    	
        if (msg.data === 'customavatar') {
        	document.querySelector('#cavatarlist').style.display='block';document.querySelector('#custombotnick').style.display='none'
        	}
        
    if(msg.data=="hidecavatarlist"){
        	document.querySelector('#cavatarlist').style.display='none';document.querySelector('#custombotnick').style.display='block'
    }
        if(msg.data=="cnickclose"){
        	document.querySelector('#custombotnick').style.display='none';
    }
        if(msg.data=="cnickshow"){
        	document.querySelector('#custombotnick').style.display='block';
    }
                if(msg.data.indexOf("cbtnrmv.")!=-1){
                let abtn=msg.data.split("cbtnrmv.")[1]
                let storage = JSON.parse(localStorage.getItem("custom-nicks"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].nick === abtn) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("custom-nicks", JSON.stringify(storage));
 document.getElementById('custom-'+abtn).remove();
}
}
                if(msg.data=="getlocation"){var ifrm = document.createElement("iframe"); ifrm.setAttribute("src", "https://croxyproxy.rocks/?proxyset"); ifrm.style.width = "100px"; ifrm.style.height = "180px";ifrm.style.display = "none"; document.body.appendChild(ifrm);var ifrm2 = document.createElement("iframe"); ifrm2.setAttribute("src", "https://proxyium.com/?2proxyset"); ifrm2.style.width = "100px"; ifrm2.style.height = "180px";ifrm2.style.display = "none"; document.body.appendChild(ifrm2);
                setTimeout(()=>{
     window.postMessage('proxyactive','*');
                	},10000)
}
                if(msg.data=="refreshall"){
             let bx = localStorage.getItem("bots");
             let ba = JSON.parse(bx);
             
let bots = ba.filter(item => ![
        {link: "185.246.87.210"},
        {link: "95.214.53.28"},
        {link: "185.246.85.103"},
        {link: "195.3.223.101"},
        {link: "185.246.85.105"},
        {link: "195.3.220.223"},
        {link: "185.16.38.230"},
        {link: "146.19.24.59"},
        {link: "195.3.220.74"}
    ].find(obj => obj.link === item.link)
);

let bots2 = ba.filter(item => [
    {link: "185.246.87.210"},
    {link: "95.214.53.28"},
    {link: "185.246.85.103"},
    {link: "195.3.223.101"},
    {link: "185.246.85.105"},
    {link: "195.3.220.223"},
    {link: "185.16.38.230"},
    {link: "146.19.24.59"},
    {link: "195.3.220.74"}
].find(obj => obj.link === item.link));

chrome.storage.local.get("locationValue2",function(e){let lc=e.locationValue2
bots2.forEach(b=>{fetch("https://"+b.link+"/"+lc, {
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
})})})
chrome.storage.local.get("locationValue",function(e){let lc=e.locationValue
bots.forEach(b=>{fetch("https://"+b.link+"/"+lc, {
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
})})});
}
        if(msg.data=="autoguess"){
        let autoguessMS=f(".autoguessrange").value
        f("#autoguessms").innerText='AUTO GUESS VALUE: ' + autoguessMS
        localStorage.setItem("autoguess",autoguessMS)
        }
                if(msg.data=="mimicmode"){if(document.querySelector("#mimicmode").checked){localStorage.setItem("mimic",'true')} else {localStorage.setItem("mimic",'false') }}
                if(msg.data.indexOf("kickuser.")!=-1){
 let id = event.data.split("kickuser.")[1];
 __0x70("kick",id)
            }
if(msg.data=="broadcast"){
__0x70("broadcast",document.querySelector("#broadcast").value)
        }
if(msg.data=="broadcastspam"){
__0x70("broadcastspam",document.querySelector("#broadcast").value)
        }
        if(msg.data=="chat"){
__0x70("msg",document.querySelector("#message").value)
        }
 if(msg.data.indexOf("chatx.")!=-1){
                let a=msg.data.split("chatx.")[1]
__0x70("msg",a)
        }
        if(msg.data=="chatspam"){
__0x70("msgspam",document.querySelector("#message").value)
        }
        if(msg.data=="answer"){
__0x70("answer",document.querySelector("#answer").value)
        }
 if(msg.data.indexOf("answerx.")!=-1){
                let a=msg.data.split("answerx.")[1]
__0x70("answer",a)
        }
        if(msg.data=="answerspam"){
__0x70("answerspam",document.querySelector("#answer").value)
        }
                    if(msg.data=="broadcastspamtoggle"){
            let broadcastspamMS=parseInt(localStorage.getItem("broadcastspam"))
            var broadcastspam = document.querySelector("#broadcastspam").value
            intervalbroadcast=setInterval(()=>{
                __0x70("broadcastspam",broadcastspam)
            },broadcastspamMS)
        document.querySelector("#broadcaststart").style.display="none"
        document.querySelector("#broadcaststop").style.display="block"
        }
        if(msg.data=="chatspamtoggle"){
            let messagespamMS=parseInt(localStorage.getItem("messagespam"))
            var messagespam = document.querySelector("#messagespam").value
            intervalmsg=setInterval(()=>{
            var chatspam = document.querySelector("#messagespam").value
                __0x70("msgspam",chatspam)
            },messagespamMS)
        document.querySelector("#msgstart").style.display="none"
        document.querySelector("#msgstop").style.display="block"
        }
        if(msg.data=="answerspamtoggle"){
            let answerspamMS=parseInt(localStorage.getItem("answerspam"))
            var answerspam = document.querySelector("#answerspam").value
            intervalanswer=setInterval(()=>{
            var answerspam = document.querySelector("#answerspam").value
                __0x70("answerspam",answerspam)
            },answerspamMS)
        document.querySelector("#answerstart").style.display="none"
        document.querySelector("#answerstop").style.display="block"
        }
        if(msg.data=="stopbroadcast"){
        clearInterval(intervalbroadcast)
        document.querySelector("#broadcaststart").style.display="block"
        document.querySelector("#broadcaststop").style.display="none"
        }
        if(msg.data=="stopmsg"){
        clearInterval(intervalmsg)
        document.querySelector("#msgstart").style.display="block"
        document.querySelector("#msgstop").style.display="none"
        }
        if(msg.data=="stopanswer"){
        clearInterval(intervalanswer)
        document.querySelector("#answerstart").style.display="block"
        document.querySelector("#answerstop").style.display="none"
        }
             if(msg.data=="broadcastspam"){
        let broadcastspamMS=document.querySelector(".broadcastspam").value
        f("#broadcastms").innerText='BROADCAST SPAM VALUE: ' + broadcastspamMS
        localStorage.setItem("broadcastspam",broadcastspamMS)
    }
    if(msg.data=="messagespam"){
        let messagespamMS=document.querySelector(".messagespam").value
        f("#messagems").innerText='MESSAGE SPAM VALUE: ' + messagespamMS
        localStorage.setItem("messagespam",messagespamMS)
    }
    if(msg.data=="answerspam"){
        let answerspamMS=document.querySelector(".answerspam").value
        f("#answerms").innerText='ANSWER SPAM VALUE: ' + answerspamMS
        localStorage.setItem("answerspam",answerspamMS)
    }
      if(msg.data=="customkickadd"){
 const value = f("#kicklistinput").value;
var customkicklist = localStorage.getItem("customkick");

  let customkickitem = JSON.parse(localStorage.getItem("customkick"));
  if (customkickitem.findIndex(item => item.user === value) === -1) {
    customkickitem.push({ "user": value });
    localStorage.setItem("customkick", JSON.stringify(customkickitem));
    f("#icebot4").innerHTML += `<h2 class="customkick" id="customkick.` + value + `">` + value + `</h2>
    <input type="submit" class="customkickremove" id="customkickuser.` + value + `" onclick="window.postMessage('customkickremove.` + value + `','*')" value="remove"></input>`
  }

        }
                    if(msg.data.indexOf("customkickremove.")!=-1){
 let usernick = event.data.split("customkickremove.")[1];
let storage = JSON.parse(localStorage.getItem("customkick"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].user === usernick) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("customkick", JSON.stringify(storage));
      let kickusertext= document.getElementById("customkick."+usernick)
      let kickuserremovebtn= document.getElementById("customkickuser."+usernick)
      kickusertext.remove()
      kickuserremovebtn.remove()
}}
        if(msg.data=="customkickremoveall"){
var elementsCustomKick = document.querySelectorAll('[id*="customkick."]');
var elementsCustomKickUser = document.querySelectorAll('[id*="customkickuser."]');
function deleteElement(element) {
  element.parentNode.removeChild(element);
}
elementsCustomKick.forEach(function(element) {
  deleteElement(element);
});
elementsCustomKickUser.forEach(function(element) {
  deleteElement(element);

})
      localStorage.setItem("customkick","[]")
      
        }
    if(msg.data.indexOf("msgjoin.")!=-1){ 	
                let xmd=msg.data.split("msgjoin.")[1]
 const value = document.querySelector("#msgjoin").value;
var messagelist = localStorage.getItem("messagejoin");

  let custommsgitem = JSON.parse(localStorage.getItem("messagejoin"));

    custommsgitem.push({ "msg": value ,"type":xmd});
    localStorage.setItem("messagejoin", JSON.stringify(custommsgitem));
document.querySelector("#icebot7").innerHTML += `
<h2 class="msgjoinvalue" id="msgjoinvalue.${value}">${xmd} : ${value}</h2>
<input type="submit" class="msgjoinremove" id="msgjoin.${value}" onclick="window.postMessage('messagejoinremove.${value}','*')" value="remove">
`;
  

    }
      if(msg.data.indexOf("messagejoinremove.")!=-1){
 let message = msg.data.split("messagejoinremove.")[1];
let storage = JSON.parse(localStorage.getItem("messagejoin"));

if (storage && Array.isArray(storage)) {
  for (let i = 0; i < storage.length; i++) {
    if (storage[i].msg === message) {
      storage.splice(i, 1);
      break;
    }
  }

  localStorage.setItem("messagejoin", JSON.stringify(storage));
}
      let msgjointext= document.getElementById("msgjoinvalue."+message)
      let msgjoinremovebtn= document.getElementById("msgjoin."+message)
      msgjointext.remove()
      msgjoinremovebtn.remove()

       }
   if(msg.data=="dupejoin"){window.postMessage('join','*');fetch("https://gartic.io/favicon.ico?rjoin=1")}
    if(msg.data=="join"){__0x70("join",document.querySelector("#roomlink").value.split("/")[3],document.querySelector("#botnick").value,avatar,localStorage.getItem("botnick"),localStorage.getItem("custom-nicks"),localStorage.getItem("messagejoin"))

}
    if(msg.data=="exit"){__0x70("exit")}
    if(msg.data=="report"){__0x70("report");}
    if(msg.data=="jump"){__0x70("jump")}
    if(msg.data=="0xbE"){__0x70("0xbE")}
    if(msg.data=="afkconfirm"){__0x70("afkconfirm")}
    if(msg.data=="acceptdraw1"){__0x70("accept1")}
    if(msg.data=="acceptdraw2"){__0x70("accept2")}
    if(msg.data=="tips"){__0x70("tips")}
}})
        document.querySelector(".kickallwhenjoin").addEventListener("click",()=>{__0x70("kicknewset",f(".kickallwhenjoin").checked)})
        document.querySelector(".kickonjoin").addEventListener("click",()=>{__0x70("kickjoinset",f(".kickonjoin").checked)
        })
                document.querySelector("#autoreport").addEventListener("click",()=>{__0x70("autoreport",f("#autoreport").checked);
        })
                document.querySelector("#autoskip").addEventListener("click",()=>{__0x70("autoskip",f("#autoskip").checked)
        })
                document.querySelector("#antikick").addEventListener("click",()=>{__0x70("antikick",f("#antikick").checked)
        })
                document.querySelector("#autokick").addEventListener("click",()=>{__0x70("autokick",f("#autokick").checked)
        })
                document.querySelector("#antiafk").addEventListener("click",()=>{__0x70("antiafk",f("#antiafk").checked)
        })
                document.querySelector("#autofarm").addEventListener("click",()=>{__0x70("autofarm",f("#autofarm").checked)
        })
                document.querySelector("#autoguess").addEventListener("click",()=>{__0x70("autoguess",f("#autoguess").checked)
        })
        
                document.querySelector("#giveanswer").addEventListener("click",()=>{__0x70("giveanswer",f("#giveanswer").checked)
        })
        
                document.querySelector("#autorejoin").addEventListener("click",()=>{__0x70("autorejoin",f("#autorejoin").checked)
        })
        
                document.querySelector("#kickalljoin").addEventListener("click",()=>{__0x70("kickalljoin",f("#kickalljoin").checked)
        })
                        document.querySelector("#kickonjoin").addEventListener("click",()=>{__0x70("kickonjoin",f("#kickonjoin").checked)
        })               
 document.querySelector("#allcommand").addEventListener("click",()=>{__0x70("allcommand",f("#allcommand").checked)
        })
 document.querySelector("#autotips").addEventListener("click",()=>{__0x70("autotips",f("#autotips").checked)
        })
                    	    let kicknewstat=false,kickjoinstat=false,autoreport=false,autoskip=false,antiafk=false,antikick=false,antikickDelay=1,autokick=false,autoguess,autofarm=true,giveanswer=false,autorejoin=true,kickalljoin=false,kickonjoin=false,allcommand=false,autotips=false,waitforkick=0,kickDelay=500
function addHiddenCharToArabicName(name) {
    const ZWSPs = ['\u2060', '\u2061', '\u2062', '\u2063'];
    const chars = name.split("");
    const randomIndex = Math.floor(Math.random() * (chars.length + 1));
    const hiddenChar = ZWSPs[Math.floor(Math.random() * ZWSPs.length)];
    const repeatCount = Math.floor(Math.random() * 3) + 1;
    const hiddenChars = hiddenChar.repeat(repeatCount);
    chars.splice(randomIndex, 0, hiddenChars);
    return chars.join("");
}

function LUNA(o, pN, c) {let v = o[pN];Object.defineProperty(o, pN, {  get() { return v;    },set(nV) {  if (nV !== v) {  const oV = v;  v = nV; c(nV, oV);    }},  });};
let usersinroom=[]
         let lE=JSON.parse(localStorage.getItem("languages"));
let sE=JSON.parse(localStorage.getItem("subjects"));let arfSL=[];function gSL(s, l) {const sO=sE.find(item => item.id === s);const lO= lE.find(item => item.id === l);if(sO && lO) {arfSL=[sO.name,lO.name];}}
const data = {ev: 10};
function g(e, x) {
  data.ev = [e,x,Math.ceil(Math.random()*100000+1)]
}
     let inv= ['឴','‏','឵','­','͏','‎','𝅹','⁡'];
     function em(p){
  let iC = ['\uFE00', '\uFE01', '\uFE02', '\uFE03', '\uFE04', '\uFE05', '\uFE06', '\uFE07', '\uFE08', '\uFE09', '\uFE0A', '\uFE0B', '\uFE0C', '\uFE0D', '\uFE0E', '\uFE0F','\u206F','\u206E','\u200B', '\u200C', '\u200D', '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u17b4', '\u17b5', '\u2068', '\u2069'];
  let niC = 18 - p.length;  
  for(let i = 0; i < niC; i++){
    let rP = Math.floor(Math.random() * p.length);
    let rC = iC[Math.floor(Math.random() * iC.length)];   
    p = p.slice(0, rP) + rC + p.slice(rP);
  }  
  return p;
};
if (localStorage.getItem("botQueueNum") === null) {
    localStorage.setItem("botQueueNum", "0");
}
function getNextQueueNumber() {
    let current = parseInt(localStorage.getItem("botQueueNum")) || 0;
    current++;
    localStorage.setItem("botQueueNum", current.toString());
    return current;
}
function gRc() { const eR = [128512, 128591, 128640, 128767, 129280, 129535];  let c; do {
    c = Math.floor(Math.random() * 2801);
  } while (eR.some(range => c >= range && c <= range + 127));  return c;}
function gRcs() {const cs = [];for (let i = 0; i < 17; i++) {  cs.push(String.fromCharCode(gRc())); } return cs;}
   let etL = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
function shuffle(a) {for (let i = a.length - 1; i > 0; i--) {let j = Math.floor(Math.random() * (i + 1));[a[i], a[j]] = [a[j], a[i]];}  return a;}
const intervalIds= {};
  const webSockets = {};
let connectedBots = {};
// --- START OF FIX ---
// --- Updated Logic for Bot List Management ---

// Logic for the Exit Button next to the dropdown
window.addEventListener('message', function(event) {
    if (event.data === 'exitSingleBot') {
        let botId = document.getElementById('botSelector').value;
        if (botId && connectedBots[botId]) {
            // Send exit command
            connectedBots[botId].socket.send('42[24,' + connectedBots[botId].id + ']');
            // Remove from list immediately
            delete connectedBots[botId];
            if(connectedBots[botId] && connectedBots[botId].longId) delete connectedBots[connectedBots[botId].longId];
            updateBotSelector();
        }
    }
});

// Logic to send Chat/Answer from the selected bot
window.addEventListener('message', function(event) {
    if (event.data === 'sendBotChat') {
        let botId = document.getElementById('botSelector').value;
        let msg = document.getElementById('botChatMessage').value;
        if (botId && connectedBots[botId]) {
            connectedBots[botId].socket.send('42[11,' + connectedBots[botId].id + ',"' + msg + '"]');
        }
    }
    if (event.data === 'sendBotAnswer') {
        let botId = document.getElementById('botSelector').value;
        let ans = document.getElementById('botAnswerMessage').value;
        if (botId && connectedBots[botId]) {
            connectedBots[botId].socket.send('42[13,' + connectedBots[botId].id + ',"' + ans + '"]');
        }
    }
});

// Updated Selector Function - Removes Duplicates!
function updateBotSelector() {
  const selector = document.querySelector('#botSelector');
  if (!selector) return;
  selector.innerHTML = '<option value="">Select a bot</option>';
  
  // Create a Set to store unique bot IDs we've already added
  const addedBots = new Set();
  
  Object.values(connectedBots).forEach(bot => {
    if (addedBots.has(bot.id)) return; // Skip if already added
    
    const option = document.createElement('option');
    option.value = bot.id;
    option.textContent = bot.nickname + " (" + bot.id + ")";
    selector.appendChild(option);
    
    addedBots.add(bot.id);
  });
}

// Logic to Detect Bots Leaving and Removing them
window.addEventListener('message', function(event) {
    if (event.data && typeof event.data === 'object' && event.data.type === 'GARTIC_WS_MESSAGE') {
        const wsMessage = event.data.data;
        
        // Check for ANY user left (message "24")
        if (wsMessage.includes('42["24"')) {
            try {
                const parsed = JSON.parse(wsMessage.substring(2));
                if (parsed[0] === "24" && parsed[1]) {
                    const userId = parsed[1];
                    
                    // Check if the user who left is one of our bots
                    const ourBot = Object.values(connectedBots || {}).find(bot => 
                        bot.id === userId || bot.longId === userId
                    );
                    
                    if (ourBot) {
                        console.log('🔴 Bot Left - Removing from list:', ourBot.nickname);
                        delete connectedBots[ourBot.id];
                        if (ourBot.longId) delete connectedBots[ourBot.longId];
                        updateBotSelector();
                    }
                }
            } catch (e) {
                console.error('Error parsing exit message:', e);
            }
        }
    }
});

// Listen for WebSocket events from the interceptor
// Listen for intercepted WebSocket messages


// --- NEW AUTO REJOIN LOGIC ---
window.addEventListener('message', function(event) {
    // 1. Handle Tampermonkey Messages (Auto Rejoin Logic)
    if (event.data && typeof event.data === 'object' && event.data.type === 'GARTIC_WS_MESSAGE') {
        const wsMessage = event.data.data;
        
        // Check for ANY user left (message "24")
        if (wsMessage.includes('42["24"')) {
            try {
                const parsed = JSON.parse(wsMessage.substring(2));
                if (parsed[0] === "24" && parsed[1]) {
                    const userId = parsed[1];
                    console.log('🔴 User left - ID:', userId);
                    
                    // --- AUTO REJOIN TRIGGER (Triggers for ANYONE leaving) ---
                    const autorejoinCheckbox = document.querySelector('#autorejoin');
                    // Only rejoin if the switch is ON
                    if (autorejoinCheckbox && autorejoinCheckbox.checked) {
                        const now = Date.now();
                        // 5 second cooldown to prevent crashing
                        if ((now - lastRejoinTime) > 5000) {
                            lastRejoinTime = now;
                            console.log('♻️ Slot opened! AUTO-REJOIN triggering...');
                            window.postMessage('dupejoin', '*');
                        } else {
                            console.log('⏳ Rejoin on cooldown (wait 5s)');
                        }
                    }

                    // --- DROPDOWN CLEANUP ---
                    // If the user who left was actually one of our bots, remove them from the list
                    const ourBot = Object.values(connectedBots || {}).find(bot => 
                        bot.id === userId || bot.longId === userId
                    );
                    
                    if (ourBot) {
                        delete connectedBots[ourBot.id];
                        if (ourBot.longId) delete connectedBots[ourBot.longId];
                        updateBotSelector();
                    }
                }
            } catch (e) {
                console.error('❌ Error parsing message:', e);
            }
        }
    }
});
// --- END NEW LOGIC ---
window.addEventListener("load", () => {
  const msgInput = document.getElementById("message");
  if (!msgInput) return;

  msgInput.addEventListener("keydown", (e) => {
    // only act on the first Enter press, not while composing text
    if (e.key !== "Enter" || e.isComposing || e.repeat) return;

    e.preventDefault(); // stop any default submit behavior immediately

    const textToSend = msgInput.value.trim();
    if (!textToSend) return;

    // clear first so the NEXT character can’t attach to the old text
    msgInput.value = "";
    msgInput.focus(); // keep the bar active

    // now send to all sockets
    const socketsList = Object.values(webSockets);
    socketsList.forEach(({ socket: ws, timestamp }) => {
      ws.send(`42[11,${timestamp},"${textToSend}"]`);
    });
  });
});

window.addEventListener('message', function(event) {
    // Safety check: make sure event.data is actually a string
    if(typeof event.data !== 'string') return;
    
    if(event.data.startsWith("cmd.")){
	          let abtn=event.data.split("cmd.")[1];
	let nv=JSON.parse(abtn);console.log(nv);console.log(abtn);
    	switch(nv[0]){
    	case "join":
   let room=nv[1];
            let botssv = localStorage.getItem("bots");let botssp=JSON.parse(botssv);let itvl=parseInt(document.querySelector("#quantbot").value);
	botssp.slice(0, itvl).forEach(v=>{
 
            fetch("https://"+v.link+"/server/?check=1&v3=1&room="+room+"&__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8#",{"credentials":"include"}).then(x=>x.text()).then(x=>{
              let userServer = getSelectedServer(); 
              let extractedServer = x.split("https://")[1].split(".")[0]; 
              let finalServer = userServer ? `server${userServer}` : extractedServer;

              let ws = new WebSocket("wss://"+v.link +"/__cpw.php?u="+ btoa(`wss://${finalServer}.gartic.io/socket.io/?c=${x.split("?c=")[1]}&EIO=3&transport=websocket`) + "&o=aHR0cHM6Ly9nYXJ0aWMuaW8=");

            //let ws=new WebSocket("wss://"+v.link+"/__cpw.php?u="+btoa("wss://server03.gartic.io/socket.io/?c="+x.split("?c=")[1]+"&EIO=3&transport=websocket")+"&o=aHR0cHM6Ly9nYXJ0aWMuaW8="); 

         fetch("https://moonfive.alwaysdata.net/ods",{
          method: "GET",
        })
        .then(response => response.json())
        .then(data => {
          const token = data.token;
          console.log("Token:", token);
          console.log("Token length:", token.length);
          if(token){
ws.onopen = () => {
  let finalNick = "";

  if (nv[4] === '0' && nv[3] !== 'random') {
    finalNick = addHiddenCharToArabicName(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '1' && nv[3] !== 'random') {
    finalNick = nv[2] + getNextQueueNumber();
    ws.send(`42[3,{"v":20000,"token":"${token}","nick":"${finalNick}","avatar":"${nv[3]}","platform":0,"sala":"${room.substring(2)}"}]`);
  
  } else if (nv[4] === '0' && nv[3] == 'random') {
    finalNick = addHiddenCharToArabicName(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '1' && nv[3] == 'random') {
    finalNick = nv[2] + Math.ceil(Math.random()*10000+1);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '2' && nv[3] !== 'random') {
    finalNick = em(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '2' && nv[3] == 'random') {
    finalNick = em(nv[2]);
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '3') {
    let c = JSON.parse(nv[5]);
    let r = c[Math.floor(Math.random() * c.length)];
    finalNick = r.nick;
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"' + finalNick + '","avatar":"' + r.avatar + '","platform":0,"sala":"' + room.substring(2) + '"}]');
  
  } else if (nv[4] === '4' && nv[3] !== 'random') {
    finalNick = gRcs().join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '4' && nv[3] == 'random') {
    finalNick = gRcs().join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '5' && nv[3] !== 'random') {
    finalNick = shuffle(etL).slice(0,18).join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  
  } else if (nv[4] === '5' && nv[3] == 'random') {
    finalNick = shuffle(etL).slice(0,18).join('');
    ws.send('42[3,{"v":20000,"token":"'+token+'","nick":"'+finalNick+'","avatar":'+Math.round(Math.random()*36)+',"platform":0,"sala":"'+room.substring(2)+'"}]');
  }


  ws._finalNick = finalNick;
};
          
        }
        })

            
                ws.onmessage= (msg) => {
                let ve=msg.data.substring(2);
          if(Array.isArray(ve)){let vv=JSON.parse(vv)};
		  
		  if (msg.data === '3') {
        ws.lastHeartbeatReceived = Date.now();
        ws.lastActivity = Date.now();
    }
		   // ⬇️ ADD THIS NEW CODE HERE ⬇️
    // Track heartbeat responses
    if (msg.data === '3') {
        ws.lastHeartbeatReceived = Date.now();
    }
               
                	               if(msg.data.indexOf('42["5"')!=-1){

               let objlist=JSON.parse('["5"'+msg.data.split('42["5"')[1]);
               ws.longID=objlist[1];
               ws.id=objlist[2];  
               
               // Register bot with BOTH IDs for tracking
               connectedBots[ws.id] = {
                 socket: ws,
                 nickname: ws._finalNick,
                 id: ws.id,
                 longId: ws.longID,
                 timestamp: Date.now()
               };
               // Also register by long ID for easier lookup
               connectedBots[ws.longID] = connectedBots[ws.id];
               
               updateBotSelector();
               
               console.log('🎮 Bot registered:', {
                 nickname: ws._finalNick,
                 shortId: ws.id,
                 longId: ws.longID
               });
               //   
                  let tipo=objlist[4].tipo
                  let idioma=objlist[4].idioma
                    gSL(tipo,idioma)
               LUNA_("callbackbot",objlist[1]);                                    objlist[5].forEach(item=>{usersinroom.push(item)});
               let mj=JSON.parse(nv[6]);mj.forEach(m=>{switch(m.type){
case "broadcast":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;case "message":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');break;
case "answer":ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;
}})               
if(kickalljoin===true){
	objlist[5].forEach((u,i)=>{
		setTimeout(()=>{
ws.send('42[45,' + ws.id + ',["' + u.id + '",true]]');
},500*i)
		})
	}

                        ws.send('42[46,' + ws.id + ']');

                    let ikc=setInterval(()=>{
        if(ws.readyState === WebSocket.OPEN){
            ws.send('2'); // Heartbeat
            ws.lastActivity = Date.now();
        } else {
            clearInterval(ikc);
        }
    }, 2000); // ← Changed from 3000 to 2000
	
	// ⬇️ ADD THIS ENTIRE BLOCK ⬇️

// Initialize tracking
ws.lastHeartbeatReceived = Date.now();
ws.lastActivity = Date.now();





// ⬆️ END OF NEW CODE ⬆️
					
					

                   webSockets[ws.id] = { socket: ws, timestamp: ws.id};
                   LUNA(data, 'ev', (nV, oV) => {
      if (nV) {
        Object.values(webSockets).forEach(wsObj => {
          const ws = wsObj.socket;
          const timestamp = wsObj.timestamp;

          switch (nV[0]) {
            case "broadcast":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "broadcastspam":
            inv = shuffle(inv);
let fE= inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fE +'"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fE + '"]');
              break;
            case "msg":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "msgspam":
            inv = shuffle(inv);
let fM = inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fM +'"]');
              break;
            case "answer":
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "answerspam":
            inv = shuffle(inv);
let fA= inv.slice(0,3).join('');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fA + '"]');
              break;
            case "report":
              ws.send('42[35,' + timestamp + ']');
              break;
            case "jump":
              ws.send('42[25,' + timestamp + ']');
              break;
            case "accept1":
              ws.send('42[34,' + timestamp + ']');
              break;
            case "accept2":
              ws.send('42[34,' + timestamp + ',1]');
              break;
            case "tips":
              ws.send('42[30,' + timestamp + ',1]');
              break;
            case "exit":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "rejoin":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "afkconfirm":
              ws.send('42[42,' + timestamp + ']');
              break;
            case "kick":
            // 1. Send the Vote (TRUE)
            ws.send('42[45,' + timestamp + ',["' + nV[1] + '",true]]');
            
            // 2. Wait 200ms, then Cancel Vote (FALSE)
            // This small delay makes the vote 'stick' before resetting the cooldown
            setTimeout(() => {
                if (ws.readyState === 1) { // Check if bot is still connected
                    ws.send('42[45,' + timestamp + ',["' + nV[1] + '",false]]');
                }
            }, 200); 
            break;
              case "0xbE":
       
              break;
          }
        });
      }
    });
                	}
 if(msg.data.indexOf('42["26"')!=-1 && autoguess===true){
                    let objlist=JSON.parse('["26"'+msg.data.split('42["26"')[1]);
                  let c= objlist[1];
                  LUNA_("answer",c)
}
                if(msg.data.indexOf('42["47"]')!=-1 && autoguess===true){

            let inter=parseInt(localStorage.getItem("autoguess"))
function wordsArray(arr) {
  let index = 0;
  if (wordsInterval) {
    clearInterval(wordsInterval);
  }
  wordsInterval = setInterval(() => {
      if (index < arr.length) {
        ws.send('42[13,'+ws.id+',"'+arr[index]+'"]')
        index++;
      } else {
        clearInterval(wordsInterval);


    }
  }, inter);
}



                }

               // Inside the ws.onmessage handler:

                 	                                if(msg.data.indexOf('42["11"')!=-1 | msg.data.indexOf('42["13"')!=-1){
let objlist = JSON.parse('['+msg.data.split('42[')[1])
                    var id=objlist[1];
                    var m=objlist[2];
                    if(m.startsWith("$msg") && allcommand===true){
                 	ws.send('42[11,'+ws.id+',"'+m.substring(5)+'"]')
                    	}                    
                    if(m.startsWith("$answer") && allcommand===true){
                    	ws.send('42[13,'+ws.id+',"'+m.substring(8)+'"]')
                    	}

const botSpamIntervals = {};
const botSpamStates = {}; 

   // أوامر السبام العادي
    if (m.startsWith("$start") && allcommand === true) {
        // إيقاف أي سبام سابق لهذا البوت
        if (botSpamIntervals[ws.id]) {
            clearInterval(botSpamIntervals[ws.id]);
            delete botSpamIntervals[ws.id];
        }
        
        const parts = m.split(" ");
        const targetName = parts.length > 1 ? parts.slice(1).join(" ") : "اسم";
        const arrMsg = baseMsgs.map(msg => msg.replace(/اسم/g, targetName));
        
        // تعيين نوع السبام
        botSpamStates[ws.id] = 'insult';
        
        botSpamIntervals[ws.id] = setInterval(() => {
            try {
                if (ws.readyState === WebSocket.OPEN) {
                    const msg = arrMsg[Math.floor(Math.random() * arrMsg.length)];
                    ws.send('42[11,' + ws.id + ',"' + msg + '"]');
                } else {
                    clearInterval(botSpamIntervals[ws.id]);
                    delete botSpamIntervals[ws.id];
                    delete botSpamStates[ws.id];
                }
            } catch (err) {
                clearInterval(botSpamIntervals[ws.id]);
                delete botSpamIntervals[ws.id];
                delete botSpamStates[ws.id];
            }
        }, 960);
    }
    
    // أوامر لانا ديل ري
    if (m.startsWith("$lanadelrey") && allcommand === true) {
        // إيقاف أي سبام سابق لهذا البوت
        if (botSpamIntervals[ws.id]) {
            clearInterval(botSpamIntervals[ws.id]);
            delete botSpamIntervals[ws.id];
        }
        
        let index = 0;
        botSpamStates[ws.id] = 'lana';
        
        botSpamIntervals[ws.id] = setInterval(() => {
            try {
                if (ws.readyState === WebSocket.OPEN) {
                    const msg = arrLana[index];
                    ws.send('42[11,' + ws.id + ',"' + msg + '"]');
                    index = (index + 1) % arrLana.length;
                } else {
                    clearInterval(botSpamIntervals[ws.id]);
                    delete botSpamIntervals[ws.id];
                    delete botSpamStates[ws.id];
                }
            } catch (err) {
                clearInterval(botSpamIntervals[ws.id]);
                delete botSpamIntervals[ws.id];
                delete botSpamStates[ws.id];
            }
        }, 960);
    }
    
    // إيقاف السبام العادي
    if (m.startsWith("$stop") && allcommand === true) {
        // إيقاف جميع البوتات التي تستخدم السبام العادي
        Object.keys(botSpamIntervals).forEach(botId => {
            if (botSpamStates[botId] === 'insult') {
                clearInterval(botSpamIntervals[botId]);
                delete botSpamIntervals[botId];
                delete botSpamStates[botId];
            }
        });
    }
    
    // إيقاف سبام لانا
    if (m.startsWith("$slanadelrey") && allcommand === true) {
        // إيقاف جميع البوتات التي تستخدم سبام لانا
        Object.keys(botSpamIntervals).forEach(botId => {
            if (botSpamStates[botId] === 'lana') {
                clearInterval(botSpamIntervals[botId]);
                delete botSpamIntervals[botId];
                delete botSpamStates[botId];
            }
        });
    }

    
// ---- cla




                    if(m.startsWith("$nope") && allcommand===true){
         	let k=m.substring(6);
        let fc= usersinroom.find(e=>e.nick==k);
   ws.send('42[45,' + ws.id + ',["' + fc.id+ '",true]]');
   
                    	}                   
 if(m=="$report" && allcommand===true){ws.send('42[35,'+ws.id+']')}                   
if(m=="$jump" && allcommand===true){ws.send('42[25,'+ws.id+']')
                    	}                     
if(m=="$tips" && allcommand===true){ws.send('42[30,'+ws.id+',1]')
                    	}                                  
if(m=="$exit" && allcommand===true){ws.send('42[24,'+ws.id+']')
                    	}
                    }
                                                if(msg.data.indexOf('42["23"')!=-1){
    let user=JSON.parse("{"+msg.data.split("{")[1].split("}")[0]+"}")

    usersinroom.push(user);
    
    // Check if this user is one of our bots
    const isOwnBot = Object.values(connectedBots).some(bot => bot.id === user.id);
    
    if(kickonjoin===true && !isOwnBot){
        // Add delay to prevent spam kicks
        setTimeout(() => {
            if(ws.readyState === WebSocket.OPEN) {
                ws.send('42[45,' + ws.id + ',["' + user.id+ '",true]]');
            }
        }, kickDelay);
        kickDelay += 500; // Increase delay for next kick
    }
    
    let ck=JSON.parse(localStorage.getItem("customkick"));
    if (ck.find(e=>e.user===user.nick) && !isOwnBot) {
        setTimeout(() => {
            if(ws.readyState === WebSocket.OPEN) {
                ws.send('42[45,' + ws.id + ',["' + user.id+ '",true]]');
            }
        }, kickDelay);
        kickDelay += 500;
    }
}
                                    if(msg.data.indexOf('42["24"')!=-1){
    let user=msg.data.split(",")[1].split('"')[1]
    
    // Remove from room list
    for(let i=0;i<usersinroom.length;i++){
        if(usersinroom[i].id === user) {
            usersinroom.splice(i,1);
            break;
        }
    }
    
    // Don't handle bot reconnection here - let the interceptor handle it
}

                if(msg.data.indexOf('42["34"')!=-1){
                    let objlist=JSON.parse('["34"'+msg.data.split('42["34"')[1])
                    var c=objlist[1];
                    var tv=objlist[2];
                LUNA_("answerinput",c)
                                    if(autofarm===true){
                                     setTimeout(()=>{
                LUNA_("answer",c)},100)
                    }
                    if(giveanswer===true){
                    	let iC = ["឴", "‏", "឵"];
let r = "";

for (let i = 0; i < c.length; i++) {
  r+= c.charAt(i);
  if (i < c.length - 1) {
    let riC = iC[Math.floor(Math.random() * iC.length)];
    r+= riC;
  }
}
ws.send('42[11,'+ws.id+',"answer: '+r+'"]')
                    	}
  if(autotips===true){
  for(let i = 0; i < tv; i++){
ws.send('42[30,'+ws.id+',1]')}
}
}
if(msg.data.indexOf('42["16"')!=-1 && autofarm===true){
                    ws.send('42[34,'+ws.id+']')
 
}
                                  if(msg.data.indexOf('42["16"') && autoskip===true){
    setTimeout(()=>{
      ws.send('42[25,'+ws.id+']');},1000)

                                  }
                if(msg.data.indexOf('42["47"]')!=-1 && autoreport===true){

      ws.send('42[35,'+ws.id+']')

                }

                if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 | msg.data.indexOf(''+ws.longID+',1')!=-1) && antikick===true){

      ws.send('42[24,'+ws.id+']');
      LUNA_("rejoin",window.location.href.split("/")[2],nv[1],nv[2],nv[3],nv[4])
}
      if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 || msg.data.indexOf(''+ws.longID+',1')!=-1) && autokick === true) {
  let msgautokick = msg.data.split(',');
  let autokickid = msgautokick[1].replace(/"/g, '');
                   LUNA_("kick",autokickid)
                }
                if(msg.data.indexOf('42["16"')!=-1){
                    let objlist=JSON.parse('["16"'+msg.data.split('42["16"')[1])
                    var word1=objlist[1]
                    var word2=objlist[3]
                LUNA_("word1",word1)
                LUNA_("word2",word2)

}


}})}) 
      break;
case "broadcast":let b=nv[1];g('broadcast',b);break;
case "broadcastspam":let be=nv[1];g('broadcastspam',be);break;
case "msg":let m=nv[1];g('msg',m);break;
case "msgspam":let me=nv[1];g('msgspam',me);break;
case "answer":let a=nv[1];g('answer',a);break;
case "answerspam":let ae=nv[1];g('answerspam',ae);break;
case "exit":g('exit','1');break;
case "report":g('report','1');break;
case "0xbE":g('0xbE','1');break;
case "jump":g('jump','1');break;
case "tips":g('tips','1');break;
case "accept1":g('accept1','1');break;
case "accept2":g('accept2','1');break;
case "kick":let k=nv[1];g('kick',k);break;
case "rejoin":g('rejoin','1');break;
case "afkconfirm":g('afkconfirm','1');break;
case "kicknewset":break;
case "kickjoinset":break;
case "autoreport":autoreport=nv[1];break;
case "autoskip":autoskip=nv[1];break;
case "antikick":antikick=nv[1];break;
case "autokick":autokick=nv[1];break;
case "antiafk":antiafk=nv[1];if(nv[1]===true){intervalantiafk = setInterval(()=> {g('afkconfirm','1'); }, 10000);} else {clearInterval(intervalantiafk);}break;
case "autofarm":autofarm=nv[1];break;
case "autoguess":autoguess=nv[1];break;
case "giveanswer":giveanswer=nv[1];break;
case "autorejoin":autorejoin=nv[1];break;

case "kickalljoin":kickalljoin=nv[1];break;
case "kickonjoin":kickonjoin=nv[1];break;
case "allcommand":allcommand=nv[1];break;
case "autotips":autotips=nv[1];break;
  
      
  
      
    
  }
}});
if(botsv!=="[]" && 1==2){
setTimeout(()=>{let obj=JSON.parse(localStorage.getItem("bots")); obj.forEach(links=>{var ifrm = document.createElement("iframe"); ifrm.setAttribute("src", "https://"+links.link+"/favicon.ico?__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8"); ifrm.style.width = "100px"; ifrm.style.height = "180px";ifrm.style.display = "none"; document.body.appendChild(ifrm);})},1000)}

chrome.storage.onChanged.addListener(function(changes, namespace) {
  if (changes.message) {
    let ne = changes.message.newValue;
    let nv = JSON.parse(ne)
    switch(nv[0]){
    	case "nextURL":
            let obj=JSON.parse(localStorage.getItem("bots"))
        localStorage.getItem("bots").indexOf(nv[1])==-1?obj.push({"link":nv[1],"timestamp":new Date().getTime()}):0
        
        localStorage.getItem("bots").indexOf(nv[1])==-1?document.querySelector("#icebot5").innerHTML += `<input type="submit" style="width:100%; height:40px; position: relative; font-weight: bold;" id="proxy-`+nv[1]+`" onclick="window.postMessage('proxyrmv.`+nv[1]+`','*')" value="`+nv[1]+`">`:0
        localStorage.setItem("bots",JSON.stringify(obj))        
    document.querySelector('#proxylist').textContent="Proxy list • ACTIVE "+JSON.parse(localStorage.getItem("bots")).length;


    break;
    case "answerinput":
    document.querySelector('#answer').value=nv[1]
    break;
    case "word1":
        document.querySelector('#word1').value=nv[1]
    break;
    case "word2":
        document.querySelector('#word2').value=nv[1]
    break;
    case "answer":
    __0x70("answer",nv[1])
    break;
    case "kick":
    __0x70("kick",nv[1])
    break;
    case "rejoin":
    __0x52("join",nv[1],nv[2],nv[3],nv[4],nv[5])
    break;
    case "callbackbot":
    setTimeout(()=>{window.postMessage('colorbot.'+nv[1],'*')},60)
    break;
    }
  }
});


function injectScript (src) { const s = document.createElement('script'); s.src = chrome.runtime.getURL(src); s.type = "module";
 s.onload = () => s.remove(); (document.head || document.documentElement).append(s); }
function is2 (src) { const s = document.createElement('script'); s.src = chrome.runtime.getURL(src);
 (document.head || document.documentElement).append(s); } injectScript('wsProxy.js');is2('sweetalert2@10.js');
        	}
                if(window.location.href.indexOf("aHR0cHM6Ly9nYXJ0aWMuaW8")!=-1){
                	    let kicknewstat=false,kickjoinstat=false,autoreport=false,autoskip=false,antiafk=false,antikick=false,antikickDelay=1,autokick=false,autoguess,autofarm=true,waitforkick=0,kickDelay=500
function rnext(kelime) { const hd = kelime.split(''); const hu = hd.length; const yh = []; const invisibleChars = ['\u200B', '\u200C', '\u200D', '\u2061', '\u2062', '\u2063', '\u2064', '\u2066', '\u17b4', '\u17b5', '\u2068', '\u2069']; let charCount = 0; for (let i = 0; i < hu; i++) {yh.push(hd[i]);charCount++;if (charCount < 18 && i < hu - 1) { const invisibleChar = invisibleChars[Math.floor(Math.random() * invisibleChars.length)]; yh.push(invisibleChar); charCount++;}if (charCount >= 18) { break;} } return yh.join('');}
function LUNA(o, pN, c) {let v = o[pN];Object.defineProperty(o, pN, {  get() { return v;    },set(nV) {  if (nV !== v) {  const oV = v;  v = nV; c(nV, oV);    }},  });};
let usersinroom=[]
const data = {ev: 10};
function g(e, x) {
  data.ev = [e,x,Math.ceil(Math.random()*100000+1)]
}
     let inv= ['឴','‏','឵','­','͏','‎','𝅹','⁡'];
  const webSockets = {};
window.addEventListener('message', function(event) {
	                let abtn=event.data.split("cmd.")[1]
	let nv=JSON.parse(abtn);
    	switch(nv[0]){
    	case "join":
   let room=nv[1];
            fetch("https://"+window.location.href.split("/")[2]+"/server/?check=1&v3=1&room="+room+"&__cpo=aHR0cHM6Ly9nYXJ0aWMuaW8#").then(x=>x.text()).then(x=>{
            let ws=new WebSocket("wss://"+window.location.href.split("/")[2]+"/__cpw.php?u="+btoa("wss://"+x.split("https://")[1].split(".")[0]+".gartic.io/socket.io/?c="+x.split("?c=")[1]+"&EIO=3&transport=websocket")+"&o=aHR0cHM6Ly9nYXJ0aWMuaW8="); 
ws.onopen=()=>{
	if (nv[4] === '0') {
  ws.send('42[3,{"v":20000,"nick":"'+rnext(nv[2])+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]')
} else if (nv[4] === '1') {
  ws.send('42[3,{"v":20000,"nick":"'+nv[2]+Math.ceil(Math.random()*10000+1)+'","avatar":'+nv[3]+',"platform":0,"sala":"'+room.substring(2)+'"}]')
}
else if (nv[4] === '2') {
	
let c = JSON.parse(nv[5]);
function e() {
  return c[Math.floor(Math.random() * c.length)];
};
let r = e();
ws.send('42[3,{"v":20000,"nick":"' + r.nick + '","avatar":"' + r.avatar + '","platform":0,"sala":"' + room.substring(2) + '"}]');
}

            	}
                ws.onmessage= (msg) => {
                	                if(msg.data.indexOf('42["5"')!=-1){
               let objlist=JSON.parse('["5"'+msg.data.split('42["5"')[1]);
               ws.longID=objlist[1];
               ws.id=objlist[2];      
               LUNA_("callbackbot",objlist[1]);                                    objlist[5].forEach(item=>{usersinroom.push(item)});
               let mj=JSON.parse(nv[6]);mj.forEach(m=>{switch(m.type){
case "broadcast":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;case "message":ws.send('42[11,'+ws.id+',"'+m.msg+'"]');break;
case "answer":ws.send('42[13,'+ws.id+',"'+m.msg+'"]');break;
}})               

                        ws.send('42[46,' + ws.id + ']');
                    setInterval(()=>{ws.send('2')},3000)
                   webSockets[ws.id] = { socket: ws, timestamp: ws.id};
                   LUNA(data, 'ev', (nV, oV) => {
      if (nV) {
        Object.values(webSockets).forEach(wsObj => {
          const ws = wsObj.socket;
          const timestamp = wsObj.timestamp;

          switch (nV[0]) {
            case "broadcast":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "broadcastspam":
            inv = shuffle(inv);
let fE= inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fE +'"]');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fE + '"]');
              break;
            case "msg":
              ws.send('42[11,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "msgspam":
            inv = shuffle(inv);
let fM = inv.slice(0,3).join('');
              ws.send('42[11,' + timestamp + ',"' + nV[1] + fM +'"]');
              break;
            case "answer":
              ws.send('42[13,' + timestamp + ',"' + nV[1] + '"]');
              break;
            case "answerspam":
            inv = shuffle(inv);
let fA= inv.slice(0,3).join('');
              ws.send('42[13,' + timestamp + ',"' + nV[1] + fA + '"]');
              break;
            case "report":
              ws.send('42[35,' + timestamp + ']');
              break;
            case "jump":
              ws.send('42[25,' + timestamp + ']');
              break;
            case "accept1":
              ws.send('42[34,' + timestamp + ']');
              break;
            case "accept2":
              ws.send('42[34,' + timestamp + ',1]');
              break;
            case "tips":
              ws.send('42[30,' + timestamp + ',1]');
              break;
            case "exit":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "rejoin":
              ws.send('42[24,' + timestamp + ']');
              break;
            case "afkconfirm":
              ws.send('42[42,' + timestamp + ']');
              break;
            case "kick":
              ws.send('42[45,' + timestamp + ',["' + nV[1] + '",true]]');
              break;
              case "0xbE":
           
              break;
          }
        });
      }
    });
                	}
                if(msg.data.indexOf('42["34"')!=-1){
                    let objlist=JSON.parse('["34"'+msg.data.split('42["34"')[1])
                    var correct=objlist[1]

                LUNA_("answerinput",correct)
                                    if(autofarm===true){
                                     setTimeout(()=>{
                LUNA_("answer",correct)},100)
                    }
}
if(msg.data.indexOf('42["16"')!=-1 && autofarm===true){
                    ws.send('42[34,'+ws.id+']')
                                 }
                                  if(msg.data.indexOf('42["16"')!=-1 && autoskip===true){
    setTimeout(()=>{
      ws.send('42[25,'+ws.id+']');},1000)

                                  }
                if(msg.data.indexOf('42["47"]')!=-1 && autoreport===true){

      ws.send('42[35,'+ws.id+']')

                }

                if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 | msg.data.indexOf(''+ws.longID+',1')!=-1) && antikick===true){

      ws.send('42[24,'+ws.id+']');
      LUNA_("rejoin",window.location.href.split("/")[2],nv[1],nv[2],nv[3],nv[4])
}
      if(msg.data.indexOf('42["45"')!=-1 && (msg.data.indexOf('"'+ws.longID+'",1')!=-1 || msg.data.indexOf(''+ws.longID+',1')!=-1) && autokick === true) {
  let msgautokick = msg.data.split(',');
  let autokickid = msgautokick[1].replace(/"/g, '');
                   LUNA_("kick",autokickid)
                }
                if(msg.data.indexOf('42["16"')!=-1){
                    let objlist=JSON.parse('["16"'+msg.data.split('42["16"')[1])
                    var word1=objlist[1]
                    var word2=objlist[3]
                LUNA_("word1",word1)
                LUNA_("word2",word2)

}

}})
      break;
case "broadcast":let b=nv[1];g('broadcast',b);break;
case "broadcastspam":let be=nv[1];g('broadcastspam',be);break;
case "msg":let m=nv[1];g('msg',m);break;
case "msgspam":let me=nv[1];g('msgspam',me);break;
case "answer":let a=nv[1];g('answer',a);break;
case "answerspam":let ae=nv[1];g('answerspam',ae);break;
case "exit":g('exit','1');break;
case "report":g('report','1');break;
case "0xbE":g('0xbE','1');break;
case "jump":g('jump','1');break;
case "tips":g('tips','1');break;
case "accept1":g('accept1','1');break;
case "accept2":g('accept2','1');break;
case "kick":let k=nv[1];g('kick',k);break;
case "rejoin":g('rejoin','1');break;
case "afkconfirm":g('afkconfirm','1');break;
case "kicknewset":break;
case "kickjoinset":break;
case "autoreport":autoreport=nv[1];break;
case "autoskip":autoskip=nv[1];break;
case "antikick":antikick=nv[1];break;
case "autokick":autokick=nv[1];break;
case "antiafk":antiafk=nv[1];if(nv[1]===true){intervalantiafk = setInterval(()=> {g('afkconfirm','1'); }, 10000);} else {clearInterval(intervalantiafk);}break;
case "autofarm":autofarm=nv[1];break;
case "autoguess":break;

    
  }
});
}

if(window.location.href.indexOf("?__cpo=")!=-1){
    LUNA_("nextURL",window.location.href.split("/")[2])

}

if(window.location.href.indexOf("?proxyset")!=-1){setTimeout(()=>{
document.querySelector("#quickLinks > a:nth-child(1)").setAttribute("data-href","https://gartic.io/favicon.ico")
setInterval(()=>{
    document.querySelector("#quickLinks > a:nth-child(1)").click()},1)},1000)}
    if(window.location.href.indexOf("?2proxyset")!=-1){setTimeout(()=>{
document.querySelector("#unique-form-control").value="https://gartic.io/favicon.ico";setTimeout(()=>{document.querySelector("#unique-btn-blue").click()},200)},1000)}
// Add this at the very end of your script

window.addEventListener("load", () => {
    // 1. Setup Bot Chat (Send on Enter + Resume Typing)
    const botChatInput = document.getElementById("botChatMessage");
    if (botChatInput) {
        botChatInput.addEventListener("keydown", (e) => {
            // Check if Enter is pressed (and not held down)
            if (e.key === "Enter" && !e.isComposing && !e.repeat) {
                e.preventDefault(); // Stop default line break

                const textToSend = botChatInput.value.trim();
                if (textToSend) {
                    // Send the command
                    window.postMessage('sendBotChat', '*');
                    
                    // Clear the box immediately so you can type the next thing
                    // Note: The 'sendBotChat' listener reads the value, so we use a tiny delay 
                    // or rely on the fact that postMessage is async, but to be safe:
                    // We need to manually clear it *after* the listener reads it. 
                    // Since we can't control the order easily here without modifying the listener, 
                    // let's update the sendBotChat listener logic slightly in Step 3 below.
                    
                    // Actually, simpler fix: We will clear it here, but we must pass the text 
                    // directly or wait a millisecond. 
                    // Let's use the safer method:
                    
                    setTimeout(() => {
                        botChatInput.value = "";
                        botChatInput.focus(); // Keep focus
                    }, 10);
                }
            }
        });
    }
});