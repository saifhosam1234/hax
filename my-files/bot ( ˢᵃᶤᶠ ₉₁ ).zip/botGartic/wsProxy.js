/* ═══════════════════════════════════════════════════════════════
   ⚡ ɨƈɛɮօȶ V6 — wsProxy.js  ˢᵃᶤᶠ ₉₁
   Injected as a page-world script by content_script.js
   ═══════════════════════════════════════════════════════════════ */
"use strict";

var scriptString = (function () {

  /* ── Utilities ─────────────────────────────────────────────── */
  function LUNA(obj, prop, callback) {
    let val = obj[prop];
    Object.defineProperty(obj, prop, {
      get()    { return val; },
      set(nV)  { if (nV !== val) { const oV = val; val = nV; callback(nV, oV); } },
    });
  }

  function processData(data) {
    if (typeof data === 'string') return data;
    if (data && data.byteLength !== undefined) {
      const arr   = Array.from(new Uint8Array(data));
      const hex   = arr.map(b => b.toString(16).padStart(2, '0'));
      let   str   = unescape(hex.map(h => '%' + h).join(''));
      try { str = decodeURIComponent(escape(str)); } catch (_) {}
      return { orig: data, uintarr: new Uint8Array(data), hexstr: hex.join(''), string: str, b64str: btoa(str) };
    }
  }

  /* ── Reactive state (one object per property so LUNA fires selectively) */
  const de = { exit: 10, rdraw: 10, kick: 10, answer: 10, chat: 10 };

  function trigger(event, value) {
    const key = event;
    if (de[key] !== undefined) {
      de[key] = [event, value, Math.ceil(Math.random() * 100000 + 1)];
    }
  }

  /* ── Game data ─────────────────────────────────────────────── */
  let subjects  = [];
  let languages = [];
  let arfSL     = [];

  setTimeout(() => {
    try {
      subjects  = window.__NEXT_DATA__.props.data.subjects;
      languages = window.__NEXT_DATA__.props.data.languages;
      localStorage.setItem('languages', JSON.stringify(languages));
      localStorage.setItem('subjects',  JSON.stringify(subjects));
    } catch (_) {}
  }, 3000);

  function gSL(subjectId, langId) {
    const sObj = subjects.find(i => i.id === subjectId);
    const lObj = languages.find(i => i.id === langId);
    if (sObj && lObj) {
      arfSL         = [sObj.name, lObj.name];
      window.argsSL = arfSL;
      setTimeout(() => {
        const el = document.querySelector('.roomtheme');
        if (el) el.innerHTML = arfSL[0] + ', ' + arfSL[1];
      }, 10);
    }
  }

  /* ── Kick-button injection ─────────────────────────────────── */
  window.FindReact = function (dom) {
    if (!dom) return null;
    for (const key in dom) {
      if (key.startsWith('__reactInternalInstance$')) return dom[key].key;
    }
    return null;
  };

  function injectKickBtn(el, id) {
    if (!el || !el.className || el.className === 'userlist') return;
    if (el.querySelector('.ib-kick-btn')) return;  // deduplicate
    if (!el.lastChild || el.lastChild.className === 'btn no-style') return;

    try {
      const isMobile = window.__NEXT_DATA__?.query?.data?.mobile === true
                    && window.__NEXT_DATA__?.page !== '/viewer';
      const top = isMobile ? '10px' : '21px';
      el.lastChild.insertAdjacentHTML('afterend',
        `<div><input type="submit" class="btn no-style ib-kick-btn"
          style="z-index:9999999;background:white;border:none;cursor:pointer;
                 position:absolute;left:91px;top:${top};width:25px;height:25px;border-radius:50%;"
          value="😊"
          onclick="javascript:window.parent.postMessage('kickuser.${id}','*');
            setTimeout(()=>{
              const b=document.querySelector('#popUp > div > div > button');
              if(b) b.click();
              const p=document.querySelector('#popUp');
              if(p) p.style.display='none';
            },0);"
        ></div>`
      );
    } catch (err) {
      console.warn('[ICEbot] Kick btn inject failed:', err);
    }
  }

  // Periodic safety pass
  setInterval(() => {
    try {
      document.querySelectorAll('div[class*="user"]:not([class*="empty"]):not([class*="tools"])')
        .forEach(el => {
          if (!el.querySelector('.ib-kick-btn')) {
            const id = window.FindReact(el);
            if (id) injectKickBtn(el, id);
          }
        });
    } catch (_) {}
  }, 500);

  // MutationObserver for instant injection
 function startKickObserver() {
  const target = document.body || document.documentElement;
  if (!target) return;
  new MutationObserver(mutations => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (typeof node.className === 'string' && node.className.includes('user')) {
          const id = window.FindReact(node);
          if (id) injectKickBtn(node, id);
        }
        node.querySelectorAll?.('div[class*="user"]').forEach(el => {
          const id = window.FindReact(el);
          if (id) injectKickBtn(el, id);
        });
      }
    }
  }).observe(target, { childList: true, subtree: true });
}

if (document.body) {
  startKickObserver();
} else {
  document.addEventListener('DOMContentLoaded', startKickObserver);
}

  /* ── Kick-menu (userlist panel) ────────────────────────────── */
  function updateKickMenu() {
    const menu = document.querySelector('.userkickmenu');
    if (!menu) return;
    const theme       = localStorage.getItem('theme');
    const lightThemes = new Set(['white', 'yellow']);
    const textColor   = lightThemes.has(theme) ? 'black' : 'white';
    const bgColor     = theme || '#FFD700';

    menu.innerHTML = '';
    (window.roomusers || []).forEach(user => {
      if (user.nick.replace(/./g, '') === 'ICEbot') return;
      menu.innerHTML +=
        `<input type="submit" class="kickmenubtn"
          style="background-color:${bgColor};color:${textColor};"
          value="${user.nick}"
          onclick="window.postMessage('kickuser.${user.id}','*')">`;
    });
  }

  /* ── Bot color highlight ───────────────────────────────────── */
  function highlightBot(longId) {
    document.querySelectorAll('span.nick').forEach(x => {
      const parent2 = x.parentElement?.parentElement;
      if (window.FindReact(parent2) === longId) {
        parent2.style.backgroundImage = 'linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.2))';
        x.style.color = '#510ac9';
      }
    });
  }

  /* ── Vote-kick toast ───────────────────────────────────────── */
  function showVoteKickToast(nick, avatar, photo) {
    const Toast = Swal.mixin({
      toast: true, position: 'top-end',
      showConfirmButton: false, timer: 3000, timerProgressBar: true,
      didOpen: t => { t.onmouseenter = Swal.stopTimer; t.onmouseleave = Swal.resumeTimer; },
    });
    const imgSrc = photo
      ? photo
      : `https://gartic.io/static/images/avatar/svg/${avatar}.svg`;
    Toast.fire({
      iconHtml: `<img src="${imgSrc}" style="height:50px;width:50px;">`,
      title: nick + ' voted to kick',
    });
  }

  /* ── postMessage command router ────────────────────────────── */
  window.addEventListener('message', msg => {
    if (typeof msg.data !== 'string') return;
    const d = msg.data;

    if (d.startsWith('votedkick.')) {
      const parts  = d.split('.');
      const nick   = parts[1];
      const avatar = parts[2];
      const photo  = parts.slice(3).join('.') === 'undefined' ? null : parts.slice(3).join('.');
      showVoteKickToast(nick, avatar, photo);
      return;
    }
    if (d === 'kickall') {
      (window.roomusers || []).forEach((u, i) => {
        if (u.id !== window.longID && !(window.whitelist || []).includes(u.id)) {
          setTimeout(() => window.postMessage('kickuser.' + u.id, '*'), 350 * i);
        }
      });
      return;
    }
    if (d === 'proxyactive') {
      Swal.mixin({
        toast: true, position: 'top-end',
        showConfirmButton: false, timer: 6000, timerProgressBar: true,
        didOpen: t => { t.onmouseenter = Swal.stopTimer; t.onmouseleave = Swal.resumeTimer; },
      }).fire({ icon: 'info', title: "Proxy cookies updated. Click 'refresh all' to enable.(ˢᵃᶤᶠ ₉₁)" });
      return;
    }
    if (d === 'info') {
      Swal.fire({
        title: 'ICEbot v6.6.6',
        html: '⸸ Unlimited requests (429 bypass)<br>⸸ Full Cloudflare bypass<br>'
            + '⸸ Anti disconnect system<br>⸸ Bot dupe<br>⸸ Anti afk fixed<br>'
            + '⸸ Custom bot added<br>⸸ One tab bot system<br>'
            + '⸸ 70+ free proxies<br>⸸ Proxy selector<br>⸸ Auto kick fixed<br>'
            + '⸸ More bot nick modes<br>⸸ Ghost mode (undetectable)<br>⸸ Bug fixes',
        icon: 'info', allowOutsideClick: false,
      });
      return;
    }
    if (d.startsWith('colorbot.')) {
      const id = d.split('colorbot.')[1];
      if (!(window.whitelist || []).includes(id)) {
        (window.whitelist = window.whitelist || []).push(id);
      }
      highlightBot(id);
      return;
    }
  });

  /* ── WebSocket proxy ───────────────────────────────────────── */
  if (typeof window.Proxy === 'undefined') return;

  const OriginalWS = window.WebSocket;
  let   wsCounter  = 0;
  let   intping;

  const wsProxyDesc = {
    set(target, prop, val) {
      if (prop === 'onmessage') {
        const origHandler = val;
        val = function (e) {
          const d = processData(e.data);
          if (typeof d !== 'string') { origHandler(e); return; }

          // ── Inject kick buttons on user list events ──────────
          if (d.includes('42["5"')) {
            window.roomusers = [];
            window.whitelist = [];
            const list = JSON.parse('["5"' + d.split('42["5"')[1]);
            list[5].forEach(u => window.roomusers.push(u));
            window.id     = list[2];
            window.longID = list[1];
            gSL(list[4].tipo, list[4].idioma);
            updateKickMenu();
            setTimeout(() => highlightBot(String(list[1])), 6000);
          }

          if (d.includes('42["23"')) {
            const user = JSON.parse('{' + d.split('{')[1].split('}')[0] + '}');
            (window.roomusers = window.roomusers || []).push(user);
            setTimeout(() => {
              const el = Array.from(document.querySelectorAll('span.nick'))
                .find(x => x.textContent === user.nick)
                ?.parentElement?.parentElement;
              if (el) injectKickBtn(el, window.FindReact(el));
            }, 300);
          }

          if (d.includes('42["24"')) {
            const uid = d.split(',')[1].split('"')[1];
            const idx = (window.roomusers || []).findIndex(u => u.id === uid);
            if (idx !== -1) window.roomusers.splice(idx, 1);
            updateKickMenu();
          }

          // ── Vote-kick detection ──────────────────────────────
          if (d.includes('42["45"')) {
            const payload = JSON.parse(d.substring(2));
            if (payload[2] === window.longID) {
              const voter = payload[1];
              const u     = (window.roomusers || []).find(x => x.id === voter);
              if (u) {
                new Audio('https://cdn.pixabay.com/audio/2022/03/15/audio_082d7de7ab.mp3')
                  .play().catch(() => {});
                window.postMessage(
                  'votedkick.' + u.nick + '.' + u.avatar + '.' + (u.foto || 'undefined'), '*'
                );
              }
            }
          }

          origHandler(e);
        };
      }
      target[prop] = val;
      return true;
    },

    get(target, prop) {
      let val = target[prop];
      if (prop === 'send') {
        val = function (data) {
          const r = processData(data);
          if (typeof r !== 'string') { target.send(data); return; }

          // ── Mimic mode ───────────────────────────────────────
          if (localStorage.getItem('mimic') === 'true') {
            if (r.includes('42[11')) {
              const parts = JSON.parse('[11' + data.split('42[11')[1]);
              window.postMessage('chatx.'   + parts[2], '*');
            }
            if (r.includes('42[13')) {
              const parts = JSON.parse('[13' + data.split('42[13')[1]);
              window.postMessage('answerx.' + parts[2], '*');
            }
            if (r.includes('42[35')) window.postMessage('report', '*');
            if (r.includes('42[24')) window.postMessage('exit',   '*');
          }

          // ── Clear kick menu on exit ──────────────────────────
          if (r.includes('42[24')) {
            const menu = document.querySelector('.userkickmenu');
            if (menu) menu.innerHTML = '';
            if (intping) clearInterval(intping);
          }

          // ── Block namespace-disconnect frame ─────────────────
          if (data === '41') return;

          // ── Chat commands from room ──────────────────────────
          if (r.includes('42[11') || r.includes('42[13')) {
            const payload = JSON.parse('[' + data.split('42[')[1]);
            const msg     = payload[2] || '';
            if (msg.startsWith('$kick'))        { window.roomusers?.forEach(x => { if (x.nick === msg.substring(6)) window.postMessage('kickuser.' + x.id, '*'); }); }
            if (msg.startsWith('$broadcast'))   { window.postMessage('broadcastx.' + msg.substring(11), '*'); }
            if (msg.startsWith('$msg'))         { window.postMessage('chatx.'       + msg.substring(5),  '*'); }
            if (msg.startsWith('$answer'))      { window.postMessage('answerx.'     + msg.substring(8),  '*'); }
            if (msg === '$report')              { window.postMessage('report',    '*'); }
            if (msg === '$jump')                { window.postMessage('jump',      '*'); }
            if (msg === '$acceptdraw1')         { window.postMessage('acceptdraw1','*'); }
            if (msg === '$acceptdraw2')         { window.postMessage('acceptdraw2','*'); }
            if (msg === '$tips')                { window.postMessage('tips',      '*'); }
            if (msg === '$exit')                { window.postMessage('exit',      '*'); }
          }

          target.send(data);
        };
      } else if (typeof val === 'function') {
        val = val.bind(target);
      }
      return val;
    },
  };

  window.WebSocket = new Proxy(OriginalWS, {
    construct(target, args) {
      const ws        = new target(args[0]);
      ws.WSLoggerId   = ++wsCounter;
      ws.binaryType   = 'arraybuffer';

      ws.sendMessage = function (msg) {
        if (ws.readyState === WebSocket.OPEN) ws.send(msg);
      };

      // Reactive bindings for de.* triggers
      LUNA(de, 'exit',   ()    => ws.sendMessage(`42[24,${window.id}]`));
      LUNA(de, 'rdraw',  (nV)  => ws.sendMessage(`42[10,${window.id},[5,"x${nV[1]}"]]`));
      LUNA(de, 'chat',   (nV)  => ws.sendMessage(`42[11,${window.id},"${nV[1]}"]`));
      LUNA(de, 'answer', (nV)  => ws.sendMessage(`42[13,${window.id},"${nV[1]}"]`));
      LUNA(de, 'kick',   (nV)  => {
        (window.roomusers || []).forEach(x => {
          if (x.nick === nV[1]) ws.sendMessage(`42[45,${window.id},["${x.id}",true]]`);
        });
      });

      ws.addEventListener('open', () => {
        intping = setInterval(() => ws.sendMessage('2'), 25000);
      });

      return new Proxy(ws, wsProxyDesc);
    },
  });

});

/* ── Self-inject into page world ───────────────────────────────── */
new MutationObserver(function (_, obs) {
  if (!document.head) return;
  obs.disconnect();
  const script     = document.createElement('script');
  script.innerHTML = '(' + scriptString + ')();';
  document.head.appendChild(script);
  script.remove();
}).observe(document, { subtree: true, childList: true });