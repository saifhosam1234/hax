"use strict";

// ═══════════════════════════════════════════════════════════════
// ⚡ ɨƈɛɮօȶ V6 — worker.js  ˢᵃᶤᶠ ₉₁
// ═══════════════════════════════════════════════════════════════

// ── Constants ──────────────────────────────────────────────────
const Types = {
  MAIN_FRAME : 'main_frame',
  SUB_FRAME  : 'sub_frame',
  XHR        : 'xmlhttprequest',
  WS         : 'websocket',
  OTHER      : 'other',
};

const Specs = {
  ON_BEFORE_REQUEST   : ['blocking'],
  ON_BEFORE_SEND      : ['blocking', 'requestHeaders', 'extraHeaders'],
  ON_HEADERS_RECEIVED : ['blocking', 'extraHeaders', 'responseHeaders'],
};

// ── Header helpers ─────────────────────────────────────────────
const HEADERS_TO_STRIP = {
  'x-frame-options'                  : true,
  'content-security-policy-report-only': true,
};

const Replacers = {
  COOKIES: {
    'set-cookie': [
      { from: /;\s*Secure/i,                        to: '' },
      { from: /;\s*SameSite=(None|Lax|Strict)/i,    to: '' },
      { from: /.{0}$/,                               to: '; Secure; SameSite=None' },
    ],
  },
  CSP: {
    'content-security-policy': [
      { from: /(^|;)\s*report-(uri|to|sample)\s[^;]*/ig, to: ';' },
      { from: /(^|;)\s*frame-ancestors\s[^;]*/i,         to: ';' },
      { from: /[;\s]*;[;\s]*/g,                           to: '; ' },
      { from: /^; /,                                      to: '' },
      { from: /; $/,                                      to: '' },
    ],
  },
};

function handlePassthrough({ requestHeaders, responseHeaders }) {
  if (responseHeaders !== undefined) return { responseHeaders };
  if (requestHeaders  !== undefined) return { requestHeaders };
  return {};
}

function handleResponseHeaders(details, replacers) {
  const responseHeaders = details.responseHeaders
    .map(header => {
      if (!header.value) return header;
      const name = header.name.toLowerCase();
      if (HEADERS_TO_STRIP[name]) return null;
      const replacer = replacers[name];
      if (replacer) {
        for (const r of replacer) {
          header.value = header.value.replace(r.from, r.to);
        }
        if (!header.value) return null;
      }
      return header;
    })
    .filter(Boolean);
  return { responseHeaders };
}

// ── Listener: Redirect addownit extension.json ─────────────────
(function _handleExtensionJson() {
  const EXTENSION_JSON_URL = chrome.runtime.getURL('extension.json');
  chrome.webRequest.onBeforeRequest.addListener(
    () => ({ redirectUrl: EXTENSION_JSON_URL }),
    { urls: ['https://oapi.addownit.com/extension.json'], types: [Types.XHR] },
    Specs.ON_BEFORE_REQUEST
  );
})();

// ── Listener: Strip CSP / fix cookies on main & sub frames ─────
(function _handleFrameResponseHeaders() {
  const replacers = { ...Replacers.COOKIES, ...Replacers.CSP };
  chrome.webRequest.onHeadersReceived.addListener(
    details => {
      if (details.frameId === 0 || details.type === Types.MAIN_FRAME) {
        return handleResponseHeaders(details, replacers);
      }
    },
    { urls: ['https://*/*', 'wss://*/*'], types: [Types.SUB_FRAME, Types.MAIN_FRAME] },
    Specs.ON_HEADERS_RECEIVED
  );
})();

// ── Listener: Strip CSP / fix cookies on XHR & main frame ──────
(function _handleXhrResponseHeaders() {
  const replacers = { ...Replacers.COOKIES, ...Replacers.CSP };
  chrome.webRequest.onHeadersReceived.addListener(
    details => {
      if (details.frameId === 0 || details.type === Types.MAIN_FRAME) {
        return handleResponseHeaders(details, replacers);
      }
      return handlePassthrough(details);
    },
    { urls: ['https://*/*', 'wss://*/*'], types: [Types.XHR, Types.MAIN_FRAME] },
    Specs.ON_HEADERS_RECEIVED
  );
})();

// ── Listener: Capture redirect location values for proxy system ─
(function _handleLocationHeaders() {
  chrome.webRequest.onHeadersReceived.addListener(
    details => {
      for (const header of details.responseHeaders) {
        if (header.name.toLowerCase() !== 'location') continue;
        const segment = header.value.split('/')[3];
        if (details.url.includes('proxyrequest.php')) {
          chrome.storage.local.set({ locationValue2: segment });
        } else if (details.url.includes('requests?fso=')) {
          chrome.storage.local.set({ locationValue: segment });
        }
      }
    },
    { urls: ['<all_urls>'] },
    ['responseHeaders']
  );
})();

// ── Listener: Clear gartic session cookie on rejoin signal ──────
(function _handleRejoinCookieClear() {
  chrome.webRequest.onBeforeRequest.addListener(
    details => {
      if (!details.url.includes('favicon.ico?rjoin=1')) return;
      chrome.cookies.getAll({ name: 'garticio@gartic.io' }, cookies => {
        cookies.forEach(cookie => {
          const scheme = cookie.secure ? 'https://' : 'http://';
          chrome.cookies.remove({
            url : scheme + cookie.domain + cookie.path,
            name: 'garticio@gartic.io',
          });
        });
      });
    },
    { urls: ['<all_urls>'] }
  );
})();

// ── Listener: Strip sec-websocket-extensions from proxy WS ──────
// This prevents "Invalid frame header" errors from __cpw.php.
(function _handleWsProxyHeaders() {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    details => ({
      requestHeaders: details.requestHeaders.filter(
        h => h.name.toLowerCase() !== 'sec-websocket-extensions'
      ),
    }),
    { urls: ['wss://*/*/__cpw.php*'] },
    Specs.ON_BEFORE_SEND
  );
})();